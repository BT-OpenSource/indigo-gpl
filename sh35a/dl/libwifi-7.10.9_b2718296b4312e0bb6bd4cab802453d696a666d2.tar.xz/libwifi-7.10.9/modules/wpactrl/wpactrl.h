// SPDX-License-Identifier: LGPL-2.1-only
#ifndef WPACTRL_H
#define WPACTRL_H

#define WPACTRL_TIMEOUT 5

int hostapd_cli_set(const char *ifname, const char *cmd, bool check_ok);
int wpa_cli_set(const char *ifname, const char *cmd, bool check_ok);
int hostapd_cli_get(const char *ifname, const char *cmd, char *out, size_t out_size);
int wpa_cli_get(const char *ifname, const char *cmd, char *out, size_t out_size);

int wpa_ctrl_iface_get(const char *ifname, const char *cmd, char *out, size_t out_size, bool isHostapd);
int wpa_ctrl_get_param(const char *buf, const char *param, char *value, size_t value_max);

#endif
