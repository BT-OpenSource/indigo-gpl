#!/bin/bash
set -e
echo "build stage"
pwd


#build only libwifiutils.so
make
make clean

#build libwifi-7.so for TEST module
WIFI_TYPE=TEST CFLAGS="-DHAS_WIFI=1" make
WIFI_TYPE=TEST CFLAGS="-DHAS_WIFI=1" make clean

#build libwifi-7.so for DEFAULT module
CFLAGS="-DHAS_WIFI=1" make
CFLAGS="-DHAS_WIFI=1" make clean
