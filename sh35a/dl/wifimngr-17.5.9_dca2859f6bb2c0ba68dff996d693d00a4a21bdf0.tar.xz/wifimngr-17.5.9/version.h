const char *wifimngr_base_version = "12.0.0";
const char *wifimngr_xtra_version = "24101-2007-dirty";
