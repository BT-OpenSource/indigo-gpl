#include <libubus.h>
#include <libubox/blobmsg.h>

void validate_stats(struct json_object *json_obj, int ifstats);
