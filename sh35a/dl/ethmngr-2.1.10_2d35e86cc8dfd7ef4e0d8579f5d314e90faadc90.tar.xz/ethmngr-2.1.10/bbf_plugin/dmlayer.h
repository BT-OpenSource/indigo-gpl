/*
 * Copyright (C) 2019 iopsys Software Solutions AB
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation
 *
 *      Author: Amit Kumar <amit.kumar@iopsys.eu>
 *
 */

#ifndef DMLAYER__H
#define DMLAYER__H

#include "libbbfdm-api/dmcommon.h"

void ip___update_child_interfaces(char *device, char *option_name, char *option_value);
struct uci_section *ethernet___get_ethernet_interface_section(const char *device_name);
char *ethernet___get_ethernet_interface_name(char *device_name);
void ip___Update_IP_Interface_Layer(char *path, char *linker);
void ppp___Update_PPP_Interface_Layer(char *path, char *linker);
void ethernet___Update_MAC_VLAN_Layer(char *path, char *linker);
void ethernet___Update_VLAN_Termination_Layer(char *path, char *linker);
void ethernet___Update_Link_Top_Layers(char *path, char *linker);
void ethernet___Update_VLAN_Termination_Top_Layers(char *path, char *linker);
void ethernet___Update_MAC_VLAN_Top_Layers(char *path, char *linker);
#endif
