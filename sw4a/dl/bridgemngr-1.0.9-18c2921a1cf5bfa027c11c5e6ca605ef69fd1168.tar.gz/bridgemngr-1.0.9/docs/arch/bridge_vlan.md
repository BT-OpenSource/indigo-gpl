# TR-181 Bridge data-model

Aim of this document is to explain how Device.Bridging.Bridge.{i}.VLAN and VLANPort datamodel objects are mapped by the bbfdm backend to network UCI.

## Backends

There are two backends available for use, and they have to be selected at compile time:

### CONFIG_BRIDGEMNGR_BRIDGE_VLAN

This compile time flag determines which backend will be included.

- If this flag is set, then bridge-vlan sections will be configured for Device.Bridging.Bridge.{i}.VLAN and Device.Bridging.Bridge.{i}.VLANPort. objects.
- If this flag is not set, then device sections will be configured Device.Bridging.Bridge.{i}.VLAN and Device.Bridging.Bridge.{i}.VLANPort objects.

## Configuration

Traditional configuration has been explained in [network_depoyment_scenarios.md](https://dev.iopsys.eu/bbf/bbfdm/-/blob/devel/docs/guide/network_depoyment_scenarios.md).

- In traditional configuration: **one VLAN could be configured per bridge and multiple bridges were configured for multiple VLANs**
- In bridge-vlan configuration: **multiple VLANs can be configured per bridge**.

## Deployment Scenarios

- **NOTE**: Please adhere to the same order of object configuration as given in examples.
- Where the same LowerLayer ports are involved, it is necessary to use a single bridge and configure required vlans on the same bridge.

### 1. Transparent Bridge

```bash
obuspa -c del Device.DHCPv4.Client.*
obuspa -c del Device.DHCPv6.Client.*
obuspa -c del Device.Ethernet.Link.*
obuspa -c del Device.Ethernet.VLANTermination.*
obuspa -c del Device.Bridging.ProviderBridge.*
obuspa -c del Device.Bridging.Bridge.*
obuspa -c del Device.IP.Interface.*

obuspa -c add Device.IP.Interface.
obuspa -c add Device.DHCPv4.Client.
obuspa -c add Device.Ethernet.Link.
obuspa -c add Device.Bridging.Bridge.
obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c add Device.Bridging.Bridge.1.Port.

obuspa -c set Device.IP.Interface.1.Enable 1
obuspa -c set Device.IP.Interface.1.LowerLayers Device.Ethernet.Link.1

obuspa -c set Device.DHCPv4.Client.1.Enable 1
obuspa -c set Device.DHCPv4.Client.1.Interface Device.IP.Interface.1

obuspa -c set Device.Bridging.Bridge.1.Port.1.Enable 1
obuspa -c set Device.Bridging.Bridge.1.Port.2.Enable 1
obuspa -c set Device.Bridging.Bridge.1.Port.3.Enable 1
obuspa -c set Device.Bridging.Bridge.1.Port.4.Enable 1

obuspa -c set Device.Bridging.Bridge.1.Port.1.ManagementPort 1
obuspa -c set Device.Bridging.Bridge.1.Port.2.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.1.Port.3.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.1.Port.4.ManagementPort 0

obuspa -c set Device.Ethernet.Link.1.LowerLayers Device.Bridging.Bridge.1.Port.1

obuspa -c set Device.Bridging.Bridge.1.Port.2.LowerLayers Device.Ethernet.Interface.1
obuspa -c set Device.Bridging.Bridge.1.Port.3.LowerLayers Device.Ethernet.Interface.2
obuspa -c set Device.Bridging.Bridge.1.Port.4.LowerLayers Device.Ethernet.Interface.5

```

- **Network UCI Config**

```bash
/etc/config/network


config interface 'loopback'
	option device 'lo'
	option proto 'static'
	option ipaddr '127.0.0.1'
	option netmask '255.0.0.0'

config globals 'globals'
	option ula_prefix 'fde0:569b:7272::/48'

config device 'LAN1'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth0'
	option name 'eth0'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN2'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth1'
	option name 'eth1'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN3'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth2'
	option name 'eth2'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:40'

config device 'LAN4'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth3'
	option name 'eth3'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:40'

config device 'WAN'
	option pause '1'
	option rxpause '1'
	option txpause '1'
	option enabled '1'
	option ifname 'eth4'
	option name 'eth4'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config interface 'iface1'
	option proto 'dhcp'
	option disabled '0'
	option device 'br-dev1'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'dev_br1'
	option name 'br-dev1'
	option type 'bridge'
	option bridge_empty '1'
	option macaddr 'E8:C7:CF:AF:49:45'
	list ports 'eth0'
	list ports 'eth1'
	list ports 'eth4'
```

### 2. One VLAN per Service (Bridge mode)

- **NOTE:** In this scenario, with bridge-vlan implementation, we cannot create an untagged interface over WAN port because WAN port is part of bridge. However tagged interface, with the help of VLANTermination object can be created as before. Please refer VLANTrunk scenario for an example or visit [network_depoyment_scenarios.md](https://dev.iopsys.eu/bbf/bbfdm/-/blob/devel/docs/guide/network_depoyment_scenarios.md).

- **TR-181 Commands**

```bash
obuspa -c del Device.DHCPv4.Client.*
obuspa -c del Device.DHCPv6.Client.*
obuspa -c del Device.Ethernet.Link.*
obuspa -c del Device.Bridging.Bridge.*
obuspa -c del Device.IP.Interface.*

obuspa -c add Device.IP.Interface.
obuspa -c add Device.Ethernet.Link.
obuspa -c add Device.Bridging.Bridge.
obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c add Device.Bridging.Bridge.1.Port.

# In the default backend, we would have created another bridge over here
# With bridge-vlans we just add VLAN and VLANPort objects to the same bridge

obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c add Device.Bridging.Bridge.1.VLAN.
obuspa -c add Device.Bridging.Bridge.1.VLAN.
obuspa -c add Device.Bridging.Bridge.1.VLANPort.
obuspa -c add Device.Bridging.Bridge.1.VLANPort.
obuspa -c add Device.Bridging.Bridge.1.VLANPort.
obuspa -c add Device.Bridging.Bridge.1.VLANPort.

obuspa -c set Device.IP.Interface.1.Enable 1

obuspa -c set Device.IP.Interface.1.LowerLayers Device.Ethernet.Link.1

obuspa -c set Device.Bridging.Bridge.1.VLANPort.1.Enable 1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.2.Enable 1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.3.Enable 1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.4.Enable 1

obuspa -c set Device.Bridging.Bridge.1.VLANPort.1.Untagged 0
obuspa -c set Device.Bridging.Bridge.1.VLANPort.2.Untagged 0
obuspa -c set Device.Bridging.Bridge.1.VLANPort.3.Untagged 0
obuspa -c set Device.Bridging.Bridge.1.VLANPort.4.Untagged 0

obuspa -c set Device.Bridging.Bridge.1.VLANPort.1.VLAN Device.Bridging.Bridge.1.VLAN.1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.2.VLAN Device.Bridging.Bridge.1.VLAN.1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.3.VLAN Device.Bridging.Bridge.1.VLAN.2
obuspa -c set Device.Bridging.Bridge.1.VLANPort.4.VLAN Device.Bridging.Bridge.1.VLAN.2

obuspa -c set Device.Bridging.Bridge.1.Port.2.LowerLayers Device.Ethernet.Interface.1
obuspa -c set Device.Bridging.Bridge.1.Port.3.LowerLayers Device.Ethernet.Interface.2
obuspa -c set Device.Bridging.Bridge.1.Port.4.LowerLayers Device.Ethernet.Interface.5

obuspa -c set Device.Bridging.Bridge.1.VLAN.1.VLANID 100
obuspa -c set Device.Bridging.Bridge.1.VLAN.2.VLANID 200

obuspa -c set Device.Bridging.Bridge.1.Port.1.ManagementPort 1
obuspa -c set Device.Bridging.Bridge.1.Port.2.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.1.Port.3.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.1.Port.4.ManagementPort 0

obuspa -c set Device.Bridging.Bridge.1.Port.1.Enable 1
obuspa -c set Device.Bridging.Bridge.1.Port.2.Enable 1
obuspa -c set Device.Bridging.Bridge.1.Port.3.Enable 1
obuspa -c set Device.Bridging.Bridge.1.Port.4.Enable 1

obuspa -c set Device.Bridging.Bridge.1.VLANPort.1.Port Device.Bridging.Bridge.1.Port.2
obuspa -c set Device.Bridging.Bridge.1.VLANPort.2.Port Device.Bridging.Bridge.1.Port.4
obuspa -c set Device.Bridging.Bridge.1.VLANPort.3.Port Device.Bridging.Bridge.1.Port.3
obuspa -c set Device.Bridging.Bridge.1.VLANPort.4.Port Device.Bridging.Bridge.1.Port.4

obuspa -c set Device.Ethernet.Link.1.LowerLayers Device.Bridging.Bridge.1.Port.1
```

- **Network UCI Config**

```bash
# cat /etc/config/network

config interface 'loopback'
	option device 'lo'
	option proto 'static'
	option ipaddr '127.0.0.1'
	option netmask '255.0.0.0'

config globals 'globals'
	option ula_prefix 'fd49:f432:bb8b::/48'

config device 'LAN1'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth0'
	option name 'eth0'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:DD'

config device 'LAN2'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth1'
	option name 'eth1'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:DD'

config device 'LAN3'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth2'
	option name 'eth2'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:DE'

config device 'LAN4'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth3'
	option name 'eth3'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:D8'

config device 'WAN'
	option pause '1'
	option rxpause '1'
	option txpause '1'
	option enabled '1'
	option ifname 'eth4'
	option name 'eth4'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:DD'

config interface 'iface1'
	option proto 'none'
	option disabled '0'
	option device 'br-dev1'
	option macaddr 'E8:C7:CF:AF:49:DD'

config device 'dev_br1'
	option name 'br-dev1'
	option type 'bridge'
	option bridge_empty '1'
	option macaddr 'E8:C7:CF:AF:49:DD'
	list ports 'eth0'
	list ports 'eth1'
	list ports 'eth4'

config bridge-vlan 'br_1_vlan_1'
	option device 'br-dev1'
	option vlan '100'
	list ports 'eth0:t'
	list ports 'eth4:t'

config bridge-vlan 'br_1_vlan_2'
	option device 'br-dev1'
	option vlan '200'
	list ports 'eth1:t'
	list ports 'eth4:t'
```

### 3. One VLAN per Service (Route mode)

- **TR-181 Commands**

```bash
obuspa -c del Device.DHCPv4.Client.*
obuspa -c del Device.DHCPv6.Client.*
obuspa -c del Device.Ethernet.Link.*
obuspa -c del Device.Ethernet.VLANTermination.*
obuspa -c del Device.Bridging.Bridge.*
obuspa -c del Device.IP.Interface.*

obuspa -c add Device.IP.Interface.
obuspa -c add Device.IP.Interface.
obuspa -c add Device.IP.Interface.
obuspa -c add Device.IP.Interface.
obuspa -c add Device.DHCPv4.Client.
obuspa -c add Device.Ethernet.VLANTermination.
obuspa -c add Device.Ethernet.VLANTermination.
obuspa -c add Device.Ethernet.Link.
obuspa -c add Device.Ethernet.Link.
obuspa -c add Device.Bridging.Bridge.
obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c add Device.Bridging.Bridge.1.Port.

obuspa -c set Device.IP.Interface.1.Enable 1
obuspa -c set Device.IP.Interface.2.Enable 1
obuspa -c set Device.IP.Interface.3.Enable 1
obuspa -c set Device.IP.Interface.4.Enable 1

obuspa -c set Device.IP.Interface.1.LowerLayers Device.Ethernet.Link.1
obuspa -c set Device.IP.Interface.2.LowerLayers Device.Ethernet.VLANTermination.1
obuspa -c set Device.IP.Interface.3.LowerLayers Device.Ethernet.VLANTermination.2
obuspa -c set Device.IP.Interface.4.LowerLayers Device.Ethernet.Link.2

obuspa -c set Device.DHCPv4.Client.1.Enable 1
obuspa -c set Device.DHCPv4.Client.1.Interface Device.IP.Interface.4

obuspa -c set Device.Ethernet.VLANTermination.1.VLANID 100
obuspa -c set Device.Ethernet.VLANTermination.2.VLANID 200

obuspa -c set Device.Ethernet.Link.2.LowerLayers Device.Ethernet.Interface.5

obuspa -c set Device.Ethernet.VLANTermination.1.LowerLayers Device.Ethernet.Link.2
obuspa -c set Device.Ethernet.VLANTermination.2.LowerLayers Device.Ethernet.Link.2

obuspa -c set Device.Bridging.Bridge.1.Port.1.Enable 1
obuspa -c set Device.Bridging.Bridge.1.Port.2.Enable 1
obuspa -c set Device.Bridging.Bridge.1.Port.3.Enable 1

obuspa -c set Device.Bridging.Bridge.1.Port.1.ManagementPort 1
obuspa -c set Device.Bridging.Bridge.1.Port.2.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.1.Port.3.ManagementPort 0

obuspa -c set Device.Ethernet.Link.1.LowerLayers Device.Bridging.Bridge.1.Port.1

obuspa -c set Device.Bridging.Bridge.1.Port.2.LowerLayers Device.Ethernet.Interface.1
obuspa -c set Device.Bridging.Bridge.1.Port.3.LowerLayers Device.Ethernet.Interface.2
```

- **Network UCI Config**

```bash
cat /etc/config/network

config interface 'loopback'
	option device 'lo'
	option proto 'static'
	option ipaddr '127.0.0.1'
	option netmask '255.0.0.0'

config globals 'globals'
	option ula_prefix 'fde0:569b:7272::/48'

config device 'LAN1'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth0'
	option name 'eth0'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN2'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth1'
	option name 'eth1'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN3'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth2'
	option name 'eth2'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:48'

config device 'LAN4'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth3'
	option name 'eth3'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:40'

config device 'WAN'
	option pause '1'
	option rxpause '1'
	option txpause '1'
	option enabled '1'
	option ifname 'eth4'
	option name 'eth4'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:48'

config interface 'iface1'
	option proto 'none'
	option disabled '0'
	option device 'br-dev1'
	option macaddr 'E8:C7:CF:AF:49:45'

config interface 'iface2'
	option proto 'none'
	option disabled '0'
	option device 'eth4.100'
	option macaddr 'E8:C7:CF:AF:49:46'

config interface 'iface3'
	option proto 'none'
	option disabled '0'
	option device 'eth4.200'
	option macaddr 'E8:C7:CF:AF:49:47'

config interface 'iface4'
	option proto 'dhcp'
	option disabled '0'
	option device 'eth4'
	option macaddr 'E8:C7:CF:AF:49:48'

config device 'vlan_ter_1'
	option type '8021q'
	option vid '100'
	option ifname 'eth4'
	option name 'eth4.100'
	option macaddr 'E8:C7:CF:AF:49:46'

config device 'vlan_ter_2'
	option type '8021q'
	option vid '200'
	option ifname 'eth4'
	option name 'eth4.200'
	option macaddr 'E8:C7:CF:AF:49:47'

config device 'dev_br1'
	option name 'br-dev1'
	option type 'bridge'
	option bridge_empty '1'
	option macaddr 'E8:C7:CF:AF:49:45'
	list ports 'eth0'
	list ports 'eth1'


```

### 4. VLAN Trunking

- **TR-181 Commands**

```bash
# Setting up VLAN Trunk with bridge-vlan backend

obuspa -c del Device.DHCPv4.Client.*
obuspa -c del Device.DHCPv6.Client.*
obuspa -c del Device.Ethernet.Link.*
obuspa -c del Device.Bridging.Bridge.*
obuspa -c del Device.IP.Interface.*

obuspa -c add Device.Bridging.Bridge.

obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c set Device.Bridging.Bridge.1.Port.1.ManagementPort 1
obuspa -c set Device.Bridging.Bridge.1.Port.1.Enable 1

obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c set Device.Bridging.Bridge.1.Port.2.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.1.Port.2.LowerLayers Device.Ethernet.Interface.1
obuspa -c set Device.Bridging.Bridge.1.Port.2.Enable 1

obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c set Device.Bridging.Bridge.1.Port.3.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.1.Port.3.LowerLayers Device.Ethernet.Interface.2
obuspa -c set Device.Bridging.Bridge.1.Port.3.Enable 1

obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c set Device.Bridging.Bridge.1.Port.4.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.1.Port.4.LowerLayers Device.Ethernet.Interface.5
obuspa -c set Device.Bridging.Bridge.1.Port.4.Enable 1

obuspa -c add Device.Bridging.Bridge.1.VLAN.
obuspa -c set Device.Bridging.Bridge.1.VLAN.1.VLANID 100
obuspa -c add Device.Bridging.Bridge.1.VLANPort.
obuspa -c set Device.Bridging.Bridge.1.VLANPort.1.Enable 1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.1.VLAN Device.Bridging.Bridge.1.VLAN.1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.1.Port Device.Bridging.Bridge.1.Port.2

# With bridge-vlans, we explicitly have to set Untagged to 0 for a tagged port
obuspa -c set Device.Bridging.Bridge.1.VLANPort.1.Untagged 0

obuspa -c add Device.Bridging.Bridge.1.VLANPort.
obuspa -c set Device.Bridging.Bridge.1.VLANPort.2.Enable 1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.2.VLAN Device.Bridging.Bridge.1.VLAN.1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.2.Port Device.Bridging.Bridge.1.Port.3

# With bridge-vlans, we explicitly have to set Untagged to 0 for a tagged port
obuspa -c set Device.Bridging.Bridge.1.VLANPort.2.Untagged 0

obuspa -c add Device.Bridging.Bridge.1.VLANPort.
obuspa -c set Device.Bridging.Bridge.1.VLANPort.3.Enable 1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.3.VLAN Device.Bridging.Bridge.1.VLAN.1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.3.Port Device.Bridging.Bridge.1.Port.4

# With bridge-vlans, we explicitly have to set Untagged to 0 for a tagged port
obuspa -c set Device.Bridging.Bridge.1.VLANPort.3.Untagged 0

# In the default backend, we would have created another bridge over here
# With bridge-vlans we just add VLAN and VLANPort objects to the same bridge

obuspa -c add Device.Bridging.Bridge.1.VLAN.
obuspa -c set Device.Bridging.Bridge.1.VLAN.2.VLANID 200

obuspa -c add Device.Bridging.Bridge.1.VLANPort.
obuspa -c set Device.Bridging.Bridge.1.VLANPort.4.Enable 1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.4.Untagged 0
obuspa -c set Device.Bridging.Bridge.1.VLANPort.4.VLAN Device.Bridging.Bridge.1.VLAN.2
obuspa -c set Device.Bridging.Bridge.1.VLANPort.4.Port Device.Bridging.Bridge.1.Port.2

obuspa -c add Device.Bridging.Bridge.1.VLANPort.
obuspa -c set Device.Bridging.Bridge.1.VLANPort.5.Enable 1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.5.Untagged 0
obuspa -c set Device.Bridging.Bridge.1.VLANPort.5.VLAN Device.Bridging.Bridge.1.VLAN.2
obuspa -c set Device.Bridging.Bridge.1.VLANPort.5.Port Device.Bridging.Bridge.1.Port.3

obuspa -c add Device.Bridging.Bridge.1.VLANPort.
obuspa -c set Device.Bridging.Bridge.1.VLANPort.6.Enable 1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.6.Untagged 0
obuspa -c set Device.Bridging.Bridge.1.VLANPort.6.VLAN Device.Bridging.Bridge.1.VLAN.2
obuspa -c set Device.Bridging.Bridge.1.VLANPort.6.Port Device.Bridging.Bridge.1.Port.4

obuspa -c add Device.Ethernet.Link.
obuspa -c set Device.Ethernet.Link.1.LowerLayers Device.Bridging.Bridge.1.Port.1

obuspa -c add Device.Ethernet.Link.
obuspa -c set Device.Ethernet.Link.2.LowerLayers Device.Ethernet.Interface.5

# Note that VLANTermination works similarly in both backends
obuspa -c add Device.Ethernet.VLANTermination
obuspa -c set Device.Ethernet.VLANTermination.1.VLANID 300
obuspa -c set Device.Ethernet.VLANTermination.1.LowerLayers Device.Ethernet.Link.2

obuspa -c add Device.IP.Interface.
obuspa -c set Device.IP.Interface.1.Enable 1
obuspa -c set Device.IP.Interface.1.LowerLayers Device.Ethernet.Link.1

obuspa -c add Device.IP.Interface.
obuspa -c set Device.IP.Interface.2.Enable 1
obuspa -c set Device.IP.Interface.2.LowerLayers Device.Ethernet.VLANTermination.1

obuspa -c add Device.DHCPv4.Client.
obuspa -c set Device.DHCPv4.Client.1.Enable 1
obuspa -c set Device.DHCPv4.Client.1.Interface Device.IP.Interface.2
```

- **Network UCI Config**

```bash
root@sh40j-e8c7cfaf49d8:~# cat /etc/config/network

config interface 'loopback'
	option device 'lo'
	option proto 'static'
	option ipaddr '127.0.0.1'
	option netmask '255.0.0.0'

config globals 'globals'
	option ula_prefix 'fd82:6f1a:084c::/48'

config device 'LAN1'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth0'
	option name 'eth0'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:DD'

config device 'LAN2'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth1'
	option name 'eth1'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:DD'

config device 'LAN3'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth2'
	option name 'eth2'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:DD'

config device 'LAN4'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth3'
	option name 'eth3'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:D8'

config device 'WAN'
	option pause '1'
	option rxpause '1'
	option txpause '1'
	option enabled '1'
	option ifname 'eth4'
	option name 'eth4'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:DE'

config device 'dev_br1'
	option name 'br-dev1'
	option type 'bridge'
	option bridge_empty '1'
	list ports 'eth0'
	list ports 'eth1'
	list ports 'eth4'
	option macaddr 'E8:C7:CF:AF:49:DD'

# bridge-vlan section for vlan 100
config bridge-vlan 'br_1_vlan_1'
	option device 'br-dev1'
	option vlan '100'
	list ports 'eth0:t'
	list ports 'eth1:t'
	list ports 'eth4:t'

# bridge-vlan section for vlan 200
config bridge-vlan 'br_1_vlan_2'
	option device 'br-dev1'
	option vlan '200'
	list ports 'eth0:t'
	list ports 'eth1:t'
	list ports 'eth4:t'

config device 'vlan_ter_1'
	option type '8021q'
	option vid '300'
	option ifname 'eth4'
	option name 'eth4.300'
	option macaddr 'E8:C7:CF:AF:49:DE'

config interface 'iface1'
	option proto 'none'
	option disabled '0'
	option device 'br-dev1'
	option macaddr 'E8:C7:CF:AF:49:DD'

config interface 'iface2'
	option proto 'dhcp'
	option disabled '0'
	option device 'eth4.300'
	option macaddr 'E8:C7:CF:AF:49:DE'
```

- **Bridge VLAN configuration**

```bash
root@sh40j-e8c7cfaf49d8:~# bridge v
port	      vlan-id
eth0		100
		200
eth1		100
		200
eth4 		100
		200
br-dev1		100
		200
```

### 5. One VLAN per Customer(MACVLAN over tagged interface)

- **TR-181 Commands**

```bash
obuspa -c del Device.DHCPv4.Client.*
obuspa -c del Device.DHCPv6.Client.*
obuspa -c del Device.Ethernet.Link.*
obuspa -c del Device.Ethernet.VLANTermination.*
obuspa -c del Device.Bridging.Bridge.*
obuspa -c del Device.IP.Interface.*

obuspa -c add Device.IP.Interface.
obuspa -c add Device.IP.Interface.
obuspa -c add Device.DHCPv4.Client.
obuspa -c add Device.DHCPv4.Client.
obuspa -c add Device.Ethernet.X_IOPSYS_EU_MACVLAN.
obuspa -c add Device.Ethernet.X_IOPSYS_EU_MACVLAN.
obuspa -c add Device.Ethernet.VLANTermination.
obuspa -c add Device.Ethernet.Link.

obuspa -c set Device.IP.Interface.1.Enable 1
obuspa -c set Device.IP.Interface.2.Enable 1

obuspa -c set Device.IP.Interface.1.LowerLayers Device.Ethernet.X_IOPSYS_EU_MACVLAN.1
obuspa -c set Device.IP.Interface.2.LowerLayers Device.Ethernet.X_IOPSYS_EU_MACVLAN.2

obuspa -c set Device.DHCPv4.Client.1.Enable 1
obuspa -c set Device.DHCPv4.Client.2.Enable 1

obuspa -c set Device.DHCPv4.Client.1.Interface Device.IP.Interface.1
obuspa -c set Device.DHCPv4.Client.2.Interface Device.IP.Interface.2

obuspa -c set Device.Ethernet.Link.1.LowerLayers Device.Ethernet.Interface.3

obuspa -c set Device.Ethernet.VLANTermination.1.VLANID 100
obuspa -c set Device.Ethernet.VLANTermination.1.LowerLayers Device.Ethernet.Link.1

obuspa -c set Device.Ethernet.X_IOPSYS_EU_MACVLAN.1.LowerLayers Device.Ethernet.VLANTermination.1
obuspa -c set Device.Ethernet.X_IOPSYS_EU_MACVLAN.2.LowerLayers Device.Ethernet.VLANTermination.1

```

- **Network UCI Config**

```bash
icat /etc/config/network

config interface 'loopback'
	option device 'lo'
	option proto 'static'
	option ipaddr '127.0.0.1'
	option netmask '255.0.0.0'

config globals 'globals'
	option ula_prefix 'fde0:569b:7272::/48'

config device 'LAN1'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth0'
	option name 'eth0'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN2'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth1'
	option name 'eth1'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN3'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth2'
	option name 'eth2'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:48'

config device 'LAN4'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth3'
	option name 'eth3'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:40'

config device 'WAN'
	option pause '1'
	option rxpause '1'
	option txpause '1'
	option enabled '1'
	option ifname 'eth4'
	option name 'eth4'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config interface 'iface1'
	option proto 'dhcp'
	option disabled '0'
	option device 'eth4_1'
	option macaddr 'E8:C7:CF:AF:49:45'

config interface 'iface2'
	option proto 'dhcp'
	option disabled '0'
	option device 'eth4_2'
	option macaddr 'E8:C7:CF:AF:49:46'

config device 'mac_vlan_1'
	option type 'macvlan'
	option ifname 'eth4.100'
	option name 'eth4_1'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'mac_vlan_2'
	option type 'macvlan'
	option ifname 'eth4.100'
	option name 'eth4_2'
	option macaddr 'E8:C7:CF:AF:49:46'

config device 'vlan_ter_1'
	option type '8021q'
	option vid '100'
	option ifname 'eth4'
	option name 'eth4.100'
```

### 6. One VLAN per Customer(MACVLAN over untagged interface)

- **TR-181 Commands**

```bash
obuspa -c del Device.DHCPv4.Client.*
obuspa -c del Device.DHCPv6.Client.*
obuspa -c del Device.Ethernet.Link.*
obuspa -c del Device.Ethernet.VLANTermination.*
obuspa -c del Device.Ethernet.X_IOPSYS_EU_MACVLAN.*
obuspa -c del Device.Bridging.Bridge.*
obuspa -c del Device.IP.Interface.*

obuspa -c add Device.IP.Interface.
obuspa -c add Device.IP.Interface.
obuspa -c add Device.Ethernet.X_IOPSYS_EU_MACVLAN.
obuspa -c add Device.Ethernet.X_IOPSYS_EU_MACVLAN.
obuspa -c add Device.Ethernet.Link.

obuspa -c set Device.IP.Interface.1.Enable 1
obuspa -c set Device.IP.Interface.2.Enable 1

obuspa -c set Device.IP.Interface.1.LowerLayers Device.Ethernet.X_IOPSYS_EU_MACVLAN.1
obuspa -c set Device.IP.Interface.2.LowerLayers Device.Ethernet.X_IOPSYS_EU_MACVLAN.2

obuspa -c set Device.Ethernet.Link.1.LowerLayers Device.Ethernet.Interface.5

obuspa -c set Device.Ethernet.X_IOPSYS_EU_MACVLAN.1.LowerLayers Device.Ethernet.Link.1
obuspa -c set Device.Ethernet.X_IOPSYS_EU_MACVLAN.2.LowerLayers Device.Ethernet.Link.1

obuspa -c add Device.DHCPv4.Client.
obuspa -c set Device.DHCPv4.Client.1.Enable 1
obuspa -c set Device.DHCPv4.Client.1.Interface Device.IP.Interface.1

obuspa -c add Device.DHCPv4.Client.
obuspa -c set Device.DHCPv4.Client.2.Enable 1
obuspa -c set Device.DHCPv4.Client.2.Interface Device.IP.Interface.2

```

- **Network UCI Config**

```bash
cat /etc/config/network

config interface 'loopback'
	option device 'lo'
	option proto 'static'
	option ipaddr '127.0.0.1'
	option netmask '255.0.0.0'

config globals 'globals'
	option ula_prefix 'fde0:569b:7272::/48'

config device 'LAN1'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth0'
	option name 'eth0'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN2'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth1'
	option name 'eth1'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN3'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth2'
	option name 'eth2'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:48'

config device 'LAN4'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth3'
	option name 'eth3'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:40'

config device 'WAN'
	option pause '1'
	option rxpause '1'
	option txpause '1'
	option enabled '1'
	option ifname 'eth4'
	option name 'eth4'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config interface 'iface1'
	option proto 'dhcp'
	option disabled '0'
	option device 'eth4_1'
	option macaddr 'E8:C7:CF:AF:49:45'

config interface 'iface2'
	option proto 'dhcp'
	option disabled '0'
	option device 'eth4_2'
	option macaddr 'E8:C7:CF:AF:49:46'

config device 'mac_vlan_1'
	option type 'macvlan'
	option ifname 'eth4'
	option name 'eth4_1'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'mac_vlan_2'
	option type 'macvlan'
	option ifname 'eth4'
	option name 'eth4_2'
	option macaddr 'E8:C7:CF:AF:49:46'
```

### 7. VLAN Translation

**This scenario is not supported for bridge vlan backend**.

### 8. Managed Bridge

**This scenario is not supported for bridge vlan backend**.

### 9. QinQ lan untagged to wan double tagged (Bridge mode)

- **TR-181 Commands**

```bash
obuspa -c del Device.DHCPv4.Client.*
obuspa -c del Device.DHCPv6.Client.*
obuspa -c del Device.Ethernet.Link.*
obuspa -c del Device.Ethernet.VLANTermination.*
obuspa -c del Device.Bridging.ProviderBridge.*
obuspa -c del Device.Bridging.Bridge.*
obuspa -c del Device.IP.Interface.*

obuspa -c add Device.Bridging.Bridge.
obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c set Device.Bridging.Bridge.1.Port.1.ManagementPort 1
obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c set Device.Bridging.Bridge.1.Port.2.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.1.Port.2.LowerLayers Device.Ethernet.Interface.1
obuspa -c set Device.Bridging.Bridge.1.Port.2.Enable 1

obuspa -c add Device.Bridging.Bridge.
obuspa -c add Device.Bridging.Bridge.2.Port.
obuspa -c set Device.Bridging.Bridge.2.Port.1.ManagementPort 1
obuspa -c add Device.Bridging.Bridge.2.Port.
obuspa -c set Device.Bridging.Bridge.2.Port.2.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.2.Port.2.LowerLayers Device.Ethernet.Interface.2
obuspa -c set Device.Bridging.Bridge.2.Port.2.Enable 1

obuspa -c add Device.Bridging.Bridge.
obuspa -c add Device.Bridging.Bridge.3.Port.
obuspa -c set Device.Bridging.Bridge.3.Port.1.ManagementPort 1
obuspa -c add Device.Bridging.Bridge.3.Port.
obuspa -c set Device.Bridging.Bridge.3.Port.2.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.3.Port.2.LowerLayers Device.Ethernet.Interface.5
obuspa -c set Device.Bridging.Bridge.3.Port.2.Enable 1

obuspa -c add Device.Bridging.Bridge.3.VLAN.
obuspa -c set Device.Bridging.Bridge.3.VLAN.1.VLANID 100

obuspa -c add Device.Bridging.Bridge.3.VLANPort.
obuspa -c set Device.Bridging.Bridge.3.VLANPort.1.Enable 1
obuspa -c set Device.Bridging.Bridge.3.VLANPort.1.VLAN Device.Bridging.Bridge.3.VLAN.1
obuspa -c set Device.Bridging.Bridge.3.VLANPort.1.Port Device.Bridging.Bridge.3.Port.2

obuspa -c add Device.Bridging.Bridge.
obuspa -c add Device.Bridging.Bridge.4.Port.
obuspa -c set Device.Bridging.Bridge.4.Port.1.ManagementPort 1
obuspa -c add Device.Bridging.Bridge.4.Port.
obuspa -c set Device.Bridging.Bridge.4.Port.2.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.4.Port.2.TPID 34984
obuspa -c set Device.Bridging.Bridge.4.Port.2.LowerLayers Device.Bridging.Bridge.3.Port.2
obuspa -c set Device.Bridging.Bridge.4.Port.2.Enable 1

obuspa -c add Device.Bridging.Bridge.4.VLAN.
obuspa -c set Device.Bridging.Bridge.4.VLAN.1.VLANID 200

obuspa -c add Device.Bridging.Bridge.4.VLANPort.
obuspa -c set Device.Bridging.Bridge.4.VLANPort.1.Enable 1
obuspa -c set Device.Bridging.Bridge.4.VLANPort.1.VLAN Device.Bridging.Bridge.4.VLAN.1
obuspa -c set Device.Bridging.Bridge.4.VLANPort.1.Port Device.Bridging.Bridge.4.Port.2

obuspa -c add  Device.Bridging.ProviderBridge.
obuspa -c set Device.Bridging.ProviderBridge.1.CVLANcomponents Device.Bridging.Bridge.1,Device.Bridging.Bridge.2
obuspa -c set Device.Bridging.ProviderBridge.1.SVLANcomponent Device.Bridging.Bridge.4
```

- **Network UCI Config**

```bash
cat /etc/config/network

config interface 'loopback'
	option device 'lo'
	option proto 'static'
	option ipaddr '127.0.0.1'
	option netmask '255.0.0.0'

config globals 'globals'
	option ula_prefix 'fd16:d69b:c19b::/48'

config device 'LAN1'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth0'
	option name 'eth0'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN2'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth1'
	option name 'eth1'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN3'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth2'
	option name 'eth2'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:46'

config device 'LAN4'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth3'
	option name 'eth3'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:40'

config device 'WAN'
	option pause '1'
	option rxpause '1'
	option txpause '1'
	option enabled '1'
	option ifname 'eth4'
	option name 'eth4'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:47'

config interface 'iface_br1'
	option device 'br-dev1'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'pr_br_1'
	option name 'br-dev1'
	option type 'bridge'
	option bridge_empty '1'
	option macaddr 'E8:C7:CF:AF:49:45'
	list ports 'eth0'
	list ports 'eth1'
	list ports 'eth4.100.200'

config device 'eth4_100'
	option type '8021q'
	option vid '100'
	option ifname 'eth4'
	option name 'eth4.100'
	option macaddr 'E8:C7:CF:AF:49:48'

config device 'br_4_dev_1'
	option type '8021ad'
	option ifname 'eth4.100'
	option name 'eth4.100.200'
	option vid '200'
	option macaddr 'E8:C7:CF:AF:49:45'

```

### 10. QinQ lan single tagged to wan double tagged (Bridge mode)

- **TR-181 Commands**

```bash
obuspa -c del Device.DHCPv4.Client.*
obuspa -c del Device.DHCPv6.Client.*
obuspa -c del Device.Ethernet.Link.*
obuspa -c del Device.Ethernet.VLANTermination.*
obuspa -c del Device.Ethernet.X_IOPSYS_EU_MACVLAN.*
obuspa -c del Device.Bridging.ProviderBridge.*
obuspa -c del Device.Bridging.Bridge.*
obuspa -c del Device.IP.Interface.*

obuspa -c add Device.Bridging.Bridge.
obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c set Device.Bridging.Bridge.1.Port.1.ManagementPort 1
obuspa -c add Device.Bridging.Bridge.1.Port.
obuspa -c set Device.Bridging.Bridge.1.Port.2.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.1.Port.2.LowerLayers Device.Ethernet.Interface.1
obuspa -c set Device.Bridging.Bridge.1.Port.2.Enable 1

obuspa -c add Device.Bridging.Bridge.1.VLAN.
obuspa -c set Device.Bridging.Bridge.1.VLAN.1.VLANID 100

obuspa -c add Device.Bridging.Bridge.1.VLANPort.
obuspa -c set Device.Bridging.Bridge.1.VLANPort.1.Enable 1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.1.Untagged 0
obuspa -c set Device.Bridging.Bridge.1.VLANPort.1.VLAN Device.Bridging.Bridge.1.VLAN.1
obuspa -c set Device.Bridging.Bridge.1.VLANPort.1.Port Device.Bridging.Bridge.1.Port.2

obuspa -c add Device.Bridging.Bridge.
obuspa -c add Device.Bridging.Bridge.2.Port.
obuspa -c set Device.Bridging.Bridge.2.Port.1.ManagementPort 1
obuspa -c add Device.Bridging.Bridge.2.Port.
obuspa -c set Device.Bridging.Bridge.2.Port.2.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.2.Port.2.LowerLayers Device.Ethernet.Interface.2
obuspa -c set Device.Bridging.Bridge.2.Port.2.Enable 1

obuspa -c add Device.Bridging.Bridge.2.VLAN.
obuspa -c set Device.Bridging.Bridge.2.VLAN.1.VLANID 100

obuspa -c add Device.Bridging.Bridge.2.VLANPort.
obuspa -c set Device.Bridging.Bridge.2.VLANPort.1.Enable 1
obuspa -c set Device.Bridging.Bridge.2.VLANPort.1.Untagged 0
obuspa -c set Device.Bridging.Bridge.2.VLANPort.1.VLAN Device.Bridging.Bridge.2.VLAN.1
obuspa -c set Device.Bridging.Bridge.2.VLANPort.1.Port Device.Bridging.Bridge.2.Port.2

obuspa -c add Device.Bridging.Bridge.
obuspa -c add Device.Bridging.Bridge.3.Port.
obuspa -c set Device.Bridging.Bridge.3.Port.1.ManagementPort 1
obuspa -c add Device.Bridging.Bridge.3.Port.
obuspa -c set Device.Bridging.Bridge.3.Port.2.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.3.Port.2.LowerLayers Device.Ethernet.Interface.5
obuspa -c set Device.Bridging.Bridge.3.Port.2.Enable 1

obuspa -c add Device.Bridging.Bridge.3.VLAN.
obuspa -c set Device.Bridging.Bridge.3.VLAN.1.VLANID 100

obuspa -c add Device.Bridging.Bridge.3.VLANPort.
obuspa -c set Device.Bridging.Bridge.3.VLANPort.1.Enable 1
obuspa -c set Device.Bridging.Bridge.3.VLANPort.1.Untagged 0
obuspa -c set Device.Bridging.Bridge.3.VLANPort.1.VLAN Device.Bridging.Bridge.3.VLAN.1
obuspa -c set Device.Bridging.Bridge.3.VLANPort.1.Port Device.Bridging.Bridge.3.Port.2

obuspa -c add Device.Bridging.Bridge.
obuspa -c add Device.Bridging.Bridge.4.Port.
obuspa -c set Device.Bridging.Bridge.4.Port.1.ManagementPort 1
obuspa -c add Device.Bridging.Bridge.4.Port.
obuspa -c set Device.Bridging.Bridge.4.Port.2.ManagementPort 0
obuspa -c set Device.Bridging.Bridge.4.Port.2.TPID 34984
obuspa -c set Device.Bridging.Bridge.4.Port.2.LowerLayers Device.Bridging.Bridge.3.Port.2
obuspa -c set Device.Bridging.Bridge.4.Port.2.Enable 1

obuspa -c add Device.Bridging.Bridge.4.VLAN.
obuspa -c set Device.Bridging.Bridge.4.VLAN.1.VLANID 300

obuspa -c add Device.Bridging.Bridge.4.VLANPort.
obuspa -c set Device.Bridging.Bridge.4.VLANPort.1.Enable 1
obuspa -c set Device.Bridging.Bridge.4.VLANPort.1.Untagged 0
obuspa -c set Device.Bridging.Bridge.4.VLANPort.1.VLAN Device.Bridging.Bridge.4.VLAN.1
obuspa -c set Device.Bridging.Bridge.4.VLANPort.1.Port Device.Bridging.Bridge.4.Port.2

obuspa -c add  Device.Bridging.ProviderBridge.

obuspa -c set Device.Bridging.ProviderBridge.1.CVLANcomponents Device.Bridging.Bridge.1,Device.Bridging.Bridge.2

obuspa -c set Device.Bridging.ProviderBridge.1.SVLANcomponent Device.Bridging.Bridge.4
```

- **Network UCI Config**

```bash
cat /etc/config/network

config interface 'loopback'
	option device 'lo'
	option proto 'static'
	option ipaddr '127.0.0.1'
	option netmask '255.0.0.0'

config globals 'globals'
	option ula_prefix 'fde0:569b:7272::/48'

config device 'LAN1'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth0'
	option name 'eth0'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN2'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth1'
	option name 'eth1'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN3'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth2'
	option name 'eth2'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:48'

config device 'LAN4'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth3'
	option name 'eth3'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:40'

config device 'WAN'
	option pause '1'
	option rxpause '1'
	option txpause '1'
	option enabled '1'
	option ifname 'eth4'
	option name 'eth4'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:46'

config interface 'iface_br1'
	option device 'br-dev1'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'pr_br_1'
	option name 'br-dev1'
	option type 'bridge'
	option bridge_empty '1'
	option macaddr 'E8:C7:CF:AF:49:45'
	list ports 'eth0'
	list ports 'eth1'
	list ports 'eth4.100.300'

config bridge-vlan 'br_1_vlan_1'
	option device 'br-dev1'
	option vlan '100'
	list ports 'eth0:t'
	list ports 'eth1:t'
	list ports 'eth4.100.300'

config device 'eth4_100'
	option type '8021q'
	option vid '100'
	option ifname 'eth4'
	option name 'eth4.100'
	option macaddr 'E8:C7:CF:AF:49:48'

config device 'br_4_dev_1'
	option type '8021ad'
	option ifname 'eth4.100'
	option name 'eth4.100.300'
	option vid '300'
	option macaddr 'E8:C7:CF:AF:49:45'

```

### 11. QinQ (Route mode)

- **TR-181 Commands**

```bash
obuspa -c del Device.DHCPv4.Client.*
obuspa -c del Device.DHCPv6.Client.*
obuspa -c del Device.Ethernet.Link.*
obuspa -c del Device.Bridging.ProviderBridge.*
obuspa -c del Device.Bridging.Bridge.*
obuspa -c del Device.IP.Interface.*

obuspa -c add Device.IP.Interface.
obuspa -c add Device.DHCPv4.Client.
obuspa -c add Device.Ethernet.VLANTermination.
obuspa -c add Device.Ethernet.VLANTermination.
obuspa -c add Device.Ethernet.Link.

obuspa -c set Device.IP.Interface.1.Enable 1
obuspa -c set Device.IP.Interface.1.LowerLayers Device.Ethernet.VLANTermination.2

obuspa -c set Device.DHCPv4.Client.1.Enable 1
obuspa -c set Device.DHCPv4.Client.1.Interface Device.IP.Interface.1

obuspa -c set Device.Ethernet.Link.1.LowerLayers Device.Ethernet.Interface.3

obuspa -c set Device.Ethernet.VLANTermination.1.VLANID 100
obuspa -c set Device.Ethernet.VLANTermination.1.LowerLayers Device.Ethernet.Link.1

obuspa -c set Device.Ethernet.VLANTermination.2.TPID 34984
obuspa -c set Device.Ethernet.VLANTermination.2.VLANID 200
obuspa -c set Device.Ethernet.VLANTermination.2.LowerLayers Device.Ethernet.VLANTermination.1

```

- **Network UCI Config**

```bash
cat /etc/config/network

config interface 'loopback'
	option device 'lo'
	option proto 'static'
	option ipaddr '127.0.0.1'
	option netmask '255.0.0.0'

config globals 'globals'
	option ula_prefix 'fde0:569b:7272::/48'

config device 'LAN1'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth0'
	option name 'eth0'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN2'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth1'
	option name 'eth1'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:45'

config device 'LAN3'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth2'
	option name 'eth2'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:48'

config device 'LAN4'
	option pause '0'
	option rxpause '0'
	option txpause '0'
	option enabled '1'
	option ifname 'eth3'
	option name 'eth3'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:40'

config device 'WAN'
	option pause '1'
	option rxpause '1'
	option txpause '1'
	option enabled '1'
	option ifname 'eth4'
	option name 'eth4'
	option eee '0'
	option macaddr 'E8:C7:CF:AF:49:46'

config interface 'iface_br1'
	option device 'br-dev1'
	option macaddr 'E8:C7:CF:AF:49:45'

config interface 'iface1'
	option proto 'dhcp'
	option disabled '0'
	option device 'eth2.100.200'
	option macaddr 'E8:C7:CF:AF:49:46'

config device 'vlan_ter_1'
	option type '8021q'
	option vid '100'
	option ifname 'eth2'
	option name 'eth2.100'

config device 'vlan_ter_2'
	option type '8021ad'
	option vid '200'
	option ifname 'eth2.100'
	option name 'eth2.100.200'
	option macaddr 'E8:C7:CF:AF:49:46'
```

## Bridge-vlan limitations

- There are some limitations for the ProviderBridge scenario with bridge-vlan backend. Let us assume there are two vlans in our system 100 and 200.

- **Driver level vlan (default) backend**

```bash
config device
	option type 'bridge'
	option name 'br-dev1'
	list ports 'eth0.100'
	list ports 'eth4.100'

config device
	option type 'bridge'
	option name 'br-dev1'
	list ports 'eth0.200'
	list ports 'eth4.200'
```

- **Bridge vlan backend**

```bash
config device
	option type 'bridge'
	option name 'br-dev1'
	list ports 'eth0'
	list ports 'eth4'

config bridge-vlan
	option device 'br-dev1'
	option vlan '100'
	list ports 'eth0:t'
	list ports 'eth4:t'

config bridge-vlan
	option device 'br-dev1'
	option vlan '200'
	list ports 'eth0:t'
	list ports 'eth4:t'
```

- So the difference is that bridge-vlan backend uses only one bridge, and there are multiple vlans on same bridge.

- Therefore, if a port Device.Bridging.Bridge.{i}.Port.{i} is passed as LowerLayer to another Device.Bridging.Bridge.{j}.Port.{j}.,
  then Device.Bridging.Bridge.{i}. should only have one vlan present in it.

## PVID

Device.Bridging.Bridge.{i}.Port.{i}.PVID works when a bridge port is part of a bridge-vlan. The port then behaves as follows:

- If an untagged frame arrives at this port, it will be assigned to the VLAN denoted by PVID.
- PVID will only work with untagged port.
- One port can have PVID set for only one VLAN.

- **TR-181 Excerpt**

```bash
# assuming the previous VLAN Trunk configuration was present
# make the port Untagged (not necessary but better to do)
obuspa -c set Device.Bridging.Bridge.1.VLANPort.4.Untagged 1
# set the PVID
obuspa -c set Device.Bridging.Bridge.1.Port.2.PVID 200
```

- **Network UCI Excerpt**
```bash
config bridge-vlan 'br_1_vlan_1'
	option device 'br-dev1'
	option vlan '100'
	list ports 'eth0:t'
	list ports 'eth1:t'
	list ports 'eth4:t'

# configuration has updated for vlan 200 bridge-vlan section
config bridge-vlan 'br_1_vlan_2'
	option device 'br-dev1'
	option vlan '200'
	list ports 'eth1:t'
	list ports 'eth4:t'
	list ports 'eth0:u*'
```

## More information

For more information on bridge-vlans, please visit the following openwrt pages:

- [Converting to DSA](https://openwrt.org/docs/guide-user/network/dsa/converting-to-dsa#untagged_tagged_and_pvid)
- [DSA mini tutorial](https://openwrt.org/docs/guide-user/network/dsa/dsa-mini-tutorial)
