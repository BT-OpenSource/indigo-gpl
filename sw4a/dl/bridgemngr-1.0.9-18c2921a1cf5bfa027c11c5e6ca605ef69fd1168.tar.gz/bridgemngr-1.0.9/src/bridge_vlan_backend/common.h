/*
 * Copyright (C) 2024 iopsys Software Solutions AB
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation
 *
 *		Author: Amin Ben Romdhane <amin.benromdhane@iopsys.eu>
 *
 */

#ifndef __COMMON_H
#define __COMMON_H

#include "libbbfdm-api/dmcommon.h"

void ethernet___Update_Link_Layer(const char *path, const char *linker);

bool bridging___is_management_port_instance(struct uci_section *device_sec);

#endif //__COMMON_H
