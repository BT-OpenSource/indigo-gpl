# Bridge Manager

This package provides Device.Bridging. datamodel objects to manage the Bridge Interfaces, Ports and VLANs on CPE.