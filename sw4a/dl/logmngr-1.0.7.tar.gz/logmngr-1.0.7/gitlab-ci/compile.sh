#!/bin/bash

echo "Install dependencies"
orig_dir=$(pwd)
echo $orig_dir

source ./gitlab-ci/shared.sh

apt update
apt install -y python3-pip

# install bbfdm
install_bbfdm

# compile
set -e
echo "build stage"
cd $orig_dir/bbf_plugin/
pwd
make
