# Log Manager

This package contains code for the Device.Syslog. object.

This package support 2 backend, namely, fluent-bit and syslog-ng. The logmngr package
abstracts the config and data model implemenation of the backend. The backend package
can be selected at compilation time by setting the corresponding config option.

The config option LOGMNGR_BACKEND_FLUENTBIT selects fluent-bit as the backend and is
the current iowrt default. The other config option present is LOGMNGR_BACKEND_SYSLOG_NG
which selects syslog-ng as the backend and can be alternatively selected.

Please read more about the uci config at:
https://dev.iopsys.eu/system/logmngr/-/blob/devel/docs/guide/uci_config_guide.md

The details of data model parameters available and their map to uci is available at:
https://dev.iopsys.eu/system/logmngr/-/blob/devel/docs/arch/dm2uci.md
