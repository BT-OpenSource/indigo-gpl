/*
 * Copyright (C) 2024 iopsys Software Solutions AB
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation
 *
 *	Author: Mohd Husaam Mehdi <husaam.mehdi@genexis.eu>
 */

#ifndef __SYSLOG_H
#define __SYSLOG_H

#include <libbbfdm_api.h>
#include <libbbfdm-api/dmcommon.h>

#include "common.h"

extern DMOBJ tSyslogObj[];
extern DMLEAF tSyslogParams[];
extern DMLEAF tSyslogFilterParams[];
extern DMOBJ tSyslogSourceObj[];
extern DMLEAF tSyslogSourceParams[];
extern DMLEAF tSyslogSourceNetworkParams[];
extern DMLEAF tSyslogTemplateParams[];
extern DMOBJ tSyslogActionObj[];
extern DMLEAF tSyslogActionParams[];
extern DMLEAF tSyslogActionLogFileParams[];
extern DMLEAF tSyslogActionLogRemoteParams[];


#endif //__SYSLOG_H

