extern char *FacilityLevel[];
extern char *Severity[];
extern char *SeverityCompare[];
extern char *SeverityCompareAction[];
extern char *Protocol[];
extern char *Compression[];
extern char *vendor_log_dir[];
