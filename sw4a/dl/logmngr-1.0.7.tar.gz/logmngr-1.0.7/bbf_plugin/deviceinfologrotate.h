/*
 * Copyright (C) 2024 iopsys Software Solutions AB
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation
 *
 *	Author: Rahul Thakur <rahul.thakur@iopsys.eu>
 */

#ifndef __DEVICEINFOLOGROTATE_H
#define __DEVICEINFOLOGROTATE_H

#include <libbbfdm_api.h>
#include <libbbfdm-api/dmcommon.h>

#include "common.h"

extern DMLEAF tLogRotateNumberofEntries[];
extern DMOBJ tDeviceInfoLogRotateObj[];
extern DMLEAF tDeviceInfoLogRotateParams[];
extern DMOBJ tLogRotateLogFileObj[];
extern DMLEAF tDeviceInfoLogRotateLogFileParams[];

#endif //__DEVICEINFOLOGROTATE_H

