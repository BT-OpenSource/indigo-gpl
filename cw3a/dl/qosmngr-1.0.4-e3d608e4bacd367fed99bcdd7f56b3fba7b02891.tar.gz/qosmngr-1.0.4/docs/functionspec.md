# Function Specification

After ubus starts the qos methods can be invoked to get the queue information

```
root@iopsys:~# ubus call qos queue_stats '{"ifname":"eth0", "qid": 5}'
{
        "queues": [
                {
                        "qid": 5,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                }
        ]
}
```

For all available queue_stats the command can be used without parameters, such as

```
root@iopsys:~# ubus call qos queue_stats 
{
        "queues": [
                {
                        "qid": 0,
                        "iface": "eth1",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 1,
                        "iface": "eth1",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 2,
                        "iface": "eth1",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 3,
                        "iface": "eth1",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 4,
                        "iface": "eth1",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 5,
                        "iface": "eth1",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 6,
                        "iface": "eth1",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 7,
                        "iface": "eth1",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 0,
                        "iface": "eth2",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 1,
                        "iface": "eth2",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 2,
                        "iface": "eth2",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 3,
                        "iface": "eth2",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 4,
                        "iface": "eth2",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 5,
                        "iface": "eth2",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 6,
                        "iface": "eth2",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 7,
                        "iface": "eth2",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 0,
                        "iface": "eth3",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 1,
                        "iface": "eth3",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 2,
                        "iface": "eth3",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 3,
                        "iface": "eth3",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 4,
                        "iface": "eth3",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 5,
                        "iface": "eth3",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 6,
                        "iface": "eth3",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 7,
                        "iface": "eth3",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 0,
                        "iface": "eth4",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 1,
                        "iface": "eth4",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 2,
                        "iface": "eth4",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 3,
                        "iface": "eth4",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 4,
                        "iface": "eth4",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 5,
                        "iface": "eth4",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 6,
                        "iface": "eth4",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 7,
                        "iface": "eth4",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 0,
                        "iface": "eth0",
                        "tx_packets": 624,
                        "tx_bytes": 165216,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 1,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 2,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 3,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 4,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 5,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 6,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 7,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                }
        ]
}
```

We can call ubus for specific port such as : 


```
root@iopsys:~# ubus call qos queue_stats '{"ifname":"eth0"}'
{
        "queues": [
                {
                        "qid": 0,
                        "iface": "eth0",
                        "tx_packets": 543,
                        "tx_bytes": 143418,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 1,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 2,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 3,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 4,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 5,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 6,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                },
                {
                        "qid": 7,
                        "iface": "eth0",
                        "tx_packets": 0,
                        "tx_bytes": 0,
                        "tx_dropped_packets": 0,
                        "tx_dropped_bytes": 0
                }
        ]
}
```
