#!/bin/bash

echo "install dependencies"

pwd

# libqos
cd /opt/dev  
rm -fr easy-soc-libs  
git clone https://dev.iopsys.eu/iopsys/easy-soc-libs.git  
cd easy-soc-libs  
cd libeasy  
make CFLAGS+="-I/usr/include/libnl3"  
mkdir -p /usr/include/easy  
cp easy.h event.h utils.h if_utils.h debug.h /usr/include/easy  
cp -a libeasy*.so* /usr/lib  
cd ../libqos  
make PLATFORM=TEST
cp qos.h /usr/include  
cp -a libqos.so* /usr/lib  
sudo ldconfig
