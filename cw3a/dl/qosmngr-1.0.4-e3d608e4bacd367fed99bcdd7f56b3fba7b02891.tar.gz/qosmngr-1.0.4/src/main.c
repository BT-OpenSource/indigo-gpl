/* SPDX-License-Identifier: GPL-2.0 */
/*
 * main.c - qosmngr's boilerplate and entry point
 *
 * Copyright (C) 2020 iopsys Software Solutions AB. All rights reserved.
 *
 * Author: Oskar Viljasaar <oskar.viljasaar@iopsys.eu>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 */

#include <stdio.h>
#include <stdlib.h>

#include <libubus.h>

#include "qosmngr.h"
#include "version.h"

const char *ubus_socket;

struct ubus_context *ctx = NULL;

const struct blobmsg_policy get_status_policy[NUM_QOS_POLICY] = {
      [QOS_POLICY_IFNAME] = { .name = "ifname", .type = BLOBMSG_TYPE_STRING },
      [QOS_POLICY_QID] = { .name = "qid", .type = BLOBMSG_TYPE_INT32},
};

static const struct ubus_method qos_methods[] = {
        UBUS_METHOD("queue_stats", qosmngr_get_stats, get_status_policy),
};

static struct ubus_object_type qos_object_type =
        UBUS_OBJECT_TYPE("qos", qos_methods);

static struct ubus_object test_object = {
        .name = "qos",
        .type = &qos_object_type,
        .methods = qos_methods,
        .n_methods = ARRAY_SIZE(qos_methods),
};

/**
 *  To get the qosmngr version
 *  @param : none
 *  return : none
 */
void qosmngr_version()
{
	syslog(LOG_ERR, "version       : %s.%s\n", qosmngr_base_version, qosmngr_xtra_version);
}

/**
 *  To expose the qosmngr object on ubus i.e., qos with method queue_stats
 *  @param ctx input parameter pointer to ubus context
 *  retrun integer value 0 on success and -1 on failure
 */
static int qosmngr_publish_object(struct ubus_context *ctx)
{
	int ret;
	ret = ubus_add_object(ctx, &test_object);
	if (ret) {
		syslog(LOG_ERR, "Failed to add 'qos' ubus object: %s\n",
			ubus_strerror(ret));
	}

	return ret;
}

/**
 *  Main function for qosmngr, everything starts here
 *  @param argc input number of input arguments
 *  @param argv input double pointer array of optional command line arguments
 *  retrun integer value 0 on success and -1 on failure
 */
int main(int argc, char **argv)
{
	int ret;
	int ch;

	/* Logging to syslog */
	openlog("qosmngr", LOG_PID|LOG_CONS, LOG_LOCAL1);

	while ((ch = getopt(argc, argv, "vs:e:")) != -1) {
		switch (ch) {
		case 'v':
			qosmngr_version();
			exit(0);
		case 's':
			ubus_socket = optarg;
			break;
		default:
			break;
		}
	}

	argc -= optind;
	argv += optind;

	uloop_init();
	ctx = ubus_connect(ubus_socket);
	if (!ctx) {
		syslog(LOG_ERR, "Failed to connect to ubus\n");
		return -1;
	}

	ubus_add_uloop(ctx);

	ret = qosmngr_publish_object(ctx);
	if (ret)
		goto out;

	/* Main loop of qosmngr */
	uloop_run();

 out:
	ubus_free(ctx);
	uloop_done();

	return 0;
}
