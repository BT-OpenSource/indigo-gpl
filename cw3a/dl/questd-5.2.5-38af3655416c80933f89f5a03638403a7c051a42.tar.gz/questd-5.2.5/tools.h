#ifndef QUESTD_TOOLS_H
#define QUESTD_TOOLS_H 1

#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#include <uci.h>

#include "common.h"

void remove_newline(char *buf);
char *single_space(char *str);
char *trim(char *str);
void remove_char(char *buf, char a);
void runCmd(const char *format, ...);
char *chrCmd(char *output, size_t output_size, const char *format, ...);
struct uci_package * init_package(struct uci_context **ctx, const char *config);
void free_uci_context(struct uci_context **ctx);
#endif /* QUESTD_TOOLS_H */
