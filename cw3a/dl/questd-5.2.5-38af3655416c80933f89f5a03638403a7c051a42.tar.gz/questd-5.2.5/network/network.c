
/*
 * network -- provides router.network object of questd
 *
 * Copyright (C) 2019-2020 IOPSYS Software Solutions AB. All rights reserved.
 *
 * Author: sukru.senli@iopsys.eu, jakob.olsson@iopsys.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 */

#include <libubox/blobmsg_json.h>
#include <libubox/blobmsg.h>
#include <libubus.h>
#include <uci.h>

#include <pthread.h>
#include <limits.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <net/if.h>
#include <sys/ioctl.h>

#include <dirent.h>
#include <time.h>

#include "network.h"
#include "tools.h"

extern int quest_add_object(struct ubus_object *obj);

static pthread_t tid[1];
pthread_attr_t attr;
int netpt;

static pthread_mutex_t assocl_lock;

static struct uci_context *uci_ctx;
static struct uci_package *uci_network, *uci_wireless;

static Network network[MAX_NETWORK];
static Host hosts[MAX_CLIENT];
static Client clients[MAX_CLIENT];
static Client clients_old[MAX_CLIENT];
static Client clients_new[MAX_CLIENT];

static Client *client_main_t = (Client *) clients;
static Client *client_worker_t = (Client *) clients_new;

static ActiveChange active_change[MAX_CLIENT];

static bool
wdev_already_there(const char *ifname, const char *wdev)
{
	bool ret = false;
	char *token;
	char ifbuf[128];
	char *saveptr;

	strncpy(ifbuf, ifname, 128);

	token = strtok_r(ifbuf, " ", &saveptr);
	while (token != NULL) {
		if (strcmp(token, wdev) == 0) {
			ret = true;
			break;
		}
		token = strtok_r(NULL, " ", &saveptr);
	}

	return ret;
}

static void
get_wireless_ifnames(char *netname, const char *ifname, char *wifs)
{
	struct uci_element *e;
	struct uci_section *s;
	const char *device = NULL;
	const char *network = NULL;
	const char *wdev = NULL;
	char wrl[64];

	memset(wrl, '\0', sizeof(wrl));

	uci_foreach_element(&uci_wireless->sections, e) {
		s = uci_to_section(e);

		if (strcmp(s->type, "wifi-iface") == 0) {
			device = uci_lookup_option_string(uci_ctx, s, "device");
			if (!device)
				continue;
			network = uci_lookup_option_string(uci_ctx, s, "network");
			if (network && strcmp(network, netname) == 0) {

				wdev = uci_lookup_option_string(uci_ctx, s, "ifname");

				if (!wdev || wdev_already_there(ifname, wdev))
					continue;

				strcat(wrl, " ");
				strncat(wrl, wdev, 8);
				strncpy(wifs, wrl, 63);
			}
		}
	}
}

static void
populate_network_interfaces()
{
	struct uci_element *e;
	const char *is_lan = NULL;
	const char *type = NULL;
	const char *defaultroute = NULL;
	const char *proto = NULL;
	const char *ipaddr = NULL;
	const char *netmask = NULL;
	const char *ifname = NULL;
	bool haswl = false;
	char wifs[64] = {0};
	int nno = 0;

	memset(network, '\0', sizeof(network));
	uci_wireless = init_package(&uci_ctx, "wireless");
	if (uci_wireless)
		haswl = true;

	// Populate network interfaces from UCI network config interface section. UCI wireless
	// config is also interacted with to fetch the wireless ifnames into network ifnames
	uci_network = init_package(&uci_ctx, "network");
	if (uci_network) {
		uci_foreach_element(&uci_network->sections, e) {
			struct uci_section *s = uci_to_section(e);

			if (nno >= MAX_NETWORK)
				return;
			network[nno].exists = false;
			if (strcmp(s->type, "interface") == 0) {
				is_lan = uci_lookup_option_string(uci_ctx, s, "is_lan");
				defaultroute = uci_lookup_option_string(uci_ctx, s, "defaultroute");
				type = uci_lookup_option_string(uci_ctx, s, "type");
				proto = uci_lookup_option_string(uci_ctx, s, "proto");
				ipaddr = uci_lookup_option_string(uci_ctx, s, "ipaddr");
				netmask = uci_lookup_option_string(uci_ctx, s, "netmask");
				ifname = uci_lookup_option_string(uci_ctx, s, "ifname");
				if (!(ifname))
					ifname = "";
				memset(wifs, '\0', sizeof(wifs));
				if (haswl)
					get_wireless_ifnames(s->e.name, ifname, wifs);
				if ((ifname && strncmp(ifname, "lo", 2) != 0) || strlen(wifs) > 0) {
					network[nno].exists = true;
					if (is_lan && strcmp(is_lan, "1") == 0)
						network[nno].is_lan = true;
					strncpy(network[nno].name, s->e.name, sizeof(network[nno].name));
					if (defaultroute && strcmp(defaultroute, "0") == 0)
						network[nno].defaultroute = false;
					else
						network[nno].defaultroute = true;
					strncpy(network[nno].type, type ? type : "", sizeof(network[nno].type));
					strncpy(network[nno].proto, proto ? proto : "", sizeof(network[nno].proto));
					if (proto && strcmp(network[nno].proto, "static") == 0) {
						strncpy(network[nno].ipaddr, ipaddr ? ipaddr : "", sizeof(network[nno].ipaddr));
						strncpy(network[nno].netmask, netmask ? netmask : "", sizeof(network[nno].netmask));
					}
					if (strlen(wifs) > 0)
						snprintf(network[nno].ifname, 128, "%s%s", ifname, wifs);
					else
						strncpy(network[nno].ifname, ifname, 128);
					nno++;
				}
			}
		}
		free_uci_context(&uci_ctx);
	}
}

static int
active_connections(char *ipaddr)
{
	FILE *f;
	int i;
	char *p, line[512];
	char *saveptr;
	int connum = 0;

	f = fopen("/proc/net/nf_conntrack", "r");

	if (f != NULL) {
		while (fgets(line, sizeof(line) - 1, f)) {
			for (i = 0, p = strtok_r(line, " ", &saveptr); p; i++, p = strtok_r(NULL, " ", &saveptr)) {
				if (i == 6 && strcmp(p+4, ipaddr) == 0)
					connum++;
			}
		}

		fclose(f);
	}

	return connum;
}

static void
match_client_to_network(Network *lan, char *ipaddr, bool *local, char *net, char *dev)
{
	if (!lan->ipaddr || !lan->netmask)
		return;

	struct in_addr ip, mask, snet, host, rslt;

	inet_pton(AF_INET, lan->ipaddr, &(ip.s_addr));
	inet_pton(AF_INET, lan->netmask, &(mask.s_addr));
	inet_pton(AF_INET, ipaddr, &(host.s_addr));

	snet.s_addr = (ip.s_addr & mask.s_addr);
	rslt.s_addr = (host.s_addr & mask.s_addr);

	if ((snet.s_addr ^ rslt.s_addr) == 0) {
		*local = true;
		snprintf(net, 32, "%s", lan->name);
		if (lan->type && strcmp(lan->type, "bridge") == 0)
			snprintf(dev, 32, "br-%s", lan->name);
		else
			strncpy(dev, lan->ifname, 32);
	}
}

void
get_device_address(char *device, char *ipaddr, char *netmask)
{
	struct ifreq ifr;
	int sock_fd;

	sock_fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);

	memset(&ifr, 0, sizeof(ifr));
	ifr.ifr_addr.sa_family = AF_INET;
	strncpy(ifr.ifr_name, device, IF_NAMESIZE);

	if (ioctl(sock_fd, SIOCGIFADDR, &ifr, sizeof(ifr)) < 0) {
		close(sock_fd);
		return;
	}

	snprintf(ipaddr, 24, "%s", inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));

	if (ioctl(sock_fd, SIOCGIFNETMASK, &ifr, sizeof(ifr)) < 0) {
		close(sock_fd);
		return;
	}

	snprintf(netmask, 24, "%s", inet_ntoa(((struct sockaddr_in *)&ifr.ifr_netmask)->sin_addr));
	close(sock_fd);
}

static void
get_network_info(Client *clnt)
{
	int ip[4];
	int netno;
	char device[16];

	clnt->local = false;

	if (sscanf(clnt->ipaddr, "%d.%d.%d.%d", &ip[0], &ip[1], &ip[2], &ip[3]) == 4) {
		for (netno = 0; netno < MAX_NETWORK && network[netno].exists; netno++) {
			if (network[netno].is_lan) {
				match_client_to_network(&network[netno], clnt->ipaddr, &clnt->local, clnt->network, clnt->device);
				if (clnt->local)
					break;
			} else if (strcmp(network[netno].type, "bridge") == 0) {
				snprintf(device, 16, "br-%s", network[netno].name);
				get_device_address(device, network[netno].ipaddr, network[netno].netmask);
				match_client_to_network(&network[netno], clnt->ipaddr, &clnt->local, clnt->network, clnt->device);
				if (clnt->local)
					break;
			}
		}
	}
}

static unsigned long long
get_netdev_stats(char *device, char *stat)
{
	FILE *snfile;
	char sysnet[256];
	unsigned long long val = 0;

	snprintf(sysnet, 128, "/sys/class/net/%s/statistics/%s", device, stat);

	snfile = fopen(sysnet, "r");
	if (NULL != snfile) {
		fscanf(snfile, "%llu", &val);
		fclose(snfile);
	}

	return val;
}

static void
get_ethernet_interface(Host *host, char *bridge, int clportno)
{
	if (clportno == 0)
		return;

	DIR *dir;
	struct dirent *ent;
	FILE *pfile;
	char path_brif[256];
	char path_portno[512];
	int pno = 0;

	snprintf(path_brif, 256, "/sys/class/net/%s/brif/", bridge);

	dir = opendir(path_brif);

	if (dir != NULL) {
		while ((ent = readdir(dir)) != NULL) {
			if (ent->d_name[0] == '.')
				continue;

			snprintf(path_portno, 512, "/%s/%s/port_no", path_brif, ent->d_name);
			pfile = fopen(path_portno, "r");

			if (pfile != NULL) {
				fscanf(pfile, "0x%d", &pno);
				fclose(pfile);
			}

			if (pno != 0 && clportno == pno) {
				strncpy(host->device, ent->d_name, 16);
				break;
			}
		}
		closedir(dir);
	}
}

static void
get_ipv6_address(Host *host)
{
	FILE *odhcpd;
	char line[1024];
	char hostname[65];
	char ip6addr[129];
	int idx = 0;

	//TODO: Read leases file from dhcp.@odhcpd[0].leasefile
	odhcpd = fopen("/tmp/hosts/odhcpd", "r");
	if (odhcpd != NULL) {
		while (fgets(line, sizeof(line), odhcpd) != NULL) {
			remove_newline(line);

			sscanf(line, "%128s %64s", ip6addr, hostname);

			if (strcmp(hostname, host->hostname) == 0) {
				strncpy(host->ipv6addr[idx], ip6addr, 128);
				idx++;
			}
		}
		fclose(odhcpd);
	}
}

static void
get_dhcp_options(Host *host)
{
	FILE *opts;
	char line[2048];
	char macaddr[25];
	char vcid[129];
	char clid[129];
	char ucid[129];

	/* /var/dhcp.client.options format */
	/* <MACADDR> vcid=<VENDOR_CLASS_ID> clid=<CLIENT_ID> ucid=<USER_CLASS_ID> */
	/* vcid: Option 60, clid: Option 61, ucid: Option 77 */
	opts = fopen("/var/dhcp.client.options", "r");

	if (opts != NULL) {
		while (fgets(line, sizeof(line), opts) != NULL) {
			remove_newline(line);

			sscanf(line, "%24s vcid=%128s clid=%128s ucid=%128s",
					macaddr,
					vcid,
					clid,
					ucid);

			if (strncmp(macaddr, host->macaddr, 24) == 0) {
				if (strcmp(vcid, "-") != 0)
					strncpy(host->dhcpopts.vcid, vcid, 128);

				if (strcmp(clid, "-") != 0)
					strncpy(host->dhcpopts.clid, clid, 128);

				if (strcmp(ucid, "-") != 0)
					strncpy(host->dhcpopts.ucid, ucid, 128);

				break;
			}
		}
		fclose(opts);
	}
}

static unsigned int
get_active_last_change(char *macaddr)
{
	unsigned int time = 0;
	int i;

	for (i = 0; i < MAX_CLIENT; i++) {
		if (strncmp(active_change[i].macaddr, macaddr, 24) == 0) {
			time = active_change[i].time;
			break;
		}
	}

	return time;
}

void
router_dump_hosts(struct blob_buf *b)
{
	int num = 1;
	int i, j;
	void *a, *ip4, *ip6, *d, *t, *s;

	a = blobmsg_open_array(b, "hosts");
	for (i = 0; i < MAX_CLIENT; i++) {
		if (!hosts[i].exists)
			continue;

		t = blobmsg_open_table(b, "");

		blobmsg_add_string(b, "macaddr", hosts[i].macaddr);
		blobmsg_add_string(b, "ipaddr", hosts[i].ipaddr);
		blobmsg_add_string(b, "addrsrc", hosts[i].addrsrc);
		blobmsg_add_u32(b, "leasetmrmn", hosts[i].leasetmrmn);
		blobmsg_add_string(b, "device", hosts[i].device);
		blobmsg_add_string(b, "network", hosts[i].network);
		blobmsg_add_string(b, "type", hosts[i].type);
		blobmsg_add_string(b, "hostname", hosts[i].hostname);
		blobmsg_add_u8(b, "active", hosts[i].active);
		blobmsg_add_u32(b, "activelstch", hosts[i].activelstch);
		blobmsg_add_u32(b, "activeconns", hosts[i].activeconns);

		d = blobmsg_open_table(b, "dhcpopts");
		blobmsg_add_string(b, "vcid", hosts[i].dhcpopts.vcid);
		blobmsg_add_string(b, "clid", hosts[i].dhcpopts.clid);
		blobmsg_add_string(b, "ucid", hosts[i].dhcpopts.ucid);
		blobmsg_close_table(b, d);

		ip4 = blobmsg_open_array(b, "ipv4addr");
		for (j = 0; j < 8; j++)
			if (hosts[i].ipv4addr[j][0] != '\0')
				blobmsg_add_string(b, "", hosts[i].ipv4addr[j]);
		blobmsg_close_array(b, ip4);

		ip6 = blobmsg_open_array(b, "ipv6addr");
		for (j = 0; j < 8; j++)
			if (hosts[i].ipv6addr[j][0] != '\0')
				blobmsg_add_string(b, "", hosts[i].ipv6addr[j]);
		blobmsg_close_array(b, ip6);

		s = blobmsg_open_table(b, "stats");
		blobmsg_add_u64(b, "tx_packets", hosts[i].stats.tx_packets);
		blobmsg_add_u64(b, "tx_bytes", hosts[i].stats.tx_bytes);
		blobmsg_add_u64(b, "rx_packets", hosts[i].stats.rx_packets);
		blobmsg_add_u64(b, "rx_bytes", hosts[i].stats.rx_bytes);
		blobmsg_close_table(b, s);

		blobmsg_close_table(b, t);

		num++;
	}
	blobmsg_close_array(b, a);
}

void
populate_hosts_from_clients(void)
{
	int num = 1;
	int i;

	// Here we walk through the clients array and fill the hosts
	// array with data expected by TR-181 Device.Hosts object.

	memset(hosts, '\0', sizeof(hosts));

	for (i = 0; i < MAX_CLIENT; i++) {
		if (!client_main_t[i].exists) {
			hosts[i].exists = false;
			continue;
		}

		hosts[i].exists = true;
		strncpy(hosts[i].macaddr, client_main_t[i].macaddr, 24);
		strncpy(hosts[i].ipaddr, client_main_t[i].ipaddr, 24);
		if (client_main_t[i].dhcp) {
			hosts[i].addrsrc = "dhcp";
			hosts[i].leasetmrmn = client_main_t[i].leasetime - (int)time(NULL);
		} else {
			hosts[i].addrsrc = "static";
			hosts[i].leasetmrmn = 0;
		}
		strncpy(hosts[i].network, client_main_t[i].network, 32);
		hosts[i].type = (client_main_t[i].wireless)?"wifi":"ethernet";
		strncpy(hosts[i].hostname, client_main_t[i].hostname, 64);
		hosts[i].active = client_main_t[i].connected;
		hosts[i].activelstch = get_active_last_change(hosts[i].macaddr);
		hosts[i].activeconns = client_main_t[i].activeconns;

		strncpy(hosts[i].ipv4addr[1], client_main_t[i].ipaddr, 24);

		if (client_main_t[i].wireless)
			strncpy(hosts[i].device, client_main_t[i].wdev, 16);
		else if (strstr(client_main_t[i].device, "br-"))
			get_ethernet_interface(&hosts[i], client_main_t[i].device, client_main_t[i].brportno);
		else
			strncpy(hosts[i].device, client_main_t[i].device, 16);

		get_dhcp_options(&hosts[i]);
		get_ipv6_address(&hosts[i]);

		if (client_main_t[i].wireless) {
			hosts[i].stats.tx_bytes = client_main_t[i].tx_bytes;
			hosts[i].stats.rx_bytes = client_main_t[i].rx_bytes;
			hosts[i].stats.tx_packets = client_main_t[i].tx_packets;
			hosts[i].stats.rx_packets = client_main_t[i].rx_packets;
		} else {
			/* TODO: Fix */
			// This assumes one client is connected to one LAN port.
			// It does not consider the cases where there is a switch behind
			// a LAN port and multiple clients behind the switch
			hosts[i].stats.tx_bytes = get_netdev_stats(hosts[i].device, "rx_bytes");
			hosts[i].stats.rx_bytes = get_netdev_stats(hosts[i].device, "tx_bytes");
			hosts[i].stats.tx_packets = get_netdev_stats(hosts[i].device, "rx_packets");
			hosts[i].stats.rx_packets = get_netdev_stats(hosts[i].device, "tx_packets");
		}

		num++;
	}
}

static void
router_dump_clients(struct blob_buf *b)
{
	char clid[24];
	int num = 1;
	int i;
	void *t;

	for (i = 0; i < MAX_CLIENT; i++) {
		if (!client_main_t[i].exists)
			continue;

		snprintf(clid, 24, "%s", client_main_t[i].macaddr);

		remove_char(clid, ':');

		t = blobmsg_open_table(b, clid);

		blobmsg_add_string(b, "hostname", client_main_t[i].hostname);
		blobmsg_add_string(b, "ipaddr", client_main_t[i].ipaddr);
		blobmsg_add_string(b, "macaddr", client_main_t[i].macaddr);
		blobmsg_add_string(b, "network", client_main_t[i].network);
		blobmsg_add_string(b, "device", client_main_t[i].device);
		blobmsg_add_u8(b, "dhcp", client_main_t[i].dhcp);
		if (client_main_t[i].dhcp)
			blobmsg_add_u64(b, "leasetime", client_main_t[i].leasetime);
		blobmsg_add_u8(b, "ipv6", client_main_t[i].ipv6);
		if (client_main_t[i].ipv6) {
			blobmsg_add_string(b, "ip6addr", client_main_t[i].ip6addr);
			blobmsg_add_string(b, "duid", client_main_t[i].duid);
			blobmsg_add_u64(b, "lease6time", client_main_t[i].lease6time);
		}
		blobmsg_add_u8(b, "connected", client_main_t[i].connected);
		if (client_main_t[i].connected)
			blobmsg_add_u32(b, "active_connections", client_main_t[i].activeconns);

		blobmsg_add_u8(b, "wireless", client_main_t[i].wireless);
		if (client_main_t[i].wireless) {
			blobmsg_add_string(b, "wdev", client_main_t[i].wdev);
			blobmsg_add_string(b, "frequency", client_main_t[i].frequency);
			blobmsg_add_u32(b, "rssi", client_main_t[i].rssi);
			blobmsg_add_u32(b, "snr", client_main_t[i].snr);
			blobmsg_add_u32(b, "idle", client_main_t[i].idle);
			blobmsg_add_u32(b, "in_network", client_main_t[i].in_network);
			blobmsg_add_u64(b, "tx_bytes", client_main_t[i].tx_bytes);
			blobmsg_add_u64(b, "rx_bytes", client_main_t[i].rx_bytes);
		}

		blobmsg_close_table(b, t);

		num++;
	}
}

static bool
wireless_sta(Client *clnt)
{
	bool wireless = false;
	char access_points[128] = {0};
	char station[2048] = {0};
	char macaddr[24] = {0};
	char rssi[8] = {0};
	char snr[8] = {0};
	char idle[8] = {0};
	char in_network[8] = {0};
	char tx_bytes[32] = {0};
	char rx_bytes[32] = {0};
	char tx_packets[32] = {0};
	char rx_packets[32] = {0};

	char *vif;
	char *saveptr;

	// To understand if the client is a wireless station,
	// we query wifi.ap.<VIF> objects to see if any of the
	// Access Points have the client MAC Address among their
	// associated stations. If the client is a wireless sta, we
	// also fill wireless specific information for the client.

	//TODO: Use ubus C API instead of bash.
	chrCmd(access_points, 128, "ubus -t 1 list wifi.ap.* | cut -d'.' -f'3,4' | tr '\n' ' '");

	vif = strtok_r(access_points, " ", &saveptr);
	while (vif != NULL) {
		memset(station, 0, 2048);
		memset(macaddr, 0, 24);
		memset(clnt->wdev, 0, 8);
		memset(clnt->frequency, 0, 8);
		memset(rssi, 0, 8);
		memset(snr, 0, 8);
		memset(idle, 0, 8);
		memset(in_network, 0, 8);
		memset(tx_bytes, 0, 32);
		memset(rx_bytes, 0, 32);
		memset(tx_packets, 0, 32);
		memset(rx_packets, 0, 32);

		chrCmd(station, 2048, "ubus -S -t 1 call wifi.ap.%s stations '{\"sta\":\"%s\"}'", vif, clnt->macaddr);
		chrCmd(macaddr, 24, "jsonfilter -s '%s' -e @.stations[0].macaddr", station);

		if (strlen(macaddr) > 8) {
			wireless = true;

			chrCmd(clnt->wdev, 8, "jsonfilter -s '%s' -e @.stations[0].wdev", station);
			chrCmd(clnt->frequency, 8, "jsonfilter -s '%s' -e @.stations[0].frequency", station);
			chrCmd(rssi, 8, "jsonfilter -s '%s' -e @.stations[0].rssi", station);
			chrCmd(snr, 8, "jsonfilter -s '%s' -e @.stations[0].snr", station);
			chrCmd(idle, 8, "jsonfilter -s '%s' -e @.stations[0].idle", station);
			chrCmd(in_network, 8, "jsonfilter -s '%s' -e @.stations[0].in_network", station);
			chrCmd(tx_bytes, 32, "jsonfilter -s '%s' -e @.stations[0].stats.tx_total_bytes", station);
			chrCmd(rx_bytes, 32, "jsonfilter -s '%s' -e @.stations[0].stats.rx_data_bytes", station);
			chrCmd(tx_packets, 32, "jsonfilter -s '%s' -e @.stations[0].stats.tx_total_pkts", station);
			chrCmd(rx_packets, 32, "jsonfilter -s '%s' -e @.stations[0].stats.rx_data_pkts", station);

			clnt->rssi = atoi(rssi);
			clnt->snr = atoi(snr);
			clnt->idle = atoi(idle);
			clnt->in_network = atoi(in_network);
			clnt->tx_bytes = atoll(tx_bytes);
			clnt->rx_bytes = atoll(rx_bytes);
			clnt->tx_packets = atoll(tx_packets);
			clnt->rx_packets = atoll(rx_packets);

			break;
		}

		vif = strtok_r(NULL, " ", &saveptr);
	}

	return wireless;
}

static void
append_dhcpv6_info(Client *clnt)
{
	FILE *hosts6;
	char line[512];
	char hostname[65];
	char device[33];
	char duid[65];
	long lease6time;
	char ip6addr[129];
	char *ptr;
	int iaid, id, length;

	clnt->ipv6 = false;
	hosts6 = fopen("/tmp/hosts/odhcpd", "r");
	if (NULL != hosts6) {
		while (fgets(line, sizeof(line), hosts6) != NULL) {
			remove_newline(line);
			if (sscanf(line, "# %32s %64s %x %64s %ld %x %d %128s", device, duid, &iaid, hostname, &lease6time, &id, &length, ip6addr)) {
				// Here we want to get the first IPv6 Address only
				ptr = strchr(ip6addr, '/');
				if (ptr != NULL)
					*ptr = '\0';
				// Here we do the matching based on hostname, however it would be more reliable to make the matching
				// based on macaddr which would require us to ndisc6 query the ip6addr, get the macaddr from the query
				// result and compare the macaddr value with the client macaddr.
				if (strcasecmp(clnt->hostname, hostname) == 0) {
					clnt->ipv6 = true;
					strncpy(clnt->ip6addr, ip6addr, 128);
					strncpy(clnt->duid, duid, 64);
					clnt->lease6time = lease6time;
					break;
				}
			}
		}
		fclose(hosts6);
	}
}

static void
append_dhcpv4_info(Client *clnt)
{
	FILE *leases;
	char line[256];
	long leasetime;
	char macaddr[25];
	char ipaddr[25];
	char hostname[65];
	char clid[257];

	//TODO: Read leases file from dhcp.@dnsmasq[0].leasefile
	leases = fopen("/var/dhcp.leases", "r");
	if (leases != NULL) {
		while (fgets(line, sizeof(line), leases) != NULL) {
			remove_newline(line);
			if (sscanf(line, "%ld %24s %24s %64s %256s", &leasetime, macaddr, ipaddr, hostname, clid) == 5) {
				if (strcasecmp(clnt->macaddr, macaddr) == 0 && strcasecmp(clnt->ipaddr, ipaddr) == 0) {
					clnt->dhcp = true;
					clnt->leasetime = leasetime;
					strncpy(clnt->hostname, hostname, 64);
					strncpy(clnt->ipaddr, ipaddr, 24);
					break;
				}
			}
		}
		fclose(leases);
	}
}

static void
get_hostname_from_config(const char *mac_in, char *hostname)
{
	struct uci_element *e;
	static struct uci_package *uci_dhcp;
	struct uci_section *s;
	const char *mac = NULL;
	const char *hname = NULL;

	uci_dhcp = init_package(&uci_ctx, "dhcp");
	if (uci_dhcp) {
		uci_foreach_element(&uci_dhcp->sections, e) {
			s = uci_to_section(e);

			if (strcmp(s->type, "host") == 0) {
				mac = uci_lookup_option_string(uci_ctx, s, "mac");
				if (mac && strcasecmp(mac, mac_in) == 0) {
					hname = uci_lookup_option_string(uci_ctx, s, "name");
					if (hname)
						strncpy(hostname, hname, 64);
				}
			}
		}
		free_uci_context(&uci_ctx);
	}
}

void
get_bridge_info(Client *clnt)
{
	char brinfo[16];
	int aging, timer;

	aging = 255;
	clnt->brportno = 0;
	if (strstr(clnt->device, "br-")) {
		chrCmd(brinfo, 16, "brctl showmacs %s | grep %s | awk '{print$1\":\"$4}'", clnt->device, clnt->macaddr);
		sscanf(brinfo, "%d:%d.%d", &clnt->brportno, &aging, &timer);
	}

	// If Aging Timer value is 30 or above, we assume the client is disconnected.
	// The reason we have the comparison value as 30 is to detect client connection status changes
	// earlier than 255 seconds which is when a disconnected client is removed from bridge entry.
	// The other alternative is to ping the client to determine connectivity.
	if (aging < 30)
		clnt->connected = true;
}

static void
register_active_change_time(char *macaddr)
{
	unsigned int curtime = (int)time(NULL);
	bool newcl = true;
	int i;

	for (i = 0; i < MAX_CLIENT; i++) {
		if (strlen(active_change[i].macaddr) < 17)
			break;

		if (strncmp(active_change[i].macaddr, macaddr, 24) == 0) {
			active_change[i].time = curtime;
			newcl = false;
			break;
		}
	}

	if (newcl && i < (MAX_CLIENT - 1)) {
		strncpy(active_change[i].macaddr, macaddr, 24);
		active_change[i].time = curtime;
	}
}

static void
generate_client_event(char *action, char *macaddr, char *ipaddr, char *network)
{
	// Register active last change time for the specific MAC address
	register_active_change_time(macaddr);

	// Generate ubus client event indicating connection status change
	runCmd("ubus send client '{\"action\":\"%s\",\"macaddr\":\"%s\",\"ipaddr\":\"%s\",\"network\":\"%s\"}'", action, macaddr, ipaddr, network);
}

 void
populate_clients(void)
{
	Client *tmp;
	FILE *arpt;
	char line[256];
	int clidx = 0;
	int hw, flag;
	char mask[257];
	int i, j;

	// Reset the client list
	memset(client_worker_t, '\0', sizeof(clients));

	// Walk through ARP table to populate clients
	arpt = fopen("/proc/net/arp", "r");
	if (arpt != NULL) {
		while (fgets(line, sizeof(line), arpt) != NULL) {
			if (clidx >= MAX_CLIENT)
				break;
			remove_newline(line);

			client_worker_t[clidx].exists = false;
			client_worker_t[clidx].local = false;
			//client_worker_t[clidx].wireless = false;
			//client_worker_t[clidx].connected = false;

			if (sscanf(line, "%24s 0x%d 0x%d %24s %256s %32s",
				client_worker_t[clidx].ipaddr, &hw, &flag,
				client_worker_t[clidx].macaddr, mask, client_worker_t[clidx].device)){
				// Ignore entries which has 00:00:00:00:00:00 as MAC address
				if (strncmp(client_worker_t[clidx].macaddr, "00:00:00:00:00:00", 17) == 0)
					continue;

				// Find which network interface this client belongs to
				get_network_info(&client_worker_t[clidx]);

				// Ignore entries which are not from LAN side
				if (!client_worker_t[clidx].local)
					continue;

				client_worker_t[clidx].exists = true;

				// Append DHCPv4 information: Hostname, IPv4 Address and Lease Time
				append_dhcpv4_info(&client_worker_t[clidx]);
				// If a hostname is given statically in dhcp config, overwrite dhcp hostname with it
				get_hostname_from_config(client_worker_t[clidx].macaddr, client_worker_t[clidx].hostname);

				// Append DHCPv6 information: IPv6 Address, DUID, Lease Time
				if (strlen(client_worker_t[clidx].hostname) > 1)
					append_dhcpv6_info(&client_worker_t[clidx]);

				// If the client is among wireless asssociated stations, assume it is connected
				client_worker_t[clidx].wireless = wireless_sta(&client_worker_t[clidx]);
				if (client_worker_t[clidx].wireless)
					client_worker_t[clidx].connected = true;
				else
				//Get Bridge Port No and set as connected
				//if Aging Timer is below 30 seconds
					get_bridge_info(&client_worker_t[clidx]);

				client_worker_t[clidx].activeconns = 0;
				if (client_worker_t[clidx].connected)
					// Get number of active connections established by this client
					client_worker_t[clidx].activeconns = active_connections(client_worker_t[clidx].ipaddr);

				clidx++;
			}
		}
		fclose(arpt);
	}

	// If a client has double entry due to switching from static
	// to dhcp connection, remove the static connection entry
	for (i = 0; i < clidx; i++) {

		if (client_worker_t[i].dhcp)
			continue;

		for (j = 0; j < clidx; j++) {

			if (!client_worker_t[j].dhcp)
				continue;

			if (strcmp(client_worker_t[i].macaddr, client_worker_t[j].macaddr) == 0) {
				client_worker_t[i].exists = false;
				break;
			}
		}
	}

	// At this point, clients are populated and
	// ready to be copied to main client array
	pthread_mutex_lock(&assocl_lock);
	tmp = client_main_t;
	client_main_t = client_worker_t;
	client_worker_t = tmp;
	pthread_mutex_unlock(&assocl_lock);
	// Compare the newly populated client array with the previously
	// populated client array in order to detect recently disconnected clients
	bool still_there;

	for (i = 0; i < MAX_CLIENT; i++) {
		if (!clients_old[i].exists)
			continue;

		if (!clients_old[i].connected)
			continue;

		still_there = false;

		for (j = 0; j < MAX_CLIENT; j++) {
			if (!client_worker_t[j].exists)
				continue;
			if (!client_worker_t[j].connected)
				continue;
			if (strcmp(clients_old[i].macaddr, client_worker_t[j].macaddr) == 0) {
				still_there = true;
				break;
			}
		}

		if (!still_there)
			generate_client_event("disconnect", clients_old[i].macaddr, clients_old[i].ipaddr, clients_old[i].network);
	}

	// Compare the newly populated client array with the previously
	// populated client array in order to detect recently connected clients
	bool was_there;

	for (i = 0; i < MAX_CLIENT; i++) {
		if (!client_worker_t[i].exists)
			continue;

		if (!client_worker_t[i].connected)
			continue;

		was_there = false;

		for (j = 0; j < MAX_CLIENT; j++) {
			if (!clients_old[j].exists)
				continue;
			if (!clients_old[j].connected)
				continue;
			if (strcmp(client_worker_t[i].macaddr, clients_old[j].macaddr) == 0) {
				was_there = true;
				break;
			}
		}

		if (!was_there)
			generate_client_event("connect", client_worker_t[i].macaddr, client_worker_t[i].ipaddr, client_worker_t[i].network);
	}

	// Copy currently populated client list
	// to old array for next round comparison
	memcpy(&clients_old, client_worker_t, sizeof(clients));
}

int
quest_router_networks(struct ubus_context *ctx, struct ubus_object *obj,
		  struct ubus_request_data *req, const char *method,
		  struct blob_attr *msg)
{
	void *t;
	int i;
	struct blob_buf buf = {0};

	blob_buf_init(&buf, 0);
	pthread_mutex_lock(&assocl_lock);
	for (i = 0; i < MAX_NETWORK && network[i].exists; i++) {
		t = blobmsg_open_table(&buf, network[i].name);
		blobmsg_add_u8(&buf, "is_lan", network[i].is_lan);
		blobmsg_add_string(&buf, "type", network[i].type);
		blobmsg_add_u8(&buf, "defaultroute", network[i].defaultroute);
		blobmsg_add_string(&buf, "proto", network[i].proto);
		if (strcmp(network[i].proto, "static") == 0) {
			blobmsg_add_string(&buf, "ipaddr", network[i].ipaddr);
			blobmsg_add_string(&buf, "netmask", network[i].netmask);
		}
		blobmsg_add_string(&buf, "ifname", network[i].ifname);
		blobmsg_close_table(&buf, t);
	}
	pthread_mutex_unlock(&assocl_lock);
	ubus_send_reply(ctx, req, buf.head);
	blob_buf_free(&buf);
	return 0;
}

int
quest_router_hosts(struct ubus_context *ctx, struct ubus_object *obj,
		  struct ubus_request_data *req, const char *method,
		  struct blob_attr *msg)
{
	struct blob_buf buf = {0};

	blob_buf_init(&buf, 0);
	pthread_mutex_lock(&assocl_lock);

	router_dump_hosts(&buf);

	pthread_mutex_unlock(&assocl_lock);
	ubus_send_reply(ctx, req, buf.head);
	blob_buf_free(&buf);
	return 0;
}

int
quest_router_clients(struct ubus_context *ctx, struct ubus_object *obj,
		  struct ubus_request_data *req, const char *method,
		  struct blob_attr *msg)
{
	struct blob_buf buf = {0};

	blob_buf_init(&buf, 0);
	pthread_mutex_lock(&assocl_lock);
	router_dump_clients(&buf);

	pthread_mutex_unlock(&assocl_lock);
	ubus_send_reply(ctx, req, buf.head);
	blob_buf_free(&buf);
	return 0;
}

int
quest_network_reload(struct ubus_context *ctx, struct ubus_object *obj,
		  struct ubus_request_data *req, const char *method,
		  struct blob_attr *msg)
{
	pthread_mutex_lock(&assocl_lock);
	populate_network_interfaces();
	pthread_mutex_unlock(&assocl_lock);
	return 0;
}

struct ubus_method network_object_methods[] = {
	UBUS_METHOD_NOARG("dump", quest_router_networks),
	UBUS_METHOD_NOARG("clients", quest_router_clients),
	UBUS_METHOD_NOARG("hosts", quest_router_hosts),
	UBUS_METHOD_NOARG("reload", quest_network_reload),
};

struct ubus_object_type network_object_type =
	UBUS_OBJECT_TYPE("network", network_object_methods);

struct ubus_object network_object = {
	.name = "router.network",
	.type = &network_object_type,
	.methods = network_object_methods,
	.n_methods = ARRAY_SIZE(network_object_methods),
};

void *monitor_clients(void *arg)
{
	while (true) {
		populate_clients();
		populate_hosts_from_clients();
		sleep(5);
	}

	return NULL;
}

int network_init(void)
{
	int r;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if (pthread_mutex_init(&assocl_lock, NULL) != 0) {
		fprintf(stderr, "Failed to initialize mutex\n");
		return 1;
	}

	populate_network_interfaces();
	netpt = pthread_create(&(tid[0]), &attr, &monitor_clients, NULL);
	if (netpt != 0) {
		fprintf(stderr, "Failed to create thread\n");
		return 1;
	}
	pthread_detach(pthread_self());
	r = quest_add_object(&network_object);
	return r;
}

int network_exit(void)
{
	pthread_attr_destroy(&attr);
	pthread_mutex_destroy(&assocl_lock);
	return 0;
}
