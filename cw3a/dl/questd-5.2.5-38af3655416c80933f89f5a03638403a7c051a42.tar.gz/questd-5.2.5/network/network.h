#ifndef NETWORK_H
#define NETWORK_H
#define MAX_NETWORK	16
#define MAX_CLIENT	256

#include <stdbool.h>

typedef struct {
	bool exists;
	char macaddr[24]; //PhysAddress
	char ipaddr[24]; //IPAddress
	const char *addrsrc; //AddressSource
	unsigned int leasetmrmn; //LeaseTimeRemaining
	char device[16]; //Layer1Interface
	char network[32]; //Layer3Interface
	const char *type; //InterfaceType
	struct {
		char vcid[128]; //VendorClassID - Option 60
		char clid[128]; //ClientID - Option 61
		char ucid[128]; //UserClassID - Option 77

	} dhcpopts;
	char hostname[64]; //HostName
	bool active; //Active
	unsigned int activelstch; //ActiveLastChange
	unsigned int activeconns; //ActiveConnectionsNumber
	char ipv4addr[8][24]; //IPv4Address
	char ipv6addr[8][128]; //IPv6Address
	struct {
		unsigned long long tx_bytes; //WANStats.BytesSent
		unsigned long long rx_bytes; //WANStats.BytesReceived
		unsigned long long tx_packets; //WANStats.PacketsSent
		unsigned long long rx_packets; //WANStats.PacketsReceived

	} stats;
} Host;

typedef struct {
	char macaddr[24];
	unsigned int time;
} ActiveChange;

typedef struct {
	bool exists;
	bool connected;
	int activeconns;
	bool local;
	bool dhcp;
	long leasetime;
	char macaddr[24];
	char ipaddr[24];
	bool ipv6;
	char ip6addr[128];
	long lease6time;
	char duid[64];
	char hostname[64];
	char network[32];
	char device[32];
	int brportno;
	bool wireless;
	char wdev[8];
	char frequency[8];
	int rssi;
	int snr;
	int idle;
	int in_network;
	unsigned long long tx_bytes;
	unsigned long long rx_bytes;
	unsigned long long tx_packets;
	unsigned long long rx_packets;
} Client;

typedef struct {
	bool exists;
	bool is_lan;
	bool defaultroute;
	char name[16];
	char type[16];
	char proto[16];
	char ipaddr[24];
	char netmask[24];
	char ifname[128];
} Network;

#endif
