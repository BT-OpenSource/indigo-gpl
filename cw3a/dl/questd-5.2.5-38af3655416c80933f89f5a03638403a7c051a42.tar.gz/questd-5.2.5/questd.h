
int quest_add_object(struct ubus_object *obj);
