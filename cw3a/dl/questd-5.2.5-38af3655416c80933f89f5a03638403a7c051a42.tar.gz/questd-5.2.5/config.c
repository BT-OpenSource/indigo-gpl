#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <sys/sysinfo.h>
#include <time.h>

#include <uci.h>

#include "system.h"
#include "config.h"

static struct uci_context *db_ctx = NULL;
static bool db_loaded = false;

void config_db_init()
{
	db_ctx = uci_alloc_context();
	uci_set_confdir(db_ctx, "/etc/board-db/config/");
	if(uci_load(db_ctx, "device", NULL) == UCI_OK)
		db_loaded = true;
}

void config_db_cleanup()
{
	if (db_ctx) {
		uci_free_context(db_ctx);
		db_ctx = NULL;
	}
}

void config_db_board_get_option(const char *opt, const char **val)
{
	struct uci_ptr ptr;

	memset(&ptr, 0, sizeof(ptr));
	ptr.package = "device";
	ptr.section = "deviceinfo";
	ptr.value = NULL;

	*val = "";

	if (!db_loaded)
		return;

	ptr.option = opt;
	if (uci_lookup_ptr(db_ctx, &ptr, NULL, true) != UCI_OK)
		return;

	if (!(ptr.flags & UCI_LOOKUP_COMPLETE))
		return;

	if(!ptr.o->v.string)
		return;

	*val = ptr.o->v.string;
}
