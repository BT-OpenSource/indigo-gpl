/*
 * A minimalist lib for processes snapshot. 
 * It is inspired from busybox ps tool and it try to provide compatible
 * behavior with it
 */
#define _GNU_SOURCE 1  /* for strchrnul */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stddef.h>
#include <stdint.h>

#include "procps.h"

#define PROCPS_BUFSIZE 1024

int file_to_buf(const char *filename, void *buf, int bufsize)
{
	FILE *file;
	int ret = -1;

	file = fopen(filename, "r");
	if (file) {
		ret = fread(buf, 1, bufsize - 1, file);
		fclose(file);
	}
	((char *)buf)[ret > 0 ? ret : 0] = '\0';
	return ret;
}

static char* safe_strncpy(char *dst, const char *src, size_t size)
{
	if (!size) return dst;
	dst[--size] = '\0';
	return strncpy(dst, src, size);
}

static procps_status_t* alloc_procps_scan(void)
{
	unsigned n = getpagesize();
	procps_status_t* sp = calloc(1, sizeof(procps_status_t));
	if (sp == NULL)
		return NULL;

	sp->dir = opendir("/proc");
	if (sp->dir == NULL) {
		free(sp);
		return NULL;
	}

	while (1) {
		n >>= 1;
		if (!n)
			break;
		sp->shift_pages_to_bytes++;
	}
	sp->shift_pages_to_kb = sp->shift_pages_to_bytes - 10;

	return sp;
}

static void free_procps_scan(procps_status_t* sp)
{
	closedir(sp->dir);
	free(sp);
}

procps_status_t* procps_scan(procps_status_t* sp)
{
	if (!sp)
		sp = alloc_procps_scan();
	if(!sp)
		return NULL;

	for (;;) {
		struct dirent *entry;
		char buf[PROCPS_BUFSIZE];
		unsigned pid;
		int n;
		char filename[sizeof("/proc/%u/task/%u/cmdline") + sizeof(int)*3 * 2];
		char *filename_tail;
		char *cp, *comm1;
		int tty;
		unsigned long vsz, rss;
		/* see proc(5) for some details on this */

		entry = readdir(sp->dir);
		if (entry == NULL) {
			free_procps_scan(sp);
			return NULL;
		}

		errno = 0;
		pid = strtoul(entry->d_name, NULL, 10);
		if (errno)
			continue;

		/* re-initialize proc variables to zero */
		memset(&sp->vsz, 0, sizeof(*sp) - offsetof(procps_status_t, vsz));

		sp->pid = pid;
		filename_tail = filename + sprintf(filename, "/proc/%u/", pid);

		strcpy(filename_tail, "stat");
		n = file_to_buf(filename, buf, PROCPS_BUFSIZE);
		if (n < 0)
			continue; /* process probably exited */

		cp = strrchr(buf, ')'); /* split into "PID (cmd" and "<rest>" */
		if (!cp) /* sanity check */
		  continue;
		cp[0] = '\0';
		comm1 = strchr(buf, '(');
		safe_strncpy(sp->comm, comm1 + 1, sizeof(sp->comm));

		/* see man 5 proc */
		n = sscanf(cp+2,
				"%c %u "               /* state, ppid */
				"%u %u %d %*s "        /* pgid, sid, tty, tpgid */
				"%*s %*s %*s %*s %*s " /* flags, min_flt, cmin_flt, maj_flt, cmaj_flt */
				"%lu %lu "             /* utime, stime */
				"%*s %*s %d "         /* cutime, cstime, priority */
				"%d "                 /* niceness */
				"%*s %*s "             /* timeout, it_real_value */
				"%lu "                 /* start_time */
				"%lu "                 /* vsize */
				"%lu "                 /* rss */
				,
				&sp->state, &sp->ppid,
				&sp->pgid, &sp->sid, &tty,
				&sp->utime, &sp->stime,
				&sp->priority,
				&sp->niceness,
				&sp->start_time,
				&vsz,
				&rss
			  );

		if (n < 11)
			continue; /* bogus data, get next /proc/XXX */

		/* vsz is in bytes and we want kb */
		sp->vsz = vsz >> 10;
		/* vsz is in bytes but rss is in *PAGES*! Can you believe that? */
		sp->rss = rss << sp->shift_pages_to_kb;

		break;
	} /* for (;;) */

	return sp;
}

void procps_get_cmdline(char *buf, int bufsz, unsigned pid, const char *comm)
{
	int sz;
	char filename[sizeof("/proc/%u/cmdline") + sizeof(int)*3];

	sprintf(filename, "/proc/%u/cmdline", pid);
	sz = file_to_buf(filename, buf, bufsz);
	if (sz > 0) {
		const char *base;
		int comm_len;

		while (--sz >= 0 && buf[sz] == '\0')
			continue;
		/* Prevent basename("process foo/bar") = "bar" */
		strchrnul(buf, ' ')[0] = '\0';
		base = basename(buf); /* before we replace argv0's NUL with space */
		while (sz >= 0) {
			if ((unsigned char)(buf[sz]) < ' ')
				buf[sz] = ' ';
			sz--;
		}
		if (base[0] == '-') /* "-sh" (login shell)? */
			base++;

		/* If comm differs from argv0, prepend "{comm} ".
		 * It allows to see thread names set by prctl(PR_SET_NAME).
		 */
		if (!comm)
			return;
		comm_len = strlen(comm);
		/* Why compare up to comm_len?
		 * Well, some processes rewrite argv, and use _spaces_ there
		 * while rewriting. (KDE is observed to do it).
		 * I prefer to still treat argv0 "process foo bar"
		 * as 'equal' to comm "process".
		 */
		if (strncmp(base, comm, comm_len) != 0) {
			comm_len += 3;
			if (bufsz > comm_len)
				memmove(buf + comm_len, buf, bufsz - comm_len);
			snprintf(buf, bufsz, "{%s}", comm);
			if (bufsz <= comm_len)
				return;
			buf[comm_len - 1] = ' ';
			buf[bufsz - 1] = '\0';
		}
	} else {
		snprintf(buf, bufsz, "[%s]", comm ? comm : "?");
	}
}
