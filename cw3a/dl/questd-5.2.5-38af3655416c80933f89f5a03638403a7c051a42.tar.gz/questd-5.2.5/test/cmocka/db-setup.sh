#!/bin/sh

if [ "$1" = "show" ]; then
	uci -c /etc/board-db/config show
else
	mkdir -p /etc/board-db/config
	echo config device 'deviceinfo' > /etc/board-db/config/device
	# device info
	uci set /etc/board-db/config/device.deviceinfo.Manufacturer="IOPSYS"
	uci set /etc/board-db/config/device.deviceinfo.BaseMACAddress="11:22:33:44:55:66"
	uci set /etc/board-db/config/device.deviceinfo.ModelName="DG400PRIME"
	uci set /etc/board-db/config/device.deviceinfo.SerialNumber="00000000"
	uci set /etc/board-db/config/device.deviceinfo.HardwareVersion="1.0"
	uci set /etc/board-db/config/device.deviceinfo.SoftwareVersion="5.6.7"
	uci set /etc/board-db/config/device.deviceinfo.ActiveFirmwareImage="DG400PRIME-X-IOPSYS-5.6.7-191121_1040"
fi
