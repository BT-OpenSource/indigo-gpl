# Network Schema

```
http://iosys.eu/router.network.json
```

| Custom Properties | Additional Properties |
| ----------------- | --------------------- |
| Forbidden         | Permitted             |

# Network

| List of Methods   |
| ----------------- |
| [hosts](#hosts)   | Method | Network (this schema) |
| [reload](#reload) | Method | Network (this schema) |

## hosts

`hosts`

- type: `Method`

### hosts Type

`object` with following properties:

| Property | Type   | Required |
| -------- | ------ | -------- |
| `input`  | object | Optional |
| `output` | object | Optional |

#### input

`input`

- is optional
- type: `object`

##### input Type

`object` with following properties:

| Property | Type | Required |
| -------- | ---- | -------- |
| None     | None | None     |

### Ubus CLI Example

```
ubus call Network hosts {}
```

### JSONRPC Example

```json
{ "jsonrpc": "2.0", "id": 0, "method": "call", "params": ["<SID>", "Network", "hosts", {}] }
```

#### output

`output`

- is optional
- type: `object`

##### output Type

`object` with following properties:

| Property | Type  | Required |
| -------- | ----- | -------- |
| `hosts`  | array | Optional |

#### hosts

`hosts`

- is optional
- type: `array`

##### hosts Type

Array type: `array`

All items must be of the type:

**Any** following _options_ needs to be fulfilled.

#### Option 1

`object` with following properties:

| Property      | Type    | Required |
| ------------- | ------- | -------- |
| `active`      | boolean | Optional |
| `activeconns` | integer | Optional |
| `activelstch` | integer | Optional |
| `addsrc`      | string  | Optional |
| `device`      | string  | Optional |
| `dhcpopts`    | object  | Optional |
| `hostname`    | string  | Optional |
| `ipaddr`      | string  | Optional |
| `ipv4addr`    | array   | Optional |
| `ipv6addr`    | array   | Optional |
| `leasetmrmn`  | integer | Optional |
| `macaddr`     | string  | Optional |
| `network`     | string  | Optional |
| `stats`       | object  | Optional |
| `type`        | string  | Optional |

#### active

`active`

- is optional
- type: `boolean`

##### active Type

`boolean`

#### activeconns

`activeconns`

- is optional
- type: `integer`

##### activeconns Type

`integer`

#### activelstch

`activelstch`

- is optional
- type: `integer`

##### activelstch Type

`integer`

#### addsrc

`addsrc`

- is optional
- type: `string`

##### addsrc Type

`string`

#### device

`device`

- is optional
- type: `string`

##### device Type

`string`

#### dhcpopts

`dhcpopts`

- is optional
- type: `object`

##### dhcpopts Type

`object` with following properties:

| Property | Type   | Required |
| -------- | ------ | -------- |
| `clid`   | string | Optional |
| `ucid`   | string | Optional |
| `vcid`   | string | Optional |

#### clid

`clid`

- is optional
- type: `string`

##### clid Type

`string`

#### ucid

`ucid`

- is optional
- type: `string`

##### ucid Type

`string`

#### vcid

`vcid`

- is optional
- type: `string`

##### vcid Type

`string`

#### hostname

`hostname`

- is optional
- type: `string`

##### hostname Type

`string`

#### ipaddr

`ipaddr`

- is optional
- type: `string`

##### ipaddr Type

`string`

#### ipv4addr

`ipv4addr`

- is optional
- type: `array`

##### ipv4addr Type

Array type: `array`

All items must be of the type:

**Any** following _options_ needs to be fulfilled.

#### Option 1

`string`

#### ipv6addr

`ipv6addr`

- is optional
- type: `array`

##### ipv6addr Type

Array type: `array`

All items must be of the type:

**Any** following _options_ needs to be fulfilled.

#### Option 1

`string`

#### leasetmrmn

`leasetmrmn`

- is optional
- type: `integer`

##### leasetmrmn Type

`integer`

#### macaddr

`macaddr`

- is optional
- type: reference

##### macaddr Type

- `string`

#### network

`network`

- is optional
- type: `string`

##### network Type

`string`

#### stats

`stats`

- is optional
- type: `object`

##### stats Type

`object` with following properties:

| Property     | Type    | Required |
| ------------ | ------- | -------- |
| `rx_bytes`   | integer | Optional |
| `rx_packets` | integer | Optional |
| `tx_bytes`   | integer | Optional |
| `tx_packets` | integer | Optional |

#### rx_bytes

`rx_bytes`

- is optional
- type: `integer`

##### rx_bytes Type

`integer`

#### rx_packets

`rx_packets`

- is optional
- type: `integer`

##### rx_packets Type

`integer`

#### tx_bytes

`tx_bytes`

- is optional
- type: `integer`

##### tx_bytes Type

`integer`

#### tx_packets

`tx_packets`

- is optional
- type: `integer`

##### tx_packets Type

`integer`

#### type

`type`

- is optional
- type: `string`

##### type Type

`string`

### Output Example

```json
{
  "hosts": [
    {
      "macaddr": "BD:6E:DA-Aa-Bb:3A",
      "ipaddr": "sint",
      "addsrc": "fugiat amet",
      "leasetmrmn": -53476260,
      "device": "ut in sunt",
      "network": "Ut",
      "type": "ex ut",
      "hostname": "ex culpa anim commodo Duis",
      "active": false,
      "activelstch": 29732855,
      "activeconns": -52454091,
      "dhcpopts": { "vcid": "in nisi", "clid": "sed", "ucid": "tempor sed proident mollit" },
      "ipv4addr": ["magna in"],
      "ipv6addr": [
        "est velit veniam id qui",
        "deserunt commodo exercitation Ut",
        "pariatur nisi labore anim",
        "do anim ut dolore"
      ],
      "stats": { "tx_packets": 21314829, "tx_bytes": -41996555, "rx_packets": 18096032, "rx_bytes": -89440974 }
    },
    {
      "macaddr": "7d-bc:d7-Cb-Aa-D7",
      "ipaddr": "enim",
      "addsrc": "sed cillum ea",
      "leasetmrmn": 26341072,
      "device": "est",
      "network": "in occaecat ea ut",
      "type": "sit Lorem qui",
      "hostname": "Lorem fugiat laboris occaecat",
      "active": false,
      "activelstch": -67035139,
      "activeconns": -4660572,
      "dhcpopts": { "vcid": "anim quis laborum nulla irure", "clid": "voluptate ut", "ucid": "amet nisi" },
      "ipv4addr": ["minim Excepteur qui", "magna do aliqua dolore quis", "sint sunt "],
      "ipv6addr": ["do", "ipsum incididunt ullamco", "cillum in", "Ut"],
      "stats": { "tx_packets": -37099784, "tx_bytes": -25311717, "rx_packets": -93024235, "rx_bytes": 33999545 }
    }
  ]
}
```

## reload

`reload`

- type: `Method`

### reload Type

`object` with following properties:

| Property | Type   | Required |
| -------- | ------ | -------- |
| `input`  | object | Optional |
| `output` | object | Optional |

#### input

`input`

- is optional
- type: `object`

##### input Type

`object` with following properties:

| Property | Type | Required |
| -------- | ---- | -------- |
| None     | None | None     |

### Ubus CLI Example

```
ubus call Network reload {}
```

### JSONRPC Example

```json
{ "jsonrpc": "2.0", "id": 0, "method": "call", "params": ["<SID>", "Network", "reload", {}] }
```

#### output

`output`

- is optional
- type: `object`

##### output Type

`object` with following properties:

| Property | Type | Required |
| -------- | ---- | -------- |
| None     | None | None     |

### Output Example

```json
{}
```
