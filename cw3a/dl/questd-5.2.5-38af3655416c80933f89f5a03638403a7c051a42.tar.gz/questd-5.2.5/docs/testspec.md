# Test Specification

Most of the functionality in questd can be tested via its ubus API. Each
API can be broken down into an individual test case to show full coverage is
achieved.

# Sections

- [Preqreuisites](#prerequisites)
- [Test Suites](#test-suites)
- [Unit Tests](#unit-tests)
- [Functional Tests](#functional-tests)
- [Functional API Tests](#functional-api-tests)

## Prerequisites

Prerequisites for the questd test suites can be listed as follows:

- Docker container has to run with NET_ADMIN capability because various network parameters must be configured.
- wifimngr and libwifi has to be built for the TEST platform due to the internal usage
- bridge-utils must be installed in order to do necessary bridge configurations that is required for questd.

## Test Suites

The questd build pipe has three test suites, a functional-api suite, a functional test suite, and a unit test suite.

### Functional API Tests

The functional API tests consists of one test suite, testing the getter
function of the [network](./functionspec.md#network) object [hosts](./functionspec.md#hosts).
Ubus under test. The functional API tests use the Ubus-API-validation
command-line interface tool to invoke a method, programmatically through
libubus, and validates it against the objects json-schema.

#### network

| Execution ID | Method | Description | Function ID Coverage         |
| :----------- | :----- | :---------- | :--------------------------- |
| 1            | hosts  | No argument | [1](./functionspec.md#hosts) |

### Functional Tests

The questd functional tests are dependent on ubus and wifimngr. They are
written in cmocka, invoking the ubus callbacks
directly from the source code, which is compiled into a shared library.
This means mocking the arguments of a cli or libubus invoke in a
`struct blob_attr *`. Functional tests are testing the questd [network](./functionspec.md#network) part.

| Execution ID | Method | Test Case Name                            | Function ID Coverage          |
| :----------- | :----- | :---------------------------------------- | :---------------------------- |
| 1            | hosts  | [test_router_hosts](#test_router_hosts)   | [1](./functionspec.md#hosts)  |
| 2            | reload | [test_router_reload](#test_router_reload) | [2](./functionspec.md#reload) |

#### test_router_hosts

##### Description

Tests the questd ubus API callback `router.network hosts`, publishing the method
[hosts](./functionspec.md#hosts).

##### Test Steps

Run the wifimngr and ubus as a background process.

Run the test, and observe host information of wireless 5GHz client `test5` and 2.4GHz client `test2` are correctly outputted to the command line interface.

##### Test Expected Results

The expected result can given as follows.

```bash
[2020-09-14 15:03:12] hosts: {"hosts":[{"macaddr":"50:80:70:60:50:40","ipaddr":"192.168.1.102","addrsrc":"static","leasetmrmn":0,"device":"test5","network":"lan","type":"wifi","hostname":"","active":true,"activelstch":0,"activeconns":0,"dhcpopts":{"vcid":"","clid":"","ucid":""},"ipv4addr":["192.168.1.102"],"ipv6addr":[],"stats":{"tx_packets":251851,"tx_bytes":197716844,"rx_packets":137122,"rx_bytes":198917288}},{"macaddr":"00:e0:4c:68:18:54","ipaddr":"192.168.1.100","addrsrc":"static","leasetmrmn":0,"device":"test2","network":"lan","type":"ethernet","hostname":"","active":true,"activelstch":0,"activeconns":0,"dhcpopts":{"vcid":"","clid":"01:00:e0:4c:68:18:54","ucid":""},"ipv4addr":["192.168.1.100"],"ipv6addr":[],"stats":{"tx_packets":0,"tx_bytes":0,"rx_packets":0,"rx_bytes":0}},{"macaddr":"20:80:70:60:50:40","ipaddr":"192.168.1.101","addrsrc":"static","leasetmrmn":0,"device":"test2","network":"lan","type":"wifi","hostname":"","active":true,"activelstch":0,"activeconns":0,"dhcpopts":{"vcid":"","clid":"","ucid":""},"ipv4addr":["192.168.1.101"],"ipv6addr":[],"stats":{"tx_packets":23241,"tx_bytes":3912221,"rx_packets":40204,"rx_bytes":36176593}}]}

```

#### test_router_reload

##### Description

Tests the questd ubus API callback `router.network reload`, publishing the method
[reload](./functionspec.md#reload).

##### Test Steps

Run the wifimngr and ubus as a background process.

Run the test, and observe that network information is reloaded with updated `is_lan` parameter.

##### Test Expected Results

The expected result can given as follows.

```bash
[2020-09-15 15:03:12] reload: {"lan":{"is_lan":true,"type":"bridge","defaultroute":true,"proto":"static","ipaddr":"192.168.1.1","netmask":"255.255.255.0","ifname":"eth1 eth2 eth3 eth4"},"wan":{"is_lan":false,"type":"anywan","defaultroute":true,"proto":"dhcp","ifname":"atm0.1 ptm0.1 eth0.1"},"wan6":{"is_lan":false,"type":"","defaultroute":true,"proto":"dhcpv6","ifname":"@wan"}}

[2020-09-15 15:03:16] reload: {"lan":{"is_lan":false,"type":"bridge","defaultroute":true,"proto":"static","ipaddr":"192.168.1.1","netmask":"255.255.255.0","ifname":"eth1 eth2 eth3 eth4"},"wan":{"is_lan":false,"type":"anywan","defaultroute":true,"proto":"dhcp","ifname":"atm0.1 ptm0.1 eth0.1"},"wan6":{"is_lan":false,"type":"","defaultroute":true,"proto":"dhcpv6","ifname":"@wan"}}
```

### Unit Tests

The unit tests are also written in cmocka. The difference between unit tests and functional tests is that functional tests are dependent on ubus and wifimngr processes, unit tests do not have such dependendecy. Questd unit tests are testing [system](./functionspec.md#system) object.

| Execution ID | Method     | Test Case Name                                    | Function ID Coverage              |
| :----------- | :--------- | :------------------------------------------------ | :-------------------------------- |
| 1            | info       | [test_system_info](#test_system_info)             | [3](./functionspec.md#info)       |
| 2            | memory     | [test_system_memory](#test_system_memory)         | [4](./functionspec.md#memory)     |
| 3            | process    | [test_system_process](#test_system_process)       | [5](./functionspec.md#process)    |
| 4            | processes  | [test_system_processes](#test_system_processes)   | [6](./functionspec.md#processes)  |
| 5            | filesystem | [test_system_filesystem](#test_system_filesystem) | [7](./functionspec.md#filesystem) |

#### test_system_info

##### Description

Tests the questd ubus API callback `router.system info`, publishing the method
[info](./functionspec.md#info).

##### Test Steps

Run the test, and observe system information of the gateway are correctly outputted to the command line interface.

##### Test Expected Results

The expected result can given as follows.

```bash
[2020-09-14 15:04:12] info: {"manufacturer":"IOPSYS","model_name":"DG400PRIME","basemac":"11:22:33:44:55:66","serial_number":"00000000","hardware_version":"1.0","software_version":"5.6.7","active_firmware_image":"DG400PRIME-X-IOPSYS-5.6.7-191121_1040","kernel":"5.4.0-47-generic","hostname":"add1bbab87e5","uptime":23312,"localtime":1600092127}

```

#### test_system_memory

##### Description

Tests the questd ubus API callback `router.system memory`, publishing the method
[memory](./functionspec.md#memory).

##### Test Steps

Run the test, and observe total memory information of the gateway are correctly outputted to the command line interface.

##### Test Expected Results

The expected result can given as follows.

```bash
[2020-09-14 15:05:12] memory: {"total":16069460,"free":619624,"shared":1122860,"buffers":710808}

```

#### test_system_process

##### Description

Tests the questd ubus API callback `router.system process`, publishing the method
[process](./functionspec.md#process).

##### Test Steps

Run the test, and observe the information about current process.

##### Test Expected Results

The expected result can given as follows.

```bash
[2020-09-14 15:06:12] process: {"cpu_usage":13,"process_num":1538}


```

#### test_system_processes

##### Description

Tests the questd ubus API callback `router.system processes`, publishing the method
[processes](./functionspec.md#processes).

##### Test Steps

Run the test, and observe the information about all processes running in the gateway.

##### Test Expected Results

The expected result can given as follows.

```bash
[2020-09-14 15:07:12] processes: {"processes":[{"pid":1,"ppid":0,"command":"{entrypoint.sh} \/bin\/bash \/usr\/local\/bin\/entrypoint.sh","vsz":18372,"%vsz":0,"priority":20,"niceness":0,"cputime":0,"state":"Sleeping"},{"pid":9,"ppid":1,"command":"{supervisord} \/usr\/bin\/python \/usr\/bin\/supervisord -c \/etc\/supervisor\/supervisord.conf","vsz":55260,"%vsz":0,"priority":20,"niceness":0,"cputime":0,"state":"Sleeping"},{"pid":10,"ppid":1,"command":"\/bin\/bash","vsz":21728,"%vsz":0,"priority":20,"niceness":0,"cputime":0,"state":"Sleeping"},{"pid":1295,"ppid":10,"command":".\/system_tests","vsz":21620,"%vsz":0,"priority":20,"niceness":0,"cputime":0,"state":"Running"}]}

```

#### test_system_filesystem

##### Description

Tests the questd ubus API callback `router.system filesystem`, publishing the method
[filesystem](./functionspec.md#filesystem).

##### Test Steps

Run the test, and observe the information of gateway filesystem.

##### Test Expected Results

The expected result can given as follows.

```bash
[2020-09-14 15:08:12] filesystem: {"filesystem":[{"name":"overlay","1kblocks":490691512,"used":145346340,"available":320349692,"usage":32,"mounted_on":"\/"},{"name":"tmpfs","1kblocks":65536,"used":0,"available":65536,"usage":0,"mounted_on":"\/dev"},{"name":"tmpfs","1kblocks":8034728,"used":0,"available":8034728,"usage":0,"mounted_on":"\/sys\/fs\/cgroup"},{"name":"shm","1kblocks":65536,"used":0,"available":65536,"usage":0,"mounted_on":"\/dev\/shm"},{"name":"\/dev\/nvme0n1p2","1kblocks":490691512,"used":145346340,"available":320349692,"usage":32,"mounted_on":"\/etc\/hosts"},{"name":"tmpfs","1kblocks":8034728,"used":0,"available":8034728,"usage":0,"mounted_on":"\/proc\/asound"},{"name":"tmpfs","1kblocks":8034728,"used":0,"available":8034728,"usage":0,"mounted_on":"\/proc\/acpi"},{"name":"tmpfs","1kblocks":8034728,"used":0,"available":8034728,"usage":0,"mounted_on":"\/proc\/scsi"},{"name":"tmpfs","1kblocks":8034728,"used":0,"available":8034728,"usage":0,"mounted_on":"\/sys\/firmware"}]}

```
