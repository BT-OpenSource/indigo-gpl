# README #
----------

Questd is a versatile application continuously monitoring the system and exposing router.system and router.network ubus objects.

```
# ubus -v list router.system
'router.system' @45ce0afe
        "info":{}
        "memory":{}
        "process":{}
        "processes":{}
        "filesystem":{}
# ubus -v list router.network
'router.network' @1260e3e9
        "dump":{}
        "clients":{}
        "hosts":{}
        "reload":{}
```

# Testing #
Build for test:
```
$ mkdir build
$ cd build
$ cmake .. -DENABLE_BUILD_TESTS=ON
$ make
$ make test
$ make test_coverage
```
