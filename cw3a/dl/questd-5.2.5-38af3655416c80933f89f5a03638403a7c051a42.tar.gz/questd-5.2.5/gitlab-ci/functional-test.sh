
#!/bin/bash
set -e
echo "preparation script"

pwd


supervisorctl status all
supervisorctl update
sleep 3
supervisorctl status all

make functional-test -C /builds/iopsys/questd/build


#report part
#GitLab-CI output
make functional-coverage -C /builds/iopsys/questd/build
