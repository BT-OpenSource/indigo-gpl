#!/bin/bash

set -e
echo "Preparation script"
pwd

brctl addbr br-lan
ifconfig br-lan 192.168.1.1
ifconfig br-lan up
ip link add name veth1 type dummy
ip link add name test2 type dummy
ip link add name test5 type dummy
brctl addif br-lan test2
brctl addif br-lan test5


cp -r /builds/iopsys/questd/test/cmocka/files/etc/* /etc/
cp -r /builds/iopsys/questd/test/cmocka/files/var/* /var/

mkdir -p /tmp/hosts && cp /builds/iopsys/questd/test/cmocka/files/odhcpd /tmp/hosts/

cp /builds/iopsys/questd/gitlab-ci/iopsys-supervisord.conf /etc/supervisor/conf.d/
cp -r /builds/iopsys/questd/schemas/* /usr/share/rpcd/schemas 

ls /etc/config/
ls /usr/share/rpcd/schemas/
ls /etc/supervisor/conf.d/

arp -i br-lan -s 192.168.1.100   00:e0:4c:68:18:54
arp -i test2 -s  192.168.1.101   20:80:70:60:50:40
arp -i test5 -s  192.168.1.102   50:80:70:60:50:40

cd ..

pwd

rm -rf /builds/iopsys/questd/build
mkdir /builds/iopsys/questd/build

pushd /builds/iopsys/questd/build
    cmake .. -DENABLE_BUILD_TESTS=ON
    make

pwd
ls
