#ifndef _TIMESTAMP_H
#define _TIMESTAMP_H

#include <stdint.h>
#include <stdbool.h>
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Reset timespec structure
 * @param[in] ts timespec structure
 */
void timestamp_reset(struct timespec *ts);


/** Update timespec structure with current time
 * @param[in] ts timespec structure
 */
void timestamp_update(struct timespec *ts);


/** Get diff between two timespec in ms
 * @param[in] ts_1 timespec structure
 * @param[in] ts_2 timespec structure
 * @return diff in ms
 */
uint32_t timestamp_diff_ms(struct timespec ts_1,
			   struct timespec ts_2);


/** Get elapsed seconds
 * @param[in] ts timespec structure
 * @return elapsed seconds till now
 */
uint32_t timestamp_elapsed_sec(const struct timespec *ts);


/** Check if timespec expired
 * @param[in] ts timespec structure
 * @param[in] tmo_ms timeout in ms
 * @return true if expired
 */
bool timestamp_expired(struct timespec *ts, unsigned int tmo_ms);


/** Converts timestamp string to timespec struct
 * @param[in] tsp timestamp string
 * @param[in] adj_rtime adjust to realtime
 * @return timespec structure
 */
struct timespec timestamp_to_timespec(const char *tsp, bool adj_rtime);

#ifdef __cplusplus
}
#endif

#endif /* _TIMESTAMP_H */
