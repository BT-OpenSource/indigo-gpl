#define _DEFAULT_SOURCE
#define _XOPEN_SOURCE
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>
#include <math.h>
#include "easy.h"

void LIBEASY_API timestamp_reset(struct timespec *ts)
{
	ts->tv_sec = 0;
	ts->tv_nsec = 0;
}

int LIBEASY_API timestamp_invalid(struct timespec *ts)
{
	return ts->tv_sec == 0 && ts->tv_nsec == 0;
}

void LIBEASY_API timestamp_update(struct timespec *ts)
{
	if (clock_gettime(CLOCK_MONOTONIC, ts) < 0) {
		ts->tv_sec = 0;
		ts->tv_nsec = 0;
	}
}

/* returns difference in ms */
uint32_t LIBEASY_API timestamp_diff_ms(struct timespec ts_1,
				       struct timespec ts_2)
{
	uint32_t ms_1, ms_2;

	ms_1 = ts_1.tv_sec * 1000;
	ms_1 += floor(ts_1.tv_nsec / 1.0e6);
	ms_2 = ts_2.tv_sec * 1000;
	ms_2 += floor(ts_2.tv_nsec / 1.0e6);

	if (ms_2 > ms_1)
		return (ms_2 - ms_1);
	else
		return (ms_1 - ms_2);
}

/* Time difference in seconds */
uint32_t LIBEASY_API timestamp_elapsed_sec(const struct timespec *ts)
{
	struct timespec now;
	uint32_t elapsed;

	if (ts->tv_sec == 0)
		return -1;

	/* seconds and nanoseconds since the Epoch */
	if (clock_gettime(CLOCK_MONOTONIC, &now) < 0)
		now.tv_sec = 0;

	elapsed = now.tv_sec - ts->tv_sec;

	return (elapsed > 0) ? elapsed : 0;
}

/* check if timestamp expired */
bool LIBEASY_API timestamp_expired(struct timespec *ts, unsigned int tmo_ms)
{
	struct timespec now;
	unsigned long diff_ns = 0, diff_s = 0;

	if (clock_gettime(CLOCK_MONOTONIC, &now) < 0)
		return false;

	diff_s = now.tv_sec - ts->tv_sec;
	diff_ns = now.tv_nsec - ts->tv_nsec;
	if ((long)diff_ns < 0) {
		diff_ns += 1000000000UL;
		diff_s--;
	}

	if (diff_s * 1000 + diff_ns / 1000000 >= tmo_ms)
		return true;

	return false;
}

/* get time adjustment seconds (time(tzone) - time(UTC) secs) */
static long int timestamp_get_off_sec(const char *tsp)
{
	char *tzone;
	long int toff = 0, sign;
	int toff_hour, toff_min;

	/* Example timestamp: "2019-02-11T06:42:31-08:00" */

	tzone = strchr(tsp, '+');
	if (!tzone) {
		tzone = strrchr(tsp, '-'); /* last occurence */
		sign = -1L;
	} else {
		sign = +1L;
	}

	if (tzone) {
		sscanf(tzone+1, "%02d:%02d", &toff_hour, &toff_min);
		toff = toff_hour * 3600 + toff_min * 60; // seconds
		toff *= -sign;
	}

	return toff;
}

/* Returns time alligned to UTC+0 */
static time_t timestamp_to_time(const char *tsp)
{
	struct tm tm_time;
	time_t res;

	/* Example timestamp: "2019-02-11T06:42:31-08:00" */
	memset(&tm_time, 0, sizeof(tm_time));
	strptime(tsp, "%Y-%m-%dT%H:%M:%S", &tm_time);

	tzset();
	res = mktime(&tm_time);

	/* Allign by toff to get UTC+0 */
	res += timestamp_get_off_sec(tsp);

	return res;
}

static struct timespec time_to_timespec(time_t t)
{
	struct timespec res = {};

	res.tv_sec = t;
	res.tv_nsec = 0;

	return res;
}

/* converts timestamp string to timespec struct
 * adj_rtime true: adjust for realtime (ignore off time)
 */
struct timespec LIBEASY_API timestamp_to_timespec(const char *tsp, bool adj_rtime)
{
	time_t tt = 0;

	tt = timestamp_to_time(tsp);
	if (adj_rtime)
		tt -= timestamp_get_off_sec(tsp);

	return time_to_timespec(tt);
}
