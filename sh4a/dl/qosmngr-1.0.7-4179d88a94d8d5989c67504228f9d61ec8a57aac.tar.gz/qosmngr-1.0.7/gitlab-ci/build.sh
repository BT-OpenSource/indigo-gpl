#!/bin/bash
set -e
echo "build stage"
pwd
make
