#include "common.h"

typedef struct {
	const char *name;
	int (*init)();
	int (*exit)();
} questd_module_t;

int modules_init();
int modules_exit();
