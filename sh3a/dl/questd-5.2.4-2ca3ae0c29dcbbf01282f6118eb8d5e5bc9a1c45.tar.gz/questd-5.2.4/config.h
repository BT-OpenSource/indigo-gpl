void config_db_init();
void config_db_cleanup();
void config_db_board_get_option(const char *opt, const char **val);
