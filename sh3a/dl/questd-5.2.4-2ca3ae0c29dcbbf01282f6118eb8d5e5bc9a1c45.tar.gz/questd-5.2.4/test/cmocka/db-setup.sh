#!/bin/sh

if [ "$1" = "show" ]; then
	uci -c /etc/board-db/config show
else
	mkdir -p /etc/board-db/config
	echo config board 'board' > /etc/board-db/config/hw
	# board info
	uci set /etc/board-db/config/hw.board.iopVerCustomer="IOPSYS"
	uci set /etc/board-db/config/hw.board.basemac="11:22:33:44:55:66"
	uci set /etc/board-db/config/hw.board.model_name="DG400PRIME"
	uci set /etc/board-db/config/hw.board.serial_number="00000000"
	uci set /etc/board-db/config/hw.board.hardware_version="1.0"
	uci set /etc/board-db/config/hw.board.iopVerTag="5.6.7"
	uci set /etc/board-db/config/hw.board.iopVersion="DG400PRIME-X-IOPSYS-5.6.7-191121_1040"
fi
