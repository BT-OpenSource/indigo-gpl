#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include <libubus.h>
#include <libubox/blobmsg_json.h>
#include <libubox/blobmsg.h>

#include <json-c/json_tokener.h>

#include <system.h>
#include <config.h>

#define _DEBUG_ 1
#define DEBUG(...) if (_DEBUG_) printf(__VA_ARGS__)

/* forward declarations */

int system_info(struct ubus_context *ctx, struct ubus_object *obj,
		  struct ubus_request_data *req, const char *method,
		  struct blob_attr *msg);
int system_memory(struct ubus_context *ctx, struct ubus_object *obj,
		  struct ubus_request_data *req, const char *method,
		  struct blob_attr *msg);
int system_process(struct ubus_context *ctx, struct ubus_object *obj,
		  struct ubus_request_data *req, const char *method,
		  struct blob_attr *msg);
int system_processes(struct ubus_context *ctx, struct ubus_object *obj,
		  struct ubus_request_data *req, const char *method,
		  struct blob_attr *msg);
int system_filesystem(struct ubus_context *ctx, struct ubus_object *obj,
		  struct ubus_request_data *req, const char *method,
		  struct blob_attr *msg);

/* global variables */
static struct blob_buf bb = {0};
static char *msg_sent = NULL;

static void reset_msg_sent()
{
	if (msg_sent) {
		free(msg_sent);
		msg_sent = NULL;
	}
}

/**
 * override libubus function
 */
int ubus_send_reply(struct ubus_context *ctx __attribute__((unused)),
		struct ubus_request_data *req __attribute__((unused)),
		struct blob_attr *msg)
{
	reset_msg_sent();
	if (msg)
		msg_sent = blobmsg_format_json(msg, true);
	return 0;
}

/*
 * override the following function so that is does nothing
 */
int quest_add_object(struct ubus_object *obj __attribute__((unused)))
{
	return 0;
}

/*
 * test purpose: checks if we got at least one parameter
 */
static void test_system_info()
{
	assert_true(system_info(NULL, NULL, NULL, NULL, NULL) == 0);
	assert_non_null(msg_sent);
	DEBUG("info:\n%s\n", msg_sent);
	assert_non_null(strstr(msg_sent, "\"serial_number\":\"00000000\""));
}

/*
 * test purpose: checks if we got at least one parameter
 */
static void test_system_memory()
{
	assert_true(system_memory(NULL, NULL, NULL, NULL, NULL) == 0);
	assert_non_null(msg_sent);
	DEBUG("memory:\n%s\n", msg_sent);
	assert_non_null(strstr(msg_sent, "\"total\":"));
}

/*
 * test purpose: checks if we got at least one parameter
 */
static void test_system_process()
{
	assert_true(system_process(NULL, NULL, NULL, NULL, NULL) == 0);
	assert_non_null(msg_sent);
	DEBUG("process:\n%s\n", msg_sent);
	assert_non_null(strstr(msg_sent, "\"cpu_usage\":"));
}

/*
 * test purpose: checks if there are at least one process in the list
 * pid 1 should always exist
 */
static void test_system_processes()
{
	assert_true(system_processes(NULL, NULL, NULL, NULL, NULL) == 0);
	assert_non_null(msg_sent);
	DEBUG("processes:\n%s\n", msg_sent);
	assert_non_null(strstr(msg_sent, "\"pid\":1"));
}

/*
 * test purpose: check if we got at least one parameter
 */
static void test_system_filesystem()
{
	assert_true(system_filesystem(NULL, NULL, NULL, NULL, NULL) == 0);
	assert_non_null(msg_sent);
	DEBUG("filesystem:\n%s\n", msg_sent);
	assert_non_null(strstr(msg_sent, "\"available\""));
}

/**
 * This is run once before all group tests
 */
static int group_setup(void **state __attribute__((unused)))
{
	assert_true(system("sudo ./db-setup.sh") == 0);

	config_db_init();
        system_init();

	return 0;
}

static int group_teardown(void **state __attribute__((unused)))
{
	system_exit();
	config_db_cleanup();
	blob_buf_free(&bb);
	reset_msg_sent();
	return 0;
}

int main(void)
{
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_system_info),
		cmocka_unit_test(test_system_memory),
		cmocka_unit_test(test_system_process),
		cmocka_unit_test(test_system_processes),
		cmocka_unit_test(test_system_filesystem),
	};
	return cmocka_run_group_tests(tests, group_setup, group_teardown);
}
