#include <sys/types.h>
#include <dirent.h>

/* minimum 16 */
enum { COMM_LEN = 16 };

typedef struct procps_status_t {
	DIR *dir;
	uint8_t shift_pages_to_bytes;
	uint8_t shift_pages_to_kb;
	/* Everything below must contain no ptrs to malloc'ed data:
	 * it is memset(0) for each process in procps_scan() */
	unsigned long vsz, rss; /* we round it to kbytes */
	unsigned long stime, utime;
	unsigned long start_time;
	unsigned pid;
	unsigned ppid;
	unsigned pgid;
	unsigned sid;
	int priority;
	int niceness;
	char state;
	/* basename of executable in exec(2), read from /proc/N/stat
	 * (if executable is symlink or script, it is NOT replaced
	 * by link target or interpreter name) */
	char comm[COMM_LEN];
} procps_status_t;

procps_status_t* procps_scan(procps_status_t* sp);
void procps_get_cmdline(char *buf, int bufsz, unsigned pid, const char *comm);
