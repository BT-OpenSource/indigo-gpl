/*
 * static board info
 */
typedef struct {
	const char *manufacturer;
	const char *basemac;
	const char *model_name;
	const char *serial_number;
        const char *hardware_version;
        const char *software_version;
	const char *active_firmware_image;
} board_info_t;

/*
 * memory info
 */
typedef struct {
	unsigned long total;
	//unsigned long used;
	unsigned long free;
	unsigned long shared;
	unsigned long buffers;
} memory_t;

typedef struct jiffy_counts_t {
	unsigned long long usr, nic, sys, idle;
	unsigned long long iowait, irq, softirq, steal;
	unsigned long long total;
	unsigned long long busy;
} jiffy_counts_t;

int system_init();
int system_exit();
