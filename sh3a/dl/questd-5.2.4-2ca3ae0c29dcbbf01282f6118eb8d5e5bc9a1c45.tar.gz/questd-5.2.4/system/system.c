/*
 * system -- provides router.system object of questd
 *
 * Copyright (C) 2020 IOPSYS Software Solutions AB. All rights reserved.
 *
 * Author: sukru.senli@iopsys.eu
 *	   oussama.ghorbel@iopsys.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <crypt.h>
#include <shadow.h>
#include <fcntl.h>
#include <sys/wait.h>

#include <libubox/blobmsg.h>
#include <libubus.h>
#include <time.h>
#include <sys/sysinfo.h>
#include <sys/utsname.h>
#include <string.h>

#include <sys/types.h>
#include <dirent.h>

#include "system.h"
#include "tools.h"
#include "config.h"
#include "procps.h"
#include "questd.h"

static struct blob_buf bb = {0};
static board_info_t board_info = {0};

/**
 * init static board information
 */
static void init_board_info(board_info_t *b)
{
	config_db_board_get_option("iopVerCustomer", &b->manufacturer);
	config_db_board_get_option("basemac", &b->basemac);
	config_db_board_get_option("model_name", &b->model_name);
	config_db_board_get_option("serial_number", &b->serial_number);
	config_db_board_get_option("hardware_version", &b->hardware_version);
	config_db_board_get_option("iopVerTag", &b->software_version);
	config_db_board_get_option("iopVersion", &b->active_firmware_image);
}

static int get_memory(memory_t *m)
{
        struct sysinfo sinfo;

        if (sysinfo(&sinfo) == 0) {
                m->total = (sinfo.totalram / 1024);
                m->free = (sinfo.freeram / 1024);
                //m->used = ((sinfo.totalram - sinfo.freeram) / 1024);
                m->shared = (sinfo.sharedram / 1024);
                m->buffers = (sinfo.bufferram / 1024);
                return 0;
        }
        return -1;
}

static void get_jif_val(jiffy_counts_t *p_jif)
{
	FILE *file;
	char line[128];
	int ret;

	if ((file = fopen("/proc/stat", "r"))) {
		while(fgets(line, sizeof(line), file) != NULL)
		{
			remove_newline(line);
			ret = sscanf(line, "cpu %llu %llu %llu %llu %llu %llu %llu %llu", &p_jif->usr, &p_jif->nic, &p_jif->sys, &p_jif->idle,
				&p_jif->iowait, &p_jif->irq, &p_jif->softirq, &p_jif->steal);

			if (ret >= 4) {
				p_jif->total = p_jif->usr + p_jif->nic + p_jif->sys + p_jif->idle
					+ p_jif->iowait + p_jif->irq + p_jif->softirq + p_jif->steal;

				p_jif->busy = p_jif->total - p_jif->idle - p_jif->iowait;
				break;
			}
		}
		fclose(file);
	}
}

static unsigned int get_cpu_load(jiffy_counts_t *prev_jif, jiffy_counts_t *cur_jif)
{
        unsigned total_diff, cpu;

        total_diff = (unsigned)(cur_jif->total - prev_jif->total);

        if (total_diff == 0)
                total_diff = 1;

        cpu = 100 * (unsigned)(cur_jif->busy - prev_jif->busy) / total_diff;

        return cpu;
}

static unsigned int get_cpu_usage()
{
        jiffy_counts_t prev_jif = {0};
        jiffy_counts_t cur_jif = {0};

        get_jif_val(&prev_jif);
        usleep(100000);
        get_jif_val(&cur_jif);

        return get_cpu_load(&prev_jif, &cur_jif);
}

/* ubus object handlers */
int system_info(struct ubus_context *ctx, struct ubus_object *obj __attribute__((unused)),
		  struct ubus_request_data *req, const char *method __attribute__((unused)),
		  struct blob_attr *msg __attribute__((unused)))
{
	struct sysinfo sinfo;
	struct utsname utsname;
	unsigned int uptime = 0;
	unsigned int localtime;

	if (sysinfo(&sinfo) == 0)
		uptime = sinfo.uptime;
	localtime = (int)time(NULL);

	blob_buf_init(&bb, 0);

	blobmsg_add_string(&bb, "manufacturer", board_info.manufacturer);
	blobmsg_add_string(&bb, "model_name", board_info.model_name);
	blobmsg_add_string(&bb, "basemac", board_info.basemac);
	blobmsg_add_string(&bb, "serial_number", board_info.serial_number);
	blobmsg_add_string(&bb, "hardware_version", board_info.hardware_version);
	blobmsg_add_string(&bb, "software_version", board_info.software_version);
	blobmsg_add_string(&bb, "active_firmware_image", board_info.active_firmware_image);

	if (uname(&utsname) >= 0)
	{
		blobmsg_add_string(&bb, "kernel", utsname.release);
		blobmsg_add_string(&bb, "hostname", utsname.nodename);
	}

	blobmsg_add_u32(&bb, "uptime", uptime);
	blobmsg_add_u32(&bb, "localtime", localtime);

	ubus_send_reply(ctx, req, bb.head);

	return 0;
}

int system_memory(struct ubus_context *ctx, struct ubus_object *obj __attribute__((unused)),
		  struct ubus_request_data *req, const char *method __attribute__((unused)),
		  struct blob_attr *msg __attribute__((unused)))
{
        memory_t m = {0};

	if (get_memory(&m))
                return UBUS_STATUS_NO_DATA;

	blob_buf_init(&bb, 0);

	blobmsg_add_u64(&bb, "total", m.total);
	blobmsg_add_u64(&bb, "free", m.free);
	//blobmsg_add_u64(&bb, "used", m.used);
	blobmsg_add_u64(&bb, "shared", m.shared);
	blobmsg_add_u64(&bb, "buffers", m.buffers);

	ubus_send_reply(ctx, req, bb.head);

	return 0;
}

int system_process(struct ubus_context *ctx, struct ubus_object *obj __attribute__((unused)),
		  struct ubus_request_data *req, const char *method __attribute__((unused)),
		  struct blob_attr *msg __attribute__((unused)))
{
	struct sysinfo sinfo;
	unsigned int procs = 0;
        unsigned int cpu;


	if (sysinfo(&sinfo) == 0)
		procs = sinfo.procs;
        cpu = get_cpu_usage();

        blob_buf_init(&bb, 0);

        blobmsg_add_u32(&bb, "cpu_usage", cpu);
        blobmsg_add_u32(&bb, "process_num", procs);

        ubus_send_reply(ctx, req, bb.head);

        return 0;
}

static const char* get_proc_state(char state)
{
	switch(state) {
		case 'R':
			return "Running";
		case 'S':
			return "Sleeping";
		case 'T':
			return "Stopped";
		case 'D':
			return "Uninterruptible";
		case 'Z':
			return "Zombie";
		case 'I':
			return "Idle";

	};
	return "Unknown";
}

int system_processes(struct ubus_context *ctx, struct ubus_object *obj __attribute__((unused)),
		  struct ubus_request_data *req, const char *method __attribute__((unused)),
		  struct blob_attr *msg __attribute__((unused)))
{
	void *a,*t;
        procps_status_t *p = NULL;
        memory_t m = {0};
	char cmd[256];
	int cputime;

	if (get_memory(&m))
                return UBUS_STATUS_NO_DATA;

	blob_buf_init(&bb, 0);

	a = blobmsg_open_array(&bb, "processes");
	while((p = procps_scan(p)) != NULL) {
		cputime = ((p->stime / sysconf(_SC_CLK_TCK)) + (p->utime / sysconf(_SC_CLK_TCK))) * 1000;
		procps_get_cmdline(cmd, sizeof(cmd), p->pid, p->comm);

		t = blobmsg_open_table(&bb, "");
		blobmsg_add_u32(&bb, "pid", p->pid);
		blobmsg_add_u32(&bb, "ppid", p->ppid);
		blobmsg_add_string(&bb, "command", cmd);
		blobmsg_add_u32(&bb, "vsz", p->vsz);
		blobmsg_add_u32(&bb, "%vsz", ((long long)(p->vsz * 100))/m.total);
		blobmsg_add_u32(&bb, "priority", p->priority);
		blobmsg_add_u32(&bb, "niceness", p->niceness);
		blobmsg_add_u32(&bb, "cputime", cputime);
		blobmsg_add_string(&bb, "state", get_proc_state(p->state));
		blobmsg_close_table(&bb, t);
	}
	blobmsg_close_array(&bb, a);

	ubus_send_reply(ctx, req, bb.head);

	return 0;
}

int system_filesystem(struct ubus_context *ctx, struct ubus_object *obj __attribute__((unused)),
		  struct ubus_request_data *req, const char *method __attribute__((unused)),
		  struct blob_attr *msg __attribute__((unused)))
{
	void *a,*t;
	FILE *df;
	char line[128];
	char name[65];
	char mounted_on[129];
	char use_per[6];
	int blocks, used, available;

	blob_buf_init(&bb, 0);
	if ((df = popen("df", "r"))) {
		a = blobmsg_open_array(&bb, "filesystem");
		while(fgets(line, sizeof(line), df) != NULL)
		{
			remove_newline(line);
			single_space(line);
			if (sscanf(line, "%64s %d %d %d %5s %128s", name, &blocks, &used, &available, use_per, mounted_on) == 6) {
				use_per[strlen(use_per)-1] = '\0';
				t = blobmsg_open_table(&bb, "");
				blobmsg_add_string(&bb, "name", name);
				blobmsg_add_u32(&bb, "1kblocks", blocks);
				blobmsg_add_u32(&bb, "used", used);
				blobmsg_add_u32(&bb, "available", available);
				blobmsg_add_u32(&bb, "usage", atoi(use_per));
				blobmsg_add_string(&bb, "mounted_on", mounted_on);
				blobmsg_close_table(&bb, t);
			}
		}
		blobmsg_close_array(&bb, a);
		pclose(df);
	}
	ubus_send_reply(ctx, req, bb.head);
	return 0;
}

static struct ubus_method system_object_methods[] = {
	UBUS_METHOD_NOARG("info", system_info),
	UBUS_METHOD_NOARG("memory", system_memory),
	UBUS_METHOD_NOARG("process", system_process),
	UBUS_METHOD_NOARG("processes", system_processes),
	UBUS_METHOD_NOARG("filesystem", system_filesystem),
};

static struct ubus_object_type system_object_type = UBUS_OBJECT_TYPE("system", system_object_methods);

struct ubus_object system_object = {
	.name = "router.system",
	.type = &system_object_type,
	.methods = system_object_methods,
	.n_methods = ARRAY_SIZE(system_object_methods),
};

int system_init()
{
	int r;
        init_board_info(&board_info);
	r = quest_add_object(&system_object);
	return r;
}

int system_exit()
{
	blob_buf_free(&bb);
	return 0;
}
