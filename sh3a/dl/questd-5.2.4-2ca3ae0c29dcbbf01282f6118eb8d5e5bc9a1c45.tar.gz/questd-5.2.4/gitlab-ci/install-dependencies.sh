#!/bin/bash
set -e
echo "Installing easy-soc-libs"
pwd

cd /opt/dev

cd /opt/dev
rm -rf wifimngr
git clone https://dev.iopsys.eu/iopsys/wifimngr.git
cd wifimngr
git checkout devel
bash ./gitlab-ci/install-dependencies.sh
make
cp -a wifimngr /usr/sbin


cd /opt/dev
rm -rf jsonpath
git clone https://git.openwrt.org/project/jsonpath.git
cd jsonpath
cmake .
make
cp -a jsonpath /usr/bin/jsonfilter

apt update
apt install -y bridge-utils iproute2 gawk
