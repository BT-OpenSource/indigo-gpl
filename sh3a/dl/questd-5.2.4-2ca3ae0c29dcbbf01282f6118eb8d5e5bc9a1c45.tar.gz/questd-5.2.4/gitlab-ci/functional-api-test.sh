
#!/bin/bash
set -e
echo "preparation script"
pwd


supervisorctl status all
supervisorctl update
sleep 3
supervisorctl status all

# run API validation
ubus-api-validator -d /builds/iopsys/questd/test/api/json/ > /builds/iopsys/questd/api-result.log

tap-junit --input ./api-result.log --output report

supervisorctl stop all




