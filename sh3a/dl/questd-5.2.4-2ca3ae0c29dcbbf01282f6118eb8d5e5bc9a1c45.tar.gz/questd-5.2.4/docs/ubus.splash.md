# Ubus Generated APIs

* [Network](./api/router.network.md)
* [System](./api/router.system.md)

