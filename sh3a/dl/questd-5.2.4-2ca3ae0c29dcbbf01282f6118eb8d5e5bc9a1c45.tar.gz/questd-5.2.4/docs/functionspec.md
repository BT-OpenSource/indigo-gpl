# Function Specification

The scope of questd is to expose the network and system information over ubus.

```
root@dc667cfd1b01:/builds/iopsys/questd# ubus -v list

'router.network' @ec341e9c
        "dump":{}
        "clients":{}
        "hosts":{}
        "reload":{}
'router.system' @ba65a953
        "info":{}
        "memory":{}
        "process":{}
        "processes":{}
        "filesystem":{}
```

# Contents

- [network](#network)
- [system](#system)

## APIs

Questd publishes two different types of objects, `network` and `system`

### network

An object that publishes network information.

| Method            | Function ID |
| :---------------- | :---------- |
| [hosts](#hosts)   | 1           |
| [reload](#reload) | 2           |

#### Methods

Methods descriptions of the `network` object.

##### hosts

Displays the client information such as mac address, ip address, connection type.

- [hosts documentation](./api/router.network.md#hosts)

##### reload

Reloads the network configuration of the gateway.

- [reload documentation](./api/router.network.md#reload)

### system

An object that publishes system information.

| Method                    | Function ID |
| :------------------------ | :---------- |
| [info](#info)             | 3           |
| [memory](#memory)         | 4           |
| [process](#hosts)         | 5           |
| [processes](#processes)   | 6           |
| [filesystem](#filesystem) | 7           |

#### Methods

Method descriptions of the `system` object.

##### info

Displays the general system information such as model name, kernel version, and serial number of the gateway over ubus.

- [info documentation](./api/router.system.md#info)

##### memory

Displays the total and free memory of the gateway over ubus.

- [memory documentation](./api/router.system.md#memory)

##### process

Displays the process information of this ubus call.

- [process documentation](./api/router.system.md#process)

##### processes

Displays information about the all processess running inside the gateway operating system.

- [processes documentation](./api/router.system.md#processes)

##### filesystem

Displays information about the filesystem of the gateway operating system.

- [filesystem documentation](./api/router.system.md#filesystem)
