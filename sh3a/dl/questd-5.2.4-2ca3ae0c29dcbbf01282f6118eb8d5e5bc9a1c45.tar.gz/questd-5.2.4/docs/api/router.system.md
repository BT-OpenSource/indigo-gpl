# System Schema

```
http://www.iosys.eu/router.system.json
```

| Custom Properties | Additional Properties |
| ----------------- | --------------------- |
| Forbidden         | Permitted             |

# System Information Object

| List of Methods           |
| ------------------------- |
| [filesystem](#filesystem) | Method | System Information Object (this schema) |
| [info](#info)             | Method | System Information Object (this schema) |
| [memory](#memory)         | Method | System Information Object (this schema) |
| [process](#process)       | Method | System Information Object (this schema) |
| [processes](#processes)   | Method | System Information Object (this schema) |

## filesystem

`filesystem`

- type: `Method`

### filesystem Type

`object` with following properties:

| Property | Type   | Required |
| -------- | ------ | -------- |
| `input`  | object | Optional |
| `output` | object | Optional |

#### input

`input`

- is optional
- type: `object`

##### input Type

`object` with following properties:

| Property | Type | Required |
| -------- | ---- | -------- |
| None     | None | None     |

### Ubus CLI Example

```
ubus call System Information Object filesystem {}
```

### JSONRPC Example

```json
{ "jsonrpc": "2.0", "id": 0, "method": "call", "params": ["<SID>", "System", "filesystem", {}] }
```

#### output

`output`

- is optional
- type: `object`

##### output Type

`object` with following properties:

| Property     | Type  | Required     |
| ------------ | ----- | ------------ |
| `filesystem` | array | **Required** |

#### filesystem

`filesystem`

- is **required**
- type: `object[]`

##### filesystem Type

Array type: `object[]`

All items must be of the type: `object` with following properties:

| Property     | Type    | Required     |
| ------------ | ------- | ------------ |
| `1kblocks`   | integer | **Required** |
| `available`  | integer | **Required** |
| `mounted_on` | string  | **Required** |
| `name`       | string  | **Required** |
| `usage`      | integer | **Required** |
| `used`       | integer | **Required** |

#### 1kblocks

`1kblocks`

- is **required**
- type: `integer`

##### 1kblocks Type

`integer`

#### available

`available`

- is **required**
- type: `integer`

##### available Type

`integer`

#### mounted_on

`mounted_on`

- is **required**
- type: `string`

##### mounted_on Type

`string`

#### name

`name`

- is **required**
- type: `string`

##### name Type

`string`

#### usage

`usage`

- is **required**
- type: `integer`

##### usage Type

`integer`

#### used

`used`

- is **required**
- type: `integer`

##### used Type

`integer`

### Output Example

```json
{
  "filesystem": [
    {
      "name": "proident",
      "1kblocks": 45926442,
      "used": -37044663,
      "available": -52353306,
      "usage": 7488855,
      "mounted_on": "Lorem reprehenderit i"
    },
    {
      "name": "proident ipsum quis dolore",
      "1kblocks": 98688733,
      "used": -92959720,
      "available": -79180383,
      "usage": 57045738,
      "mounted_on": "dolore laborum ea proident"
    },
    {
      "name": "commodo occaecat",
      "1kblocks": 40030548,
      "used": 15617438,
      "available": -22608575,
      "usage": -34722552,
      "mounted_on": "velit ut"
    },
    {
      "name": "Ut eu magna velit nostrud",
      "1kblocks": 29552184,
      "used": 20547036,
      "available": -27228773,
      "usage": 10546668,
      "mounted_on": "esse ad in ut"
    },
    {
      "name": "fugiat in aliquip eu",
      "1kblocks": -84677635,
      "used": -36089586,
      "available": 18860790,
      "usage": -56812288,
      "mounted_on": "esse culpa proident"
    }
  ]
}
```

## info

`info`

- type: `Method`

### info Type

`object` with following properties:

| Property | Type   | Required |
| -------- | ------ | -------- |
| `input`  | object | Optional |
| `output` | object | Optional |

#### input

`input`

- is optional
- type: `object`

##### input Type

`object` with following properties:

| Property | Type | Required |
| -------- | ---- | -------- |
| None     | None | None     |

### Ubus CLI Example

```
ubus call System Information Object info {}
```

### JSONRPC Example

```json
{ "jsonrpc": "2.0", "id": 0, "method": "call", "params": ["<SID>", "System", "info", {}] }
```

#### output

`output`

- is optional
- type: `object`

##### output Type

`object` with following properties:

| Property                | Type    | Required     |
| ----------------------- | ------- | ------------ |
| `active_firmware_image` | string  | **Required** |
| `basemac`               | string  | **Required** |
| `hardware_version`      | string  | **Required** |
| `hostname`              | string  | **Required** |
| `kernel`                | string  | **Required** |
| `localtime`             | integer | **Required** |
| `manufacturer`          | string  | **Required** |
| `model_name`            | string  | **Required** |
| `serial_number`         | string  | **Required** |
| `software_version`      | string  | **Required** |
| `uptime`                | integer | **Required** |

#### active_firmware_image

`active_firmware_image`

- is **required**
- type: `string`

##### active_firmware_image Type

`string`

#### basemac

`basemac`

- is **required**
- type: reference

##### basemac Type

`string`

All instances must conform to this regular expression (test examples
[here](<https://regexr.com/?expression=%5E(%5B0-9A-Fa-f%5D%7B2%7D%5B%3A-%5D)%7B5%7D(%5B0-9A-Fa-f%5D%7B2%7D)%24>)):

```regex
^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$
```

#### hardware_version

`hardware_version`

- is **required**
- type: `string`

##### hardware_version Type

`string`

#### hostname

`hostname`

- is **required**
- type: `string`

##### hostname Type

`string`

#### kernel

`kernel`

- is **required**
- type: `string`

##### kernel Type

`string`

#### localtime

`localtime`

- is **required**
- type: `integer`

##### localtime Type

`integer`

#### manufacturer

`manufacturer`

- is **required**
- type: `string`

##### manufacturer Type

`string`

#### model_name

`model_name`

- is **required**
- type: `string`

##### model_name Type

`string`

#### serial_number

`serial_number`

- is **required**
- type: `string`

##### serial_number Type

`string`

#### software_version

`software_version`

- is **required**
- type: `string`

##### software_version Type

`string`

#### uptime

`uptime`

- is **required**
- type: `integer`

##### uptime Type

`integer`

### Output Example

```json
{
  "manufacturer": "aute",
  "basemac": "C8:33-2a:D2-ec-41",
  "model_name": "pariatur cupidatat Lorem",
  "serial_number": "qui enim Excepteur velit",
  "hardware_version": "id Excepteur adipisicing do",
  "software_version": "laborum",
  "active_firmware_image": "aliqua eiusmod",
  "kernel": "minim mollit occaecat",
  "hostname": "in do est",
  "uptime": 80898595,
  "localtime": 32676262
}
```

## memory

`memory`

- type: `Method`

### memory Type

`object` with following properties:

| Property | Type   | Required |
| -------- | ------ | -------- |
| `input`  | object | Optional |
| `output` | object | Optional |

#### input

`input`

- is optional
- type: `object`

##### input Type

`object` with following properties:

| Property | Type | Required |
| -------- | ---- | -------- |
| None     | None | None     |

### Ubus CLI Example

```
ubus call System Information Object memory {}
```

### JSONRPC Example

```json
{ "jsonrpc": "2.0", "id": 0, "method": "call", "params": ["<SID>", "System", "memory", {}] }
```

#### output

`output`

- is optional
- type: `object`

##### output Type

`object` with following properties:

| Property  | Type    | Required     |
| --------- | ------- | ------------ |
| `buffers` | integer | **Required** |
| `free`    | integer | **Required** |
| `shared`  | integer | **Required** |
| `total`   | integer | **Required** |

#### buffers

`buffers`

- is **required**
- type: `integer`

##### buffers Type

`integer`

#### free

`free`

- is **required**
- type: `integer`

##### free Type

`integer`

#### shared

`shared`

- is **required**
- type: `integer`

##### shared Type

`integer`

#### total

`total`

- is **required**
- type: `integer`

##### total Type

`integer`

### Output Example

```json
{ "total": -42770237, "free": -15940536, "shared": 29164853, "buffers": 28649026 }
```

## process

`process`

- type: `Method`

### process Type

`object` with following properties:

| Property | Type   | Required |
| -------- | ------ | -------- |
| `input`  | object | Optional |
| `output` | object | Optional |

#### input

`input`

- is optional
- type: `object`

##### input Type

`object` with following properties:

| Property | Type | Required |
| -------- | ---- | -------- |
| None     | None | None     |

### Ubus CLI Example

```
ubus call System Information Object process {}
```

### JSONRPC Example

```json
{ "jsonrpc": "2.0", "id": 0, "method": "call", "params": ["<SID>", "System", "process", {}] }
```

#### output

`output`

- is optional
- type: `object`

##### output Type

`object` with following properties:

| Property      | Type    | Required     |
| ------------- | ------- | ------------ |
| `cpu_usage`   | integer | **Required** |
| `process_num` | integer | **Required** |

#### cpu_usage

`cpu_usage`

- is **required**
- type: `integer`

##### cpu_usage Type

`integer`

#### process_num

`process_num`

- is **required**
- type: `integer`

##### process_num Type

`integer`

### Output Example

```json
{ "cpu_usage": 35246546, "process_num": -8040255 }
```

## processes

`processes`

- type: `Method`

### processes Type

`object` with following properties:

| Property | Type   | Required |
| -------- | ------ | -------- |
| `input`  | object | Optional |
| `output` | object | Optional |

#### input

`input`

- is optional
- type: `object`

##### input Type

`object` with following properties:

| Property | Type | Required |
| -------- | ---- | -------- |
| None     | None | None     |

### Ubus CLI Example

```
ubus call System Information Object processes {}
```

### JSONRPC Example

```json
{ "jsonrpc": "2.0", "id": 0, "method": "call", "params": ["<SID>", "System", "processes", {}] }
```

#### output

`output`

- is optional
- type: `object`

##### output Type

`object` with following properties:

| Property    | Type  | Required     |
| ----------- | ----- | ------------ |
| `processes` | array | **Required** |

#### processes

`processes`

- is **required**
- type: `object[]`

##### processes Type

Array type: `object[]`

All items must be of the type: `object` with following properties:

| Property   | Type    | Required     |
| ---------- | ------- | ------------ |
| `%vsz`     | integer | **Required** |
| `command`  | string  | **Required** |
| `cputime`  | integer | **Required** |
| `niceness` | integer | **Required** |
| `pid`      | integer | **Required** |
| `ppid`     | integer | **Required** |
| `priority` | integer | **Required** |
| `state`    | string  | **Required** |
| `vsz`      | integer | **Required** |

#### %vsz

`%vsz`

- is **required**
- type: `integer`

##### %vsz Type

`integer`

#### command

`command`

- is **required**
- type: `string`

##### command Type

`string`

#### cputime

`cputime`

- is **required**
- type: `integer`

##### cputime Type

`integer`

#### niceness

`niceness`

- is **required**
- type: `integer`

##### niceness Type

`integer`

#### pid

`pid`

- is **required**
- type: `integer`

##### pid Type

`integer`

#### ppid

`ppid`

- is **required**
- type: `integer`

##### ppid Type

`integer`

#### priority

`priority`

- is **required**
- type: `integer`

##### priority Type

`integer`

#### state

`state`

- is **required**
- type: `string`

##### state Type

`string`

#### vsz

`vsz`

- is **required**
- type: `integer`

##### vsz Type

`integer`

### Output Example

```json
{
  "processes": [
    {
      "pid": -92148311,
      "ppid": -23539399,
      "command": "nostrud ut culpa Excepteur nulla",
      "vsz": 11993797,
      "%vsz": -93674380,
      "priority": 80077465,
      "niceness": 17517803,
      "cputime": 70208496,
      "state": "pariatur nisi voluptate"
    }
  ]
}
```
