#!/bin/bash

echo "install dependencies of uspd"
pwd

source ./gitlab-ci/shared.sh

# install required packages
exec_cmd apt update
exec_cmd apt install -y python3-pip
exec_cmd pip3 install pexpect ubus

# install libbbf
cd /opt/dev
rm -rf bbf

if [ -z "${BBF_TAR_URL}" ]; then
	exec_cmd git clone https://dev.iopsys.eu/iopsys/bbf.git
	cd bbf

	echo "BBF Upstream Hash ${UPSTREAM_BBF_SHA}"
	if [ -n "${UPSTREAM_BBF_SHA}" ]; then
		exec_cmd git checkout ${UPSTREAM_BBF_SHA}
	fi
	git log -1

	source ./gitlab-ci/shared.sh
	install_libbbf
	./gitlab-ci/setup.sh
else
	echo "## Installing upstream libbbf release from [${BBF_TAR_URL}] ##"
	mkdir -p bbf
	cd bbf
	exec_cmd wget -q ${BBF_TAR_URL} -O bbf.sh
	chmod +x bbf.sh
	./bbf.sh --prefix=/ --exclude-subdir --skip-license
	ldconfig
	cd ..
fi

