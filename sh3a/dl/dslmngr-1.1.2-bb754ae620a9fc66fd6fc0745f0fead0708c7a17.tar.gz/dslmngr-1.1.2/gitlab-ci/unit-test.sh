#!/bin/bash
set -e
echo "preparation script"

pwd

make unit-test -C ./

# report part
# GitLab-CI output
gcovr -r .
# Artefact
gcovr -r . --html --html-details -o ./unit-test-coverage.html
