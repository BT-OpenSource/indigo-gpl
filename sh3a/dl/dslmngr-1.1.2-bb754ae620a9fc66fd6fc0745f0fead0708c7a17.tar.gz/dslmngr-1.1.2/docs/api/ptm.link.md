# ptm.link.&lt;number&gt;

| List of Methods                   |
| --- |
| [status](#status)                 |

## status

`status`

Type: `Method`

### Ubus CLI Example

```bash
ubus call ptm.link.1 status
```

### JSONRPC Example

```json
{
  "jsonrpc": "2.0",
  "id": 0,
  "method": "call",
  "params": ["<SID>", "ptm.link.1", "status"]
}
```

### Input

None

### Output

- type: `object`
- Example as below
```json
{
        "status": "up",
        "mac_addr": "00:11:22:33:44:55"
}
```
