#!/bin/bash

echo "install dependencies"

# libeasy.so
rm -fr libeasy
mkdir -p /usr/include/easy
git clone -b devel https://dev.iopsys.eu/hal/libeasy.git
cd libeasy
make
cp -a libeasy*.so* /usr/lib
cp -a *.h /usr/include/easy/
