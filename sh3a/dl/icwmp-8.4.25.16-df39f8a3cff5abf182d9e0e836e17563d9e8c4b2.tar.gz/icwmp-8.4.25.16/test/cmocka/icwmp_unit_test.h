#ifndef ICWMP_UNIT_TEST
#define ICWMP_UNIT_TEST
int icwmp_backup_session_test(void);
int icwmp_cli_unit_test(void);
int icwmp_custom_inform_test(void);
int icwmp_datamodel_interface_test(void);
int icwmp_download_unit_test(void);
int icwmp_notifications_test(void);
int icwmp_soap_msg_test(void);
int icwmp_uci_test(void);
#endif // ICWMP_UNIT_TEST
