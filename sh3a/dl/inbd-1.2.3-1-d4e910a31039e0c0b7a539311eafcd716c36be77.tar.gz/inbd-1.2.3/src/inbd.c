
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>

#include <netlink/netlink.h>
#include <netlink/socket.h>
#include <netlink/genl/ctrl.h>
#include <netlink/genl/genl.h>

#include <netlink/attr.h>

#include <json-c/json.h>

#include "config.h"

#define NETLINK_FAMILY_NAME "easysoc"
#define NETLINK_GROUP_NAME  "notify"

/* attributes */
enum {
	NL_UNSPEC,
	NL_MSG,
	__NL_MAX,
};
#define NL_MAX (__NL_MAX - 1)
#define MAX_MSG 512

static struct nla_policy nl_policy[__NL_MAX] = {
	[NL_MSG] = { .type = NLA_STRING },
};

static struct nlattr *attrs[__NL_MAX];

static void
remove_char(char *buf, char ch)
{
	char newbuf[strlen(buf)+1];
	int i = 0;
	int j = 0;

	while (buf[i]) {
		newbuf[j] = buf[i];
		if (buf[i] != ch)
			j++;
		i++;
	}
	newbuf[j] = '\0';
	strcpy(buf, newbuf);
}

static void
json_get_var(json_object *obj, const char *var, char *value)
{
	json_object_object_foreach(obj, key, val) {
		if(!strcmp(key, var)) {
			switch (json_object_get_type(val)) {
			case json_type_object:
				break;
			case json_type_array:
				break;
			case json_type_string:
				sprintf(value, "%s", json_object_get_string(val));
				break;
			case json_type_boolean:
				sprintf(value, "%d", json_object_get_boolean(val));
				break;
			case json_type_int:
				sprintf(value, "%d", json_object_get_int(val));
				break;
			default:
				break;
			}
		}
	}
}

static void
json_parse_and_get(char *str, const char *var, char *value)
{
	json_object *obj;

	obj = json_tokener_parse(str);
	if (!obj || json_object_get_type(obj) != json_type_object) {
		return;
	}
	json_get_var(obj, var, value);
}

static int process_netlink_message(char *msg)
{
	char event[32];
	char data[128];
	char mode[16];
	char status[32];
	char cmd[MAX_MSG];

	sscanf(msg, "%31s %127[^\n]s", event, data);

	if (strcmp(event, "ethport") == 0) {
		char ifname[16];
		char link[16];

		remove_char(data, '\'');
		json_parse_and_get(data, "ifname", ifname);
		json_parse_and_get(data, "link", link);

		snprintf(cmd, MAX_MSG, "PORT=%s LINK=%s /sbin/hotplug-call ethernet", ifname, link);

		system(cmd);
	} else if (strcmp(event, "dsl") == 0) {
		remove_char(data, '\'');
		json_parse_and_get(data, "mode", mode);
		json_parse_and_get(data, "status", status);

		snprintf(cmd, MAX_MSG, "STATUS=%s MODE=%s /sbin/hotplug-call dsl", status, mode);

		system(cmd);
	}

	return 0;
}

static int netlink_nl_parser(struct nl_msg *msg, void *arg)
{
	struct nlmsghdr *nlh = nlmsg_hdr(msg);
	int ret;
	//char cmd[MAX_MSG];

	if (!genlmsg_valid_hdr(nlh, 0)){
		printf("Got invalid message\n");
		return 0;
	}

	ret = genlmsg_parse(nlh, 0, attrs, NL_MSG, nl_policy);

	if (!ret){

		if (attrs[NL_MSG] ) {
			char *data;

			data = nla_get_string(attrs[NL_MSG]);
			//printf("got message string (%s)\n", data);
			//snprintf(cmd, MAX_MSG, "ubus send %s\n", data);
			//system(cmd);
			process_netlink_message(data);
		}
	}
	return 0;
}

int main (int c, char* argv[])
{
	struct nl_sock *sock;
	int err;
	static int grp;

	sock = nl_socket_alloc();
	if(!sock){
		printf("Error: could not allocate socket\n");
		exit(1);
	}

	err = nl_socket_modify_cb(sock, NL_CB_VALID, NL_CB_CUSTOM, netlink_nl_parser, NULL);

	if (err < 0){
		printf("Error: %d\n", err);
		exit(1);
	}

	if ((err = genl_connect(sock)) < 0){
		printf("Error: %s\n", nl_geterror(err));
		exit(1);
	}

	if ((grp = genl_ctrl_resolve_grp(sock, NETLINK_FAMILY_NAME, NETLINK_GROUP_NAME)) < 0){
		printf("Error: %s (%s grp %s)\n", nl_geterror(grp), NETLINK_FAMILY_NAME, NETLINK_GROUP_NAME);
		exit(1);
	}

	nl_socket_add_membership(sock, grp);

	/* seq number dont really work for multicast so dissable check */
	nl_socket_disable_seq_check(sock);

	while (1) {
		err = nl_recvmsgs_default(sock);
		if (err < 0){
			printf("Error: %s (%s grp %s)\n", nl_geterror(err), NETLINK_FAMILY_NAME, NETLINK_GROUP_NAME);
		}
	}
}
