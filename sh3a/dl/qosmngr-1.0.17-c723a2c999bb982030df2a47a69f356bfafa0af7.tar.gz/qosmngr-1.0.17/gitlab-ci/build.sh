#!/bin/bash
set -e
echo "build stage"
pwd
make CFLAGS='-DBBF_VENDOR_PREFIX=\"X_IOPSYS_EU_\"'
