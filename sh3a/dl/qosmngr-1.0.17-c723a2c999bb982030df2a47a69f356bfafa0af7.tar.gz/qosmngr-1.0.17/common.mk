# Useful to refer to headers not located in the same directory as the source files being compiled
PROJECT_TOPLEVEL := $(dir $(CURDIR)/$(word $(words $(MAKEFILE_LIST)),$(MAKEFILE_LIST)))
INCLUDE_DIR = $(PROJECT_TOPLEVEL)/include

# Common compiler options
CC=gcc # gcc || clang

COMMON_LDFLAGS = -luci -lubus -lubox -ljson-c -lblobmsg_json -lnl-genl-3 -lnl-3 -lqos
QOSMNGR_LIB_DIR	?= $(shell dirname $(PWD))
QOSMNGR_LDFLAGS	= -lqosmngr -L$(QOSMNGR_LIB_DIR)
