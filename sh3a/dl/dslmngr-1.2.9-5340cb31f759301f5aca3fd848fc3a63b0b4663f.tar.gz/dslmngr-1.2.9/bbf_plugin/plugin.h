/*
 * Copyright (C) 2024 iopsys Software Solutions AB
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation
 *
 *		Author: Amit Kumar <amit.kumar@iopsys.eu>
 *
 */

#ifndef __PLUGIN_H__
#define __PLUGIN_H__

#include "libbbfdm-api/dmcommon.h"

extern DMOBJ tDeviceDSLObj[];
extern DMOBJ tDevicePTMObj[];
extern DMOBJ tDeviceATMObj[];
extern DMOBJ tDeviceFASTObj[];

int get_line_linkstatus(json_object *json_obj, char **value);
void remove_device_from_interface(struct uci_section *interface_s, char *device);
#endif

