/*
 * linux_eth.c
 */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <ctype.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <time.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include <linux/mii.h>
#include <linux/ethtool.h>
#include <linux/sockios.h>
#include <easy/easy.h>
#include "ethernet.h"
#include "linux_eth.h"

typedef enum {
    iow_rx_byte = 0,
    iow_rx_packets,
    iow_rx_dropped,
    iow_rx_fraglist_packets,
    iow_rx_nr_frag_packets,
    iow_rx_nr_frag_headroom_err,
    iow_tx_byte,
    iow_tx_packets,
    iow_tx_dropped,
    iow_tx_nr_frag_packets,
    iow_tx_fraglist_packets,
    iow_tx_fraglist_nr_frags_packets,
    iow_tx_tso_packets,
    iow_tx_tso_drop_packets,
    iow_tx_gso_packets,
    iow_tx_gso_dropped_packets,
    iow_rx_frame,
    iow_rx_bytes,
    iow_rx_bytes_g,
    iow_rx_broadcast,
    iow_rx_multicast,
    iow_rx_crc_err,
    iow_rx_runt_err,
    iow_rx_jabber_err,
    iow_rx_undersize,
    iow_rx_oversize,
    iow_rx_pkt64,
    iow_rx_pkt65to127,
    iow_rx_pkt128to255,
    iow_rx_pkt256to511,
    iow_rx_pkt512to1023,
    iow_rx_pkt1024tomax,
    iow_rx_unicast,
    iow_rx_len_err,
    iow_rx_outofrange_err_ctr,
    iow_rx_pause,
    iow_rx_fifo_overflow,
    iow_rx_vlan,
    iow_rx_wdog,
    iow_rx_lpi_usec_ctr,
    iow_rx_lpi_tran_ctr,
    iow_rx_drop_frame_ctr,
    iow_rx_drop_byte_ctr,
    iow_tx_bytes,
    iow_tx_frame,
    iow_tx_broadcast,
    iow_tx_broadcast_gb,
    iow_tx_multicast,
    iow_tx_multicast_gb,
    iow_tx_pkt64,
    iow_tx_pkt65to127,
    iow_tx_pkt128to255,
    iow_tx_pkt256to511,
    iow_tx_pkt512to1023,
    iow_tx_pkt1024tomax,
    iow_tx_unicast,
    iow_tx_underflow_err,
    iow_tx_bytes_g,
    iow_tx_frame_g,
    iow_tx_pause,
    iow_tx_vlan,
    iow_tx_lpi_usec_ctr,
    iow_tx_lpi_tran_ctr,
    iow_STAT_END,
} g_linux_indx;

static struct ethtool_stats *g_linux_stats = NULL;
static struct eth_stats g_linux_ifstats;

int linux_eth_get_link_settings(const char*, struct eth_link*);

int linux_eth_set_link_settings(const char *ifname, struct eth_link link)
{
    struct {
	struct ethtool_link_settings req;
	__u32 link_mode_data[3 * 32 * 127];
    } ecmd;

    memset(&ecmd, 0, sizeof(struct ethtool_link_settings));

    if (linux_eth_get_link_settings(ifname, &link))
	return -1;

    ecmd.req.cmd = ETHTOOL_SLINKSETTINGS;

    ecmd.req.port = link.portid;
    ecmd.req.speed = link.speed;
    ecmd.req.autoneg = (link.autoneg == 0 ? false : true);
    ecmd.req.duplex = (link.fullduplex == 1 ? false : true);

    if (0 != eth_ioctl(ifname, SIOCETHTOOL, &ecmd, sizeof(struct ethtool_link_settings)))
	return -1;
    return 0;
}

int linux_eth_get_link_settings(const char *ifname, struct eth_link *link)
{
    struct {
	struct ethtool_link_settings req;
	__u32 link_mode_data[3 * 32 * 127];
    } ecmd;

    memset(&ecmd, 0, sizeof(struct ethtool_link_settings));

    ecmd.req.cmd = ETHTOOL_GLINKSETTINGS;

    if (0 != eth_ioctl(ifname, SIOCETHTOOL, &ecmd, sizeof(struct ethtool_link_settings)))
	return -1;

    if (ecmd.req.link_mode_masks_nwords >= 0 || ecmd.req.cmd != ETHTOOL_GLINKSETTINGS)
	return -1;

    ecmd.req.link_mode_masks_nwords = -ecmd.req.link_mode_masks_nwords;

    if (0 != eth_ioctl(ifname, SIOCETHTOOL, &ecmd, sizeof(struct ethtool_link_settings)))
	return -1;

    if (ecmd.req.link_mode_masks_nwords <= 0 || ecmd.req.cmd != ETHTOOL_GLINKSETTINGS)
	return -1;

    link->portid = ecmd.req.port;
    link->speed = ecmd.req.speed;
    link->autoneg = ecmd.req.autoneg == 0 ? false : true;
    link->fullduplex = ecmd.req.duplex == 1 ? false : true;

    return 0;
}

int linux_eth_poweron_phy(const char *ifname, struct eth_phy p)
{
    libethernet_err("%s(): TODO\n", __func__);
    return 0;
}

int linux_eth_poweroff_phy(const char *ifname, struct eth_phy p)
{
    libethernet_err("%s(): TODO\n", __func__);
    return 0;
}

int linux_eth_reset_phy(const char *ifname, int phy_id)
{
    return eth_mii_reset_phy(ifname, phy_id);
}

static int linux_get_ifstats(const char *ifname, struct eth_stats *s)
{
    struct if_stats easy_ifstat;

    if (!s)
        return -1;

    memset(&easy_ifstat, 0, sizeof(struct if_stats));
    if (if_getstats(ifname, &easy_ifstat) < 0) {
        return -1;
    }

    s->tx_bytes = easy_ifstat.tx_bytes;
    s->tx_packets = easy_ifstat.tx_packets;
    s->tx_errors = easy_ifstat.tx_errors;
/* Some counters set to zero, and will be populated cross referring
 * the rmon stats structure.
 */
    s->tx_ucast_packets = 0;
    s->tx_mcast_packets = 0;
    s->tx_bcast_packets = 0;
    s->tx_discard_packets = 0;
    s->rx_bytes = easy_ifstat.rx_bytes;
    s->rx_packets = 0;
    s->rx_errors = easy_ifstat.rx_errors;
    s->rx_ucast_packets = 0;
    s->rx_mcast_packets = 0;
    s->rx_bcast_packets = 0;
    s->rx_discard_packets = 0;
    s->rx_unknown_packets = 0;

    return 0;
}
 
static int linux_get_ethtool_stats(const char *ifname)
{
    int fd; 
    size_t n_stats;
    size_t stats_size;
    int status;

    fd = socket(AF_INET, SOCK_DGRAM, /* protocol = */ 0); 
    if (fd < 0) {
        syslog(LOG_ERR, "%s(%d): Failed"
                " to open control socket.\n", __FUNCTION__, __LINE__);
        return -1;
    }

    struct ethtool_drvinfo drvinfo = {.cmd = ETHTOOL_GDRVINFO};
    struct ifreq req = {.ifr_data = (void *)&drvinfo};
    strncpy(req.ifr_name, ifname, sizeof(req.ifr_name));
    status = ioctl(fd, SIOCETHTOOL, &req);

    if (status < 0) {
        close(fd);
        syslog(LOG_ERR, "%s(%d): Failed to get"
                "driver information from %s:", __FUNCTION__, __LINE__, ifname);
        return -1; 
    }

    n_stats = (size_t)drvinfo.n_stats;
    if (n_stats < 1) {
        close(fd);
        syslog(LOG_ERR, "%s(%d): No stats"
                " available for %s", __FUNCTION__, __LINE__, ifname);
        return -1;
    }
    stats_size = sizeof(struct ethtool_stats) + (n_stats * sizeof(uint64_t));

    g_linux_stats = (struct ethtool_stats *)calloc(1, stats_size);
    if (!g_linux_stats) {
        close(fd);
        syslog(LOG_ERR, "%s(%d): malloc failed.", 
                __FUNCTION__, __LINE__);
        return -1;
    }

    g_linux_stats->cmd = ETHTOOL_GSTATS;
    g_linux_stats->n_stats = n_stats;
    req.ifr_data = (void *)g_linux_stats;

    status = ioctl(fd, SIOCETHTOOL, &req);
    if (status < 0) {
        close(fd);
        if (g_linux_stats)
	    free(g_linux_stats);
        syslog(LOG_ERR, "%s(%d): Reading statistics"
                " from %s failed:", __FUNCTION__, __LINE__, ifname);
        return -1;
    }

    close(fd);
    return 0;
}

int linux_get_if_stats(const char *ifname)
{
    memset(&g_linux_ifstats, 0, sizeof(struct eth_stats));


    if (linux_get_ifstats(ifname, &g_linux_ifstats) < 0)
        return -1;
    if (linux_get_ethtool_stats(ifname) < 0)
        return -1;

    return 0;
}

int linux_eth_get_stats(const char *ifname, struct eth_stats *s)
{
    if (!s)
        return -1;

    if (linux_get_if_stats(ifname) < 0)
        return -1;

    s->tx_bytes = g_linux_ifstats.tx_bytes;
    s->tx_packets = g_linux_ifstats.tx_packets;
    s->tx_errors = g_linux_ifstats.tx_errors;
    s->tx_ucast_packets = (uint64_t)g_linux_stats->data[iow_tx_unicast];
    s->tx_mcast_packets = (uint64_t)g_linux_stats->data[iow_tx_multicast];
    s->tx_bcast_packets = (uint64_t)g_linux_stats->data[iow_tx_broadcast];
    s->tx_discard_packets = (uint64_t)g_linux_stats->data[iow_tx_dropped];
    s->rx_bytes = g_linux_ifstats.rx_bytes;
    s->rx_packets = (uint64_t)g_linux_stats->data[iow_rx_packets];
    s->rx_errors = g_linux_ifstats.rx_errors;
    s->rx_ucast_packets = (uint64_t)g_linux_stats->data[iow_rx_unicast];
    s->rx_mcast_packets = (uint64_t)g_linux_stats->data[iow_rx_multicast];
    s->rx_bcast_packets = (uint64_t)g_linux_stats->data[iow_rx_broadcast];
    s->rx_discard_packets = (uint64_t)g_linux_stats->data[iow_rx_dropped];
/*FIXME: Doesn't exist a way to get the counter rx_unknown_packets.*/
    s->rx_unknown_packets = 0;

    free(g_linux_stats);

    return 0;
}

int linux_eth_get_rmon_stats(const char *ifname, struct eth_rmon_stats *rmon)
{
    int ret = 0;

    if (linux_get_if_stats(ifname) < 0)
        ret = -1;

    rmon->tx.packets = (uint64_t)g_linux_stats->data[iow_tx_packets];
    rmon->tx.bytes = (uint64_t)g_linux_stats->data[iow_tx_byte];
    rmon->tx.crc_err_packets = 0;
/* These two counters are marked zero because they dont
 * hold much relevancy to Customer
 */
    rmon->tx.under_sz_packets = 0;
    rmon->tx.over_sz_packets = 0;
    rmon->tx.packets_64bytes = (uint64_t)g_linux_stats->data[iow_tx_pkt64];
    rmon->tx.packets_65to127bytes = (uint64_t)g_linux_stats->data[iow_tx_pkt65to127];
    rmon->tx.packets_128to255bytes = (uint64_t)g_linux_stats->data[iow_tx_pkt128to255];
    rmon->tx.packets_256to511bytes = (uint64_t)g_linux_stats->data[iow_tx_pkt256to511];
    rmon->tx.packets_512to1023bytes = (uint64_t)g_linux_stats->data[iow_tx_pkt512to1023];
    rmon->tx.packets_1024to1518bytes = (uint64_t)g_linux_stats->data[iow_tx_pkt1024tomax];
    rmon->tx.pause_packets = (uint64_t)g_linux_stats->data[iow_tx_pause];

    rmon->rx.bytes = (uint64_t)g_linux_stats->data[iow_rx_byte];
    rmon->rx.packets = (uint64_t)g_linux_stats->data[iow_rx_packets];
    rmon->rx.bcast_packets = (uint64_t)g_linux_stats->data[iow_rx_broadcast];
    rmon->rx.mcast_packets = (uint64_t)g_linux_stats->data[iow_rx_multicast];
    rmon->rx.crc_err_packets = (uint64_t)g_linux_stats->data[iow_rx_crc_err];
    rmon->rx.under_sz_packets = (uint64_t)g_linux_stats->data[iow_rx_undersize];
    rmon->rx.over_sz_packets = (uint64_t)g_linux_stats->data[iow_rx_oversize];
    rmon->rx.packets_64bytes = (uint64_t)g_linux_stats->data[iow_rx_pkt64];
    rmon->rx.packets_65to127bytes = (uint64_t)g_linux_stats->data[iow_rx_pkt65to127];
    rmon->rx.pause_packets = (uint64_t)g_linux_stats->data[iow_rx_pause];

    free(g_linux_stats);

    return ret;
}
