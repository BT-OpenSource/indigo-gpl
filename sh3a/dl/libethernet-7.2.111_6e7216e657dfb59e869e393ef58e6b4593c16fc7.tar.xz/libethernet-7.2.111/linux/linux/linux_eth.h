#ifndef LINUX_ETH_H
#define LINUX_ETH_H

#ifdef __cplusplus
extern "C" {
#endif

int linux_eth_set_link_settings(const char *ifname, struct eth_link link);
int linux_eth_get_link_settings(const char *ifname, struct eth_link *link);
int linux_eth_poweron_phy(const char *ifname, struct eth_phy p);
int linux_eth_poweroff_phy(const char *ifname, struct eth_phy p);
int linux_eth_reset_phy(const char *ifname, int phy_id);
int linux_eth_get_stats(const char *ifname, struct eth_stats *s);
int linux_eth_get_rmon_stats(const char *ifname, struct eth_rmon_stats *rmon);

#ifdef __cplusplus
}
#endif

#endif /* LINUX_ETH_H */
