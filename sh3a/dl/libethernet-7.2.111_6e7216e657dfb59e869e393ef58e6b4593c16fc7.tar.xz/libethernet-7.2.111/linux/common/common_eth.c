/*
 * common_eth.c - Linux based statistics collection ubus methods.
 *
 * Copyright (C) 2023 iopsys Software Solutions AB. All rights reserved.
 *
 * Author: padmalochan.mohapatra@iopsys.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <ctype.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <time.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include <linux/ethtool.h>
#include <linux/sockios.h>
#include <easy/easy.h>
#include <easy/if_utils.h>
#include "ethernet.h"
#include "../linux/linux_eth.h"
#include "../mtk/mtk_eth.h"

#if defined(IOPSYS_MEDIATEK)
const struct eth_ops mtk_eth_ops = {
        .ifname = "lan",
        .get_stats = mtk_eth_get_stats,
        .get_rmon_stats = mtk_eth_get_rmon_stats,
};
#elif defined(IOPSYS_LINUX)
const struct eth_ops linux_eth_ops = {
        .ifname = "eth",
        .set_link_settings = linux_eth_set_link_settings,
        .get_link_settings = linux_eth_get_link_settings,
        .poweron_phy = linux_eth_poweron_phy,
        .poweroff_phy = linux_eth_poweroff_phy,
        .reset_phy = linux_eth_reset_phy,
        .get_stats = linux_eth_get_stats,
        .get_rmon_stats = linux_eth_get_rmon_stats,
};
#endif
