/*
 * mtk_eth.c - Linux based statistics collection ubus methods.
 *
 * Copyright (C) 2023 iopsys Software Solutions AB. All rights reserved.
 *
 * Author: padmalochan.mohapatra@iopsys.eu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <ctype.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <time.h>
#include <syslog.h>
#include <unistd.h>
#include <stdlib.h>
#include <linux/ethtool.h>
#include <linux/sockios.h>
#include <easy/easy.h>
#include <easy/if_utils.h>
#include "ethernet.h"
#include "mtk_eth.h"

typedef enum {
    iow_tx_packets = 0,
    iow_tx_bytes,
    iow_rx_packets,
    iow_rx_bytes,
    iow_TxDrop,
    iow_TxCrcErr,
    iow_TxUnicast,
    iow_TxMulticast,
    iow_TxBroadcast,
    iow_TxCollision,
    iow_TxSingleCollision,
    iow_TxMultipleCollision,
    iow_TxDeferred,
    iow_TxLateCollision,
    iow_TxExcessiveCollistion,
    iow_TxPause,
    iow_TxPktSz64,
    iow_TxPktSz65To127,
    iow_TxPktSz128To255,
    iow_TxPktSz256To511,
    iow_TxPktSz512To1023,
    iow_Tx1024ToMax,
    iow_TxBytes,
    iow_RxDrop,
    iow_RxFiltering,
    iow_RxUnicast,
    iow_RxMulticast,
    iow_RxBroadcast,
    iow_RxAlignErr,
    iow_RxCrcErr,
    iow_RxUnderSizeErr,
    iow_RxFragErr,
    iow_RxOverSzErr,
    iow_RxJabberErr,
    iow_RxPause,
    iow_RxPktSz64,
    iow_RxPktSz65To127,
    iow_RxPktSz128To255,
    iow_RxPktSz256To511,
    iow_RxPktSz512To1023,
    iow_RxPktSz1024ToMax,
    iow_RxBytes,
    iow_RxCtrlDrop,
    iow_RxIngressDrop,
    iow_RxArlDrop,
    iow_STATS_END,
} g_indx;

struct mtk_ethnic_stats {
    uint32_t   cmd;
    uint32_t   n_stats;
    uint64_t   data[iow_STATS_END];
} g_mtk_stat;

static struct eth_stats g_mtk_ifstats;

static int mtk_get_ifstats(const char *ifname, struct eth_stats *s)
{

    struct if_stats easy_ifstat;

    if (!s)
        return -1;

    memset(&easy_ifstat, 0, sizeof(struct if_stats));
    if (if_getstats(ifname, &easy_ifstat) < 0) {
	return -1;
    }

    s->tx_bytes = easy_ifstat.tx_bytes;
    s->tx_packets = easy_ifstat.tx_packets;
    s->tx_errors = easy_ifstat.tx_errors;
/* Some counters set to zero, and will be populated cross referring
 * the rmon stats structure.
 */
    s->tx_ucast_packets = 0;
    s->tx_mcast_packets = 0;
    s->tx_bcast_packets = 0;
    s->tx_discard_packets = 0;
    s->rx_bytes = easy_ifstat.rx_bytes;
    s->rx_packets = 0;
    s->rx_errors = easy_ifstat.rx_errors;
    s->rx_ucast_packets = 0;
    s->rx_mcast_packets = 0;
    s->rx_bcast_packets = 0;
    s->rx_discard_packets = 0;
    s->rx_unknown_packets = 0;

    return 0;
}


int mtk_get_ethtool_stats(const char *ifname)
{
    int ret = 0;

    g_mtk_stat.cmd = ETHTOOL_GSTATS;
    if (0 != eth_ioctl(ifname, SIOCETHTOOL, &g_mtk_stat, sizeof(struct mtk_ethnic_stats)))
        ret = -1;

    if (ret)
	syslog(LOG_ERR, "%s(%d) nic_stats collection failed.", __FUNCTION__, __LINE__);

    return ret;
}


int mtk_get_if_stats(const char *ifname)
{

    memset(&g_mtk_ifstats, 0, sizeof(struct eth_stats));
    memset(&g_mtk_stat, 0, sizeof(struct mtk_ethnic_stats));

    if (mtk_get_ifstats(ifname, &g_mtk_ifstats) < 0)
        return -1;
    if (mtk_get_ethtool_stats(ifname) < 0)
	return -1;

    return 0;
}

int mtk_eth_get_stats(const char *ifname, struct eth_stats *s)
{
    if (!s)
	return -1;
    if (mtk_get_if_stats(ifname) < 0)
	return -1;

    s->tx_bytes = g_mtk_ifstats.tx_bytes;
    s->tx_packets = g_mtk_ifstats.tx_packets;
    s->tx_errors = g_mtk_ifstats.tx_errors;
    s->tx_ucast_packets = g_mtk_stat.data[iow_TxUnicast];
    s->tx_mcast_packets = g_mtk_stat.data[iow_TxMulticast];
    s->tx_bcast_packets = g_mtk_stat.data[iow_TxBroadcast];
    s->tx_discard_packets = g_mtk_stat.data[iow_TxDrop];
    s->rx_bytes = g_mtk_ifstats.rx_bytes;
    s->rx_packets = g_mtk_stat.data[iow_rx_packets];
    s->rx_errors = g_mtk_ifstats.rx_errors;
    s->rx_ucast_packets = g_mtk_stat.data[iow_RxUnicast];
    s->rx_mcast_packets = g_mtk_stat.data[iow_RxMulticast];
    s->rx_bcast_packets = g_mtk_stat.data[iow_RxBroadcast];
    s->rx_discard_packets = g_mtk_stat.data[iow_RxDrop];
/*FIXME: Doesn't exist a way to get the counter rx_unknown_packets.*/
    s->rx_unknown_packets = 0;

    return 0;
}

int mtk_eth_get_rmon_stats(const char *ifname, struct eth_rmon_stats *rmon)
{
    int ret = 0;

    if (mtk_get_if_stats(ifname) < 0)
	ret = -1;

    rmon->tx.packets = g_mtk_stat.data[iow_tx_packets];
    rmon->tx.bytes = g_mtk_stat.data[iow_tx_bytes];
    rmon->tx.crc_err_packets = g_mtk_stat.data[iow_TxCrcErr];
/* These two counters are marked zero because they dont 
 * hold much relevancy to Customer 
 */
    rmon->tx.under_sz_packets = 0;
    rmon->tx.over_sz_packets = 0;
    rmon->tx.packets_64bytes = g_mtk_stat.data[iow_TxPktSz64];
    rmon->tx.packets_65to127bytes = g_mtk_stat.data[iow_TxPktSz65To127];
    rmon->tx.packets_128to255bytes = g_mtk_stat.data[iow_TxPktSz128To255];
    rmon->tx.packets_256to511bytes = g_mtk_stat.data[iow_TxPktSz256To511];
    rmon->tx.packets_512to1023bytes = g_mtk_stat.data[iow_TxPktSz512To1023];
    rmon->tx.packets_1024to1518bytes = g_mtk_stat.data[iow_Tx1024ToMax];
    rmon->tx.pause_packets = g_mtk_stat.data[iow_TxPause];

    rmon->rx.bytes = g_mtk_stat.data[iow_RxBytes];
    rmon->rx.packets = g_mtk_stat.data[iow_rx_packets];
    rmon->rx.bcast_packets = g_mtk_stat.data[iow_RxBroadcast];
    rmon->rx.mcast_packets = g_mtk_stat.data[iow_RxMulticast];
    rmon->rx.crc_err_packets = g_mtk_stat.data[iow_RxCrcErr];
    rmon->rx.under_sz_packets = g_mtk_stat.data[iow_RxUnderSizeErr];
    rmon->rx.over_sz_packets = g_mtk_stat.data[iow_RxOverSzErr];
    rmon->rx.packets_64bytes = g_mtk_stat.data[iow_RxPktSz64];
    rmon->rx.packets_65to127bytes = g_mtk_stat.data[iow_RxPktSz65To127];
    rmon->rx.packets_128to255bytes = g_mtk_stat.data[iow_RxPktSz128To255];
    rmon->rx.packets_256to511bytes = g_mtk_stat.data[iow_RxPktSz256To511];
    rmon->rx.packets_512to1023bytes = g_mtk_stat.data[iow_RxPktSz512To1023];
    rmon->rx.packets_1024to1518bytes = g_mtk_stat.data[iow_RxPktSz1024ToMax];
    rmon->tx.pause_packets = g_mtk_stat.data[iow_RxPause];

    return ret;
}
