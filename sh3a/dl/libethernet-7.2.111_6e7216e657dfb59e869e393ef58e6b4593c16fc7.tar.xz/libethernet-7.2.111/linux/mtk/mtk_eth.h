#ifndef MTK_ETH_H
#define MTK_ETH_H

#ifdef __cplusplus
extern "C" {
#endif

int mtk_eth_get_stats(const char *ifname, struct eth_stats *s);
int mtk_eth_get_rmon_stats(const char *ifname, struct eth_rmon_stats *rmon);

#ifdef __cplusplus
}
#endif

#endif  /* MTK_ETH_H */
