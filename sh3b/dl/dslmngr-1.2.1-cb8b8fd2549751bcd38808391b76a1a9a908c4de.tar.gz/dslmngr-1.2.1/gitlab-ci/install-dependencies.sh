#!/bin/bash

echo "install dependencies"

# libeasy
cd /opt/dev
rm -fr libeasy
mkdir -p /usr/include/easy
git clone -b devel https://dev.iopsys.eu/hal/libeasy.git
cd libeasy
make
cp -a libeasy*.so* /usr/lib
cp -a *.h /usr/include/easy/

# libdsl
cd /opt/dev
rm -fr libdsl
git clone -b devel https://dev.iopsys.eu/hal/libdsl.git
cd libdsl
make PLATFORM=TEST
cp -a common.h xdsl.h xtm.h /usr/include
cp -a libdsl*.so* /usr/lib
sudo ldconfig
