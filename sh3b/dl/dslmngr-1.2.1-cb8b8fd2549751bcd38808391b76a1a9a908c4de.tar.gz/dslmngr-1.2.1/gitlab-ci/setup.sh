#!/bin/bash

echo "preparation script"

pwd

cp -r ./test/files/etc/* /etc/
cp -r ./schemas/ubus/* /usr/share/rpcd/schemas
if [ -n "$1" ]; then
cp ./gitlab-ci/iopsys-supervisord.conf /etc/supervisor/conf.d/
else
cp ./gitlab-ci/iopsys-supervisord_functional.conf /etc/supervisor/conf.d/
fi

ls /etc/config/
ls /usr/share/rpcd/schemas/
ls /etc/supervisor/conf.d/
