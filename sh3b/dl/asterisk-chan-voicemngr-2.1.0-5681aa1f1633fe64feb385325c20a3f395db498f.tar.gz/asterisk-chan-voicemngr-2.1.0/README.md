Asterisk Channel for IOPSYS Voice HAL (voicemngr/libvoice)
