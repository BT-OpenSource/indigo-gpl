#!/bin/bash

echo "Install dependencies"
orig_dir=$(pwd)
echo $orig_dir

source ./gitlab-ci/shared.sh

# install bbfdm
install_bbfdm

# compile
set -e
echo "build stage"
cd $orig_dir/bbf_plugin/
pwd
make CFLAGS="-DBBF_VENDOR_PREFIX=\\\"X_IOPSYS_EU_\\\""

