# Function Specification

The scope of mcastmgr manages is snooping.

ubus dump when one subscriber has connected is listening on a stream

```
root@iopsys:~# ubus call mcast stats 
{ 
        "snooping": [
        {
                "interface": "br-lan",
                "groups": [
                {
                        "groupaddr": "227.10.10.10",
                        "clients": [
                        {
                                "ipaddr": "192.168.1.210",
                                "device": "eth1", 
                                "timeout": 259
                        }
                        ]
                }
                ]
        }
        ]
}
```

