/* Inteno AB, Stockholm, Sweden
 * Channel for Broadcom FXS ports
 */

#ifndef CHAN_BRCM_H
#define CHAN_BRCM_H

/* Change this value when needed */
#define CHANNEL_VERSION "1.2"

#define DEFAULT_CALLER_ID "Unknown"
#define PHONE_MAX_BUF 480
#define CALL_STATUS_MAX_LEN 14

#define TIMEMSEC 1000

#define PCMU 0
#define G726 2
#define G723 4
#define PCMA 8
#define G729 18
#define G722 9
#define DTMF_PAYLOAD 101
#define DTMF 128
#define RTCP_SR      200
#define RTCP_RR      201
#define RTCP_SDES    202
#define RTCP_XR      207

#define CN 13

#define NOT_INITIALIZED -1
//#define EPSTATUS_DRIVER_ERROR -1
#define MAX_NUM_LINEID 30
#define PACKET_BUFFER_SIZE 1024
#define NUM_SUBCHANNELS 2

#define BEGIN 0
#define CONT  1
#define END   2

enum brcm_channel_state {
	ONHOOK,
	OFFHOOK,
	DIALING,
	CALLING,
	INCALL,
	ANSWER,
	CALLENDED,
	RINGING,
	CALLWAITING,
	ONHOLD,
	TRANSFERING,
	RINGBACK,
	AWAITONHOOK,
	ALLOCATED,
};

enum LINE_EVENT {																// Events from low level line (endpoint etc.)
	EVENT_DTMF0,
	EVENT_DTMF1,
	EVENT_DTMF2,
	EVENT_DTMF3,
	EVENT_DTMF4,
	EVENT_DTMF5,
	EVENT_DTMF6,
	EVENT_DTMF7,
	EVENT_DTMF8,
	EVENT_DTMF9,
	EVENT_DTMFA,
	EVENT_DTMFB,
	EVENT_DTMFC,
	EVENT_DTMFD,
	EVENT_DTMFH,
	EVENT_DTMFS,
	EVENT_OFFHOOK,
	EVENT_ONHOOK,
	EVENT_EARLY_OFFHOOK,
	EVENT_EARLY_ONHOOK,
	EVENT_FLASH,
	EVENT_CALL_REJECT,
	EVENT_DECT_UNAVAILABLE,
	EVENT_MEDIA,
	EVENT_SWITCH,
	EVENT_JOIN,
	EVENT_RELEASE,
	EVENT_LAST,
};

enum endpoint_type {
	FXS,
	FXO,
	DECT,
};

enum CALL_DIRECTION {
	INCOMING_CALL,
	OUTGOING_CALL,
};

typedef enum dialtone_state {
	DIALTONE_OFF = 0,
	DIALTONE_ON,
	DIALTONE_CONGESTION,
	DIALTONE_SPECIAL_CONDITION,
	DIALTONE_UNOBTAINABLE,
	DIALTONE_HOWLER,
	DIALTONE_UNKNOWN,
	DIALTONE_LAST,
} dialtone_state;

struct brcm_subchannel {
	int id;
	unsigned int call_id;		/* The call_id of connection assigned by pjsip */
	struct ast_channel *owner;	/* Channel we belong to, possibly NULL */
	int connection_id;		/* Current connection id, may be -1 */
	enum brcm_channel_state channel_state;	/* Channel states */
	enum CALL_DIRECTION call_direction;		// Direction of call for the subchannel : 0 = incoming, 1 = outgoing
	unsigned int connection_init;	/* State for endpoint id connection initialization */
	struct ast_frame fr;		/* Frame */
	unsigned int time_stamp;	/* Endpoint RTP time stamp state */
	unsigned int period;		/* Endpoint RTP period */
	unsigned int ssrc;		/* Endpoint RTP synchronization source */
	int codec;			/* Used codec */
	struct brcm_pvt *parent;	/* brcm_line owning this subchannel */
	int cw_timer_id;		/* Current call waiting timer id, -1 if no active timer */
	int cwBeep_timer_id;		/* Current call waiting beep timer id, -1 if no active timer */
	int r4_hangup_timer_id;		/* Current R4 hangup timer id, -1 if no active timer */
	int onhold_hangup_timer_id;	/* Current onhold hangup timer id, -1 if no active timer */
	int conference_initiator;       /* True if this subchannel is the original leg in a 3-way conference */
	char *conference_id;            /* uuid of the conference initiated by this subchannel */
	int conf_timer_id;              /* Current conference call timer id, -1 if no active timer */
	rtp_statistics rtp_stats;	/* RTP statistics for currently hanging up channel */
	unsigned int jitter_count;
	unsigned long int farEndInterrivalJitter;
	char blind_xfer_target[32];	/* Transfer target for unattended call transfer */
};


struct brcm_channel_tech {
	int (* signal_ringing)(struct brcm_pvt *p);
	int (* signal_ringing_callerid_pending)(struct brcm_pvt *p);
	int (* signal_callerid)(struct ast_channel *chan, struct brcm_subchannel *s);
	int (* stop_ringing)(struct brcm_pvt *p);
	int (* stop_ringing_callerid_pending)(struct brcm_pvt *p);
	int (* release)(struct brcm_pvt *p);
};


struct brcm_pvt {
	ast_mutex_t lock;
	int fd;							/* Raw file descriptor for this device */
	int line_id;				/* Maps to the correct port */
	char dtmfbuf[AST_MAX_EXTENSION];/* DTMF buffer per channel */
	int dtmf_len;					/* Length of DTMF buffer */
	int dtmf_first;					/* DTMF control state, button pushes generate 2 events, one on button down and one on button up */
	struct ast_format_cap * lastformat;            /* Last output format */
	struct ast_format_cap * lastinput;             /* Last input format */
	struct brcm_pvt *next;			/* Next channel in list */
	char offset[AST_FRIENDLY_OFFSET];
	char buf[PHONE_MAX_BUF];					/* Static buffer for reading frames */
	char context_direct[AST_MAX_EXTENSION];
	char context[AST_MAX_EXTENSION];
	char obuf[PHONE_MAX_BUF * 2];
	char ext[AST_MAX_EXTENSION];
	char language[MAX_LANGUAGE];
	char cid_num[AST_MAX_EXTENSION];
	char cid_name[AST_MAX_EXTENSION];
	char extensionCallStatus[CALL_STATUS_MAX_LEN];

	struct brcm_subchannel *sub[NUM_SUBCHANNELS];	/* List of sub-channels, needed for callwaiting and 3-way support */
	int hf_detected;			/* Hook flash detected */
	dialtone_state dialtone;		/* Set by manager command */
	struct brcm_channel_tech *tech;

	int interdigit_timer_id;		/* Id of timer that tracks interdigit timeout */
	int autodial_timer_id;			/* Id of timer that tracks autodial timeout */
	int dialtone_timeout_timer_id;	/* Id of timer that tracks dialtone timeout */
	int onhold_hangup_timer_id;		/* Id of timer that tracks onhold hangup timeout */
};

enum rtp_type {
	BRCM_UNKNOWN,
	BRCM_AUDIO,
	BRCM_RTCP_SR,
	BRCM_RTCP_RR
};



/* Mapping of DTMF to char/name/intval */
typedef struct DTMF_CHARNAME_MAP
{
	enum LINE_EVENT	event;
	char	name[12];
	char	c;
	int		i;
} DTMF_CHARNAME_MAP;




typedef struct DIALTONE_MAP
{
	dialtone_state	state;
	char		str[24];
} DIALTONE_MAP;

static const DIALTONE_MAP dialtone_map[] =
{
	{DIALTONE_OFF,		"off"},
	{DIALTONE_ON,		"on"},
	{DIALTONE_CONGESTION,	"congestion"},
	{DIALTONE_SPECIAL_CONDITION, "special"},
	{DIALTONE_UNOBTAINABLE, "number unobtainable"},
	{DIALTONE_HOWLER, "howler"},
	{DIALTONE_UNKNOWN,	"unknown"},
	{DIALTONE_LAST,		"-"},
};

/* Struct for individual endpoint settings */
typedef struct {
	int enabled;
	char language[MAX_LANGUAGE];
	char cid_num[AST_MAX_EXTENSION];
	char cid_name[AST_MAX_EXTENSION];
	char context_direct[AST_MAX_EXTENSION]; //Context that will be checked for exact matches
	char context[AST_MAX_EXTENSION]; //Default context for dialtone mode
	char autodial_ext[AST_MAX_EXTENSION];
	int autodial_timeoutmsec;
	int ringsignal;
	int timeoutmsec;
        int interdigitopenmsec;
        int minimumnumberdigits;
        char terminationdigit;
	int period;
	int hangup_xfer;
	int dialtone_timeoutmsec;
	int offhook_nu_timeoutmsec;
	int offhook_silence_timeoutmsec;
	int do_not_disturb;
	int anonymouscallenable;
        int calleridenable;
        int calleridnameenable;
} channel_settings;


/* Caller ID */
#define CLID_MAX_DATE	10
#define CLID_MAX_NUMBER	21
#define CLID_MAX_NAME	16
typedef struct CLID_STRING
{
	char date[CLID_MAX_DATE];
	char number_name[CLID_MAX_NUMBER + CLID_MAX_NAME + 4]; // 4 = comma, quotation marks and null terminator
} CLID_STRING;


/* Global jitterbuffer configuration - by default, jb is disabled */
static struct ast_jb_conf default_jbconf =
{
	.flags = 0,
	.max_size = -1,
	.resync_threshold = -1,
	.impl = "",
	.target_extra = -1,
};


#define DEFAULT_CALL_WAITING_TIMEOUT 20 // In seconds
#define DEFAULT_CALL_WAITING_BEEP_FREQ 5 // In seconds

#define DEFAULT_R4_HANGUP_TIMEOUT 5000 // In milliseconds
#define DEFAULT_ONHOLD_HANGUP_TIMEOUT 20 // In seconds


#endif /* CHAN_BRCM_H */
