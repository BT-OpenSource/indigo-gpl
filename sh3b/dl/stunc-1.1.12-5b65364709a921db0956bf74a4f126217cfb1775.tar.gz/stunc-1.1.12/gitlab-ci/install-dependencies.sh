#!/bin/bash

echo "install dependencies for unit-test script"
pwd

source ./gitlab-ci/shared.sh

# install required packages
exec_cmd apt update
exec_cmd apt install -y python3-pip
exec_cmd pip3 install pexpect ubus

echo "Installing libwolfssl"
exec_cmd apt install -y libwolfssl-dev

# install uspd
cd /opt/dev  
[ -d uspd ] && rm -fr uspd 
exec_cmd git clone https://dev.iopsys.eu/iopsys/uspd.git
cd uspd
#exec_cmd git checkout origin/transaction_id
exec_cmd ./gitlab-ci/install-dependencies.sh
exec_cmd ./gitlab-ci/setup.sh
exec_cmd make
exec_cmd cp uspd /usr/sbin/uspd
