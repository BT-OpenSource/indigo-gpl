#!/bin/bash

echo "preparation script"

mkdir -p /var/state/
cp ./gitlab-ci/iopsys-supervisord.conf /etc/supervisor/conf.d/
cp -rf ./test/files/* /

ls /etc/config/
ls /etc/supervisor/conf.d/
