# STUNC Tests
`STUNC` module test is based on `iopsys/code-analysis-dev` docker image. It consists
of below test phases, in each phase different kind of test perform:

1. Static code analysis
2. Functional Test

## 1. Static code Analysis
In this stage code is being tested for flaws by running static code analysers,
it also runs CPD tests which determine the optimal reusable codes.
Tests running in this phase are:

 - Flaw finder
 - CPP Check
 - CPD Test

## 2. Functional Test
In this stage functionality provided by `stunc` is getting tested.

Below tests and verifications done in this stage:
- Compilation check
- Functionality verification with python scripts



