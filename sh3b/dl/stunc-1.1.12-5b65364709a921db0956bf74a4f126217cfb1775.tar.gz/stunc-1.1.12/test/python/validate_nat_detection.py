#!/usr/bin/python3

import ubus
import json

TEST_NAME = "Validate NAT detection"

print("Running: " + TEST_NAME)

assert ubus.connect()

nat = ubus.call("usp", "get", {"path":"Device.ManagementServer.NATDetected"})
print(nat)
#assert nat[0]["NATDetected"]==True, "NAT not detected, Please verify manually"

conreq = ubus.call("usp", "get", {"path":"Device.ManagementServer.UDPConnectionRequestAddress"})
print(conreq)
#assert len(conreq[0]["UDPConnectionRequestAddress"])!=0, "Failed to get USP connection req"

ubus.disconnect()

print("PASS: " + TEST_NAME)
