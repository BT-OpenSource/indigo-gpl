#!/bin/bash

echo "Install dependencies for functional test"
pwd

# install uspd
cd /opt/dev
[ -d uspd ] && rm -fr uspd
git clone https://dev.iopsys.eu/iopsys/uspd.git
cd uspd
./gitlab-ci/install-dependencies.sh
./gitlab-ci/setup.sh
make
cp uspd /usr/sbin/uspd

