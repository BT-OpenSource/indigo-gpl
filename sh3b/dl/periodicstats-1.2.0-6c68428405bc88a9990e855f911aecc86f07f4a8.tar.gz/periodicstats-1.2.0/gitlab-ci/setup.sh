#!/bin/bash

echo "Setup Script"

pwd

cp -r ./test/files/etc/* /etc/
cp ./gitlab-ci/iopsys-supervisord.conf /etc/supervisor/conf.d/

ls /etc/config/
ls /etc/supervisor/conf.d/

supervisorctl shutdown
supervisord -c /etc/supervisor/supervisord.conf
