# Periodicstats
===============

[periodicstats](https://dev.iopsys.eu/iopsys/periodicstats)

## Introduction

Periodicstats daemon implements collection of periodic statistics for the device. Periodic statistics
are measured over a sample interval and are made available to the controller. The daemon also
implements the support for the Device.PeriodicStats object.

## Project Components

Project consists of following components:

- Application written in C programming language.
- Documentation in a Markdown format

## Build Instructions

`periodicstats` is written using C programming language and TR181 data model object implemented as bbf plugin.

## UCI configuration

There is no default configuration for periodicstats, it should be added separately.
Below is an example of a basic configuration. Note that in the uci configuration below

```
config globals 'globals'
        option enable '1'

config sampleset 'set_1'
        option fetch_samples '0'
        option enable '1'
        option sample_interval '20'
        option report_sample '7'

config parameter 'param_1_set_1'
        option sample_set 'set_1'
        option enable '1'
        option reference 'Device.Ethernet.Link.1.Stats.BytesReceived'

config sampleset 'set_2'
        option fetch_samples '0'
        option enable '1'
        option sample_interval '10'
        option report_sample '4'

config parameter 'param_1_set_2'
        option sample_set 'set_2'
        option enable '1'
        option reference 'Device.Ethernet.Link.2.Stats.BytesReceived'
```


The device can be configured with mutiple sampleset and parameter sections. The sampleset
object corresponds to the Device.PeriodicStats.SampleSet.{i} object and the parameter section
refers to the Device.PeriodicStats.SampleSet.{i}.Parameter.{i} object.
The parameter section is related to the sampleset object via the sample_set option.

## UBUS API

Periodicstats daemon has no registered object or method over ubus.
'usp' can be used to perform operations on periodicstats configuration.

The above uci configuration can be mapped to the output of usp command below:

```
root@iopsys:~# ubus call usp get '{"path":"Device.PeriodicStatistics."}'
{
	"PeriodicStatistics": {
		"MaxReportSamples": 0,
		"MinSampleInterval": 0,
		"SampleSet": [
			{
				"Alias": "cpe-1",
				"Enable": true,
				"FetchSamples": 0,
				"ForceSample": false,
				"Name": "set_1",
				"Parameter": [
					{
						"Alias": "cpe-1",
						"CalculationMode": "0",
						"Enable": true,
						"Failures": 0,
						"HighThreshold": 0,
						"LowThreshold": 0,
						"Reference": "Device.Ethernet.Link.1.Stats.BytesReceived",
						"SampleMode": "Current",
						"SampleSeconds": "",
						"SuspectData": "",
						"Values": "[ \"4359\", \"4359\", \"4764\", \"4856\", \"5113\", \"5159\", \"5488\" ]"
					},
				],
				"ParameterNumberOfEntries": 1,
				"ReportEndTime": "2021-04-23T07:29:22Z",
				"ReportSamples": 7,
				"ReportStartTime": "2021-04-23T07:27:22Z",
				"SampleInterval": 20,
				"SampleSeconds": "0,20,40,60,80,100,120,",
				"Status": "Enabled",
				"TimeReference": "0001-01-01T00:00:00Z"
			},
			{
				"Alias": "cpe-2",
				"Enable": true,
				"FetchSamples": 0,
				"ForceSample": false,
				"Name": "set_2",
				"Parameter": [
					{
						"Alias": "cpe-3",
						"CalculationMode": "0",
						"Enable": true,
						"Failures": 0,
						"HighThreshold": 0,
						"LowThreshold": 0,
						"Reference": "Device.Ethernet.Link.2.Stats.BytesReceived",
						"SampleMode": "Current",
						"SampleSeconds": "",
						"SuspectData": "",
						"Values": "[ \"16840\", \"17621\", \"17621\", \"17787\" ]"
					}
				],
				"ParameterNumberOfEntries": 1,
				"ReportEndTime": "2021-04-23T07:29:22Z",
				"ReportSamples": 4,
				"ReportStartTime": "2021-04-23T07:28:50Z",
				"SampleInterval": 10,
				"SampleSeconds": "0,10,20,30,",
				"Status": "Enabled",
				"TimeReference": "0001-01-01T00:00:00Z"
			}
		],
		"SampleSetNumberOfEntries": 2
	}
```

