/*
 * main.c - for periodicstats everything starts here.
 *
 * Copyright (C) 2022 iopsys Software Solutions AB. All rights reserved.
 *
 * Author: Shubham Sharma <shubham.sharma@iopsys.eu>
 *
 * See LICENSE file for license related information.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <libubus.h>

#include "periodicstats.h"

// Global periodic stats structure
static LIST_HEAD(ss_list);

/**
 *  This function prints the usage of the daemon
 *  @param prog input pointer to char, for program name
 */
static void pstat_usage(char *prog)
{
	fprintf(stderr, "Usage: %s [options]\n", prog);
	fprintf(stderr, "\n");
	fprintf(stderr, "options:\n");
	fprintf(stderr, "    -s <socket path>   ubus socket\n");
	fprintf(stderr, "    -h <help>       To print this help menu\n");
	fprintf(stderr, "\n");
}

/**
 *  Main function for periodicstats, everything starts here
 *  @param argc input number of input arguments
 *  @param argv input double pointer array of optional command line arguments
 *  retrun integer value 0 on success and -1 on failure
 */
int main(int argc, char **argv)
{
	struct ubus_context *ctx = NULL;
	const char *ubus_socket = NULL;
	int ch, ret;

	while ((ch = getopt(argc, argv, "hs:")) != -1) {
		switch (ch) {
		case 's':
			ubus_socket = optarg;
			break;
		case 'h':
			pstat_usage(argv[0]);
			exit(0);
		default:
			break;
		}
	}

	/* Logging to syslog */
	openlog("periodicstats", LOG_PID|LOG_CONS, LOG_LOCAL1);

	uloop_init();
	ctx = ubus_connect(ubus_socket);
	if (!ctx) {
		syslog(LOG_ERR, "Failed to connect to ubus\n");
		return -1;
	}

	// Initialize global periodic stats structure
	ret = pstats_global_init(&ss_list);
	if (ret) {
		syslog(LOG_ERR, "Failed to initialize global periodic stats.\n");
		goto out;
	}

	ubus_add_uloop(ctx);

	// stats collection invoked from here
	pstats_get_stats(&ss_list);

	/* Main loop of periodicstats */
	uloop_run();

 out:
	ubus_free(ctx);
	uloop_done();
	pstats_global_free(&ss_list);

	return 0;
}
