/*
 * periodicstats.h - definitions used in periodic statistics
 *
 * Copyright (C) 2022 iopsys Software Solutions AB. All rights reserved.
 *
 * Author: Shubham Sharma <shubham.sharma@iopsys.eu>
 *
 * See LICENSE file for license related information.
 *
 */

#ifndef PERIODICSTATS_H
#define PERIODICSTATS_H

#include <string.h>
#include <time.h>
#include <uci.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <json-c/json.h>

/* logging though syslog */
#include <syslog.h>

/* To utalize kernel list implementation. */
#include <libubox/list.h>
#include <libubox/uloop.h>
#include <libubox/blobmsg_json.h>

/* UCI definitions, used to parse the config files at their right location */
#define UCI_CONFIG_PSTATS   "periodicstats"

#define MAX_DATA_STR 4096
#define MAX_REF_STR 256
#define MAX_NAME_STR 128
#define MAX_ALIAS_STR 64
#define MAX_TIME_STR 25

#define DEFAULT_REF_TIME "0001-01-01T00:00:00Z"

/*
 * Structure for parameters inside each sample set
 * */
typedef struct parameters {
	bool enable;
	char name[MAX_NAME_STR];
	char reference[MAX_REF_STR];
	char values[MAX_REF_STR];
	struct list_head list;
} param;

/*
 * Structure for sample sets inside global periodic stats
 * */
typedef struct sample_sets {
	struct uloop_timeout utimer;
	bool enable;
	uint32_t smpl_intrvl;
	uint32_t rprt_smpls;
	uint32_t fetch_samples;
	time_t time_ref;
	char name[MAX_NAME_STR];
	struct list_head params;
	struct list_head list;
} smpl_set;

int pstats_global_init(struct list_head *ss_list);
void pstats_global_free(struct list_head *ss_list);
void pstats_get_stats(struct list_head *global_list);


#endif /* PERIODICSTATS_H */
