/*
 * periodicstats.c - periodic stats method handeling code
 *
 * Copyright (C) 2022 iopsys Software Solutions AB. All rights reserved.
 *
 * Author: Shubham Sharma <shubham.sharma@iopsys.eu>
 *
 * See LICENSE file for license related information.
 *
 */

#include <time.h>
#include <libubus.h>

#include "periodicstats.h"

#define ubus_timeout 5

static void _ubus_handler_cb(struct ubus_request *req, int type __attribute__((unused)), struct blob_attr *msg)
{
	struct json_object **jobj = (struct json_object **)req->priv;
	char *buffer = NULL;

	if (msg == NULL || jobj == NULL)
		return;

	*jobj = NULL;

	buffer = blobmsg_format_json(msg, true);
	if (buffer == NULL)
		return;

	*jobj = json_tokener_parse(buffer);

	free(buffer);
}

static int _ubus_call(const char *obj_name, const char *method, struct blob_buf *bb, struct json_object **jout)
{
	struct ubus_context *ubus_ctx = NULL;
	uint32_t id;
	int ret = -1;

	ubus_ctx = ubus_connect(NULL);
	if (ubus_ctx == NULL) {
		syslog(LOG_ERR, "ubus connect failed");
		return -1;
	}

	ret = ubus_lookup_id(ubus_ctx, obj_name, &id);
	if (ret != 0) {
		syslog(LOG_ERR, "ubus lookup failed");
		return -1;
	}

	ret = ubus_invoke(ubus_ctx, id, method, bb->head, _ubus_handler_cb, jout, ubus_timeout * 1000);
	ubus_free(ubus_ctx);

	return ret;
}

static char *usp_get_parameter_value(const char *path_name)
{
	struct blob_buf bb = {0};
	json_object *jobj = NULL;
	char *value = NULL;

	memset(&bb, 0, sizeof(struct blob_buf));
	blob_buf_init(&bb, 0);

	blobmsg_add_string(&bb, "path", path_name);

	_ubus_call("usp", "get", &bb, &jobj);
	if (jobj == NULL) {
		syslog(LOG_ERR, "Could not read stats");
		goto end;
	}

	json_object_object_foreach(jobj, key, val) {
		(void)(key); // Skip unused variable error
		value = strdup(json_object_get_string(val));
		break;
	}

	json_object_put(jobj);

end:
	blob_buf_free(&bb);
	return value;
}

static char *uci_get_option_value(const char *sampleset, const char *reference, const char *option)
{
	struct uci_context *uci_ctx = uci_alloc_context();
	struct uci_package *uci_pkg = NULL;
	struct uci_element *uci_elmnt = NULL;
	char *value = NULL;

	uci_load(uci_ctx, "periodicstats", &uci_pkg);
	if (!uci_pkg) {
		syslog(LOG_ERR, "Failed to load configuration\n");
		uci_free_context(uci_ctx);
		return value;
	}

	uci_foreach_element(&uci_pkg->sections, uci_elmnt) {
		struct uci_section *uci_sec = uci_to_section(uci_elmnt);
		if (uci_sec && !strcmp(uci_sec->type, "parameter")) {
			struct uci_option *samp_set = uci_lookup_option(uci_ctx, uci_sec, "sample_set");
			struct uci_option *ref = uci_lookup_option(uci_ctx, uci_sec, "reference");
			if (samp_set && ref && !strcmp(samp_set->v.string, sampleset) && !strcmp(ref->v.string, reference)) {
				struct uci_option *u_option = uci_lookup_option(uci_ctx, uci_sec, option);
				value = u_option ? strdup(u_option->v.string) : NULL;
				break;
			}
		}
	}

	uci_unload(uci_ctx, uci_pkg);
	uci_free_context(uci_ctx);

	return value;
}

static void uci_set_option_value(const char *sec_name, const char *option, const char *value)
{
	struct uci_context *uci_ctx = uci_alloc_context();
	struct uci_ptr ptr = {0};
	char uci_path[256] = {0};

	snprintf(uci_path, sizeof(uci_path), "periodicstats.%s.%s=%s", sec_name, option, value);

	if (uci_lookup_ptr(uci_ctx, &ptr, uci_path, true) != UCI_OK) {
		uci_free_context(uci_ctx);
		return;
	}

	if (uci_set(uci_ctx, &ptr) != UCI_OK) {
		uci_free_context(uci_ctx);
		return;
	}

	if (uci_save(uci_ctx, ptr.p) != UCI_OK) {
		uci_free_context(uci_ctx);
		return;
	}

	uci_commit(uci_ctx, &ptr.p, false);
	uci_free_context(uci_ctx);
}

static unsigned int get_next_run_time(time_t time_ref, uint32_t periodic_interval)
{
	unsigned int next_period = 0;
	time_t curr_time;

	curr_time = time(NULL);

	if (curr_time > time_ref)
		next_period = (periodic_interval - ((curr_time - time_ref) % periodic_interval));
	else
		next_period = (time_ref - curr_time) % periodic_interval;

	if (next_period == 0)
		next_period = periodic_interval;

	return next_period;
}

static int pstats_get_nb_sample_stored(char *list)
{
	int count = 0;

	if (!list)
		return count;

	if (*list)
		count = 1;

	while (*list) {
		if (*list++ == ',')
			count++;
	}

	return count;
}

static void pstats_handle_sampleset(smpl_set *sample_set, param *sample_param)
{
	char values[2048] = {0};
	char *sample_list = NULL;

	values[0] = 0;

	char *data = usp_get_parameter_value(sample_param->reference);
	if (data == NULL)
		return;

	sample_list = uci_get_option_value(sample_set->name, sample_param->reference, "values");

	if (sample_list) {
		int samples_stored = pstats_get_nb_sample_stored(sample_list);

		if (samples_stored >= sample_set->rprt_smpls)
			snprintf(values, sizeof(values), "%s,%s", strchr(sample_list, ',') + 1, data);
		else
			snprintf(values, sizeof(values), "%s,%s", sample_list, data);
	} else {
		snprintf(values, sizeof(values), "%s", data);
	}

	if (values[0] != 0)
		uci_set_option_value(sample_param->name, "values", values);

	if (sample_list) free(sample_list);
	free(data);
}

static void pstats_sampleset_cb(struct uloop_timeout *timeout)
{
	smpl_set *sample_set = NULL;
	param *sample_param = NULL;
	unsigned int next_period;

	sample_set = container_of(timeout, smpl_set, utimer);

	list_for_each_entry(sample_param, &sample_set->params, list) {
		if ((sample_param->enable != 1) || (sample_param->reference[0] == '\0'))
			continue;

		pstats_handle_sampleset(sample_set, sample_param);
	}

	next_period = get_next_run_time(sample_set->time_ref, sample_set->smpl_intrvl);
	syslog(LOG_INFO, "Start new collection session of sample set '%s' in %d sec\n", sample_set->name, next_period);
	uloop_timeout_set(timeout, next_period * 1000);
}

/**
 *  pstats_get_stats function for invoking periodic statistics
 *  @param global_list input pointer to global list_head structure
 */
void pstats_get_stats(struct list_head *global_list)
{
	smpl_set *sample_set = NULL;
	unsigned int next_period;

	list_for_each_entry(sample_set, global_list, list) {
		if (sample_set->enable != 1)
			continue;

		sample_set->utimer.cb = pstats_sampleset_cb;
		next_period = get_next_run_time(sample_set->time_ref, sample_set->smpl_intrvl);
		syslog(LOG_INFO, "Start new collection session of sample set '%s' in %d sec\n", sample_set->name, next_period);
		uloop_timeout_set(&sample_set->utimer, next_period * 1000);
	}
}
