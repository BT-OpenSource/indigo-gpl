/*
 * Copyright (C) 2022 iopsys Software Solutions AB
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation
 *
 *	Author: Shubham Sharma <shubham.sharma@iopsys.eu>
 */

#ifndef __PERIODICSTATISTICS_H
#define __PERIODICSTATISTICS_H

#include <libbbf_api.h>

extern DMOBJ tDevicePeriodicStatisticsObj[];
extern DMOBJ tPeriodicStatisticsObj[];
extern DMLEAF tPeriodicStatisticsParams[];
extern DMOBJ tPeriodicStatisticsSampleSetObj[];
extern DMLEAF tPeriodicStatisticsSampleSetParams[];
extern DMLEAF tPeriodicStatisticsSampleSetParameterParams[];

#endif //__PERIODICSTATISTICS_H

