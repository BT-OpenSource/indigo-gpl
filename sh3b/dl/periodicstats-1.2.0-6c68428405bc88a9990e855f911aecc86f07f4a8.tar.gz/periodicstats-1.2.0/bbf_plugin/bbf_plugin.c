/*
 * Copyright (C) 2022 iopsys Software Solutions AB
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation
 *
 *	Author: Shubham Sharma <shubham.sharma@iopsys.eu>
 */

#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include "bbf_plugin.h"

#define DEFAULT_ONE "1"
#define DEFAULT_ZERO "0"
#define DEFAULT_REPORT_SAMPLE "24"
#define DEFAULT_SAMPLE_INTERVAL "3600"
#define DEFAULT_REF_TIME "0001-01-01T00:00:00Z"
#define BASE 10

//static char *SampleMode[] = {"Current", "Change", NULL};
//static char *CalculationMode[] = {"Latest", "Minimum", "Maximum", "Average", NULL};

/* ********** DynamicObj ********** */
DM_MAP_OBJ tDynamicObj[] = {
/* parentobj, nextobject, parameter */
{"Device.", tDevicePeriodicStatisticsObj, NULL},
{0}
};

/*************************************************************
* ENTRY METHOD
**************************************************************/
static int browsePeriodicStatisticsSampleSetInst(struct dmctx *dmctx, DMNODE *parent_node, void *prev_data, char *prev_instance)
{
	struct dmmap_dup *p = NULL;
	char *inst = NULL;
	LIST_HEAD(dup_list);

	bbf_synchronise_config_sections_with_dmmap("periodicstats", "sampleset", "dmmap_periodicstats", &dup_list);
	list_for_each_entry(p, &dup_list, list) {

		inst = bbf_handle_instance(dmctx, parent_node, p->dmmap_section, "sampleset_instance", "sampleset_alias");

		if (bbf_link_instance_object(dmctx, parent_node, (void *)p->config_section, inst) == DM_STOP)
			break;
	}
	bbf_free_config_sections_list(&dup_list);

	return 0;
}

static int browsePeriodicStatisticsSampleSetParameterInst(struct dmctx *dmctx, DMNODE *parent_node, void *prev_data, char *prev_instance)
{
	struct dmmap_dup *p = NULL;
	char *inst = NULL;
	LIST_HEAD(dup_list);

	bbf_synchronise_config_sections_with_dmmap("periodicstats", "parameter", "dmmap_periodicstats", &dup_list);
	list_for_each_entry(p, &dup_list, list) {
		char *cur_sample_set = NULL;

		bbf_uci_get_value_by_section(p->config_section, "sample_set", &cur_sample_set);
		if (strcmp(cur_sample_set, section_name((struct uci_section *)prev_data)) != 0)
			continue;

		inst = bbf_handle_instance(dmctx, parent_node, p->dmmap_section, "parameter_instance", "parameter_alias");

		if (bbf_link_instance_object(dmctx, parent_node, (void *)p->config_section, inst) == DM_STOP)
			return 0;
	}
	bbf_free_config_sections_list(&dup_list);

	return 0;
}

/*************************************************************
* ADD & DEL OBJ
**************************************************************/
static int addObjPeriodicStatisticsSampleSet(char *refparam, struct dmctx *ctx, void *data, char **instance)
{
	struct uci_section *s = NULL, *dmmap_sampleset = NULL;
	char name[32];

	snprintf(name, sizeof(name), "set_%s", *instance);

	bbf_uci_add_section("periodicstats", "sampleset", &s);
	bbf_uci_rename_section(s, name);
	bbf_uci_set_value_by_section(s, "enable", DEFAULT_ZERO);
	bbf_uci_set_value_by_section(s, "report_sample", DEFAULT_REPORT_SAMPLE);
	bbf_uci_set_value_by_section(s, "sample_interval", DEFAULT_SAMPLE_INTERVAL);
	bbf_uci_set_value_by_section(s, "fetch_samples", DEFAULT_ZERO);
	bbf_uci_set_value_by_section(s, "time_reference", DEFAULT_REF_TIME);

	bbf_uci_add_section_bbfdm("dmmap_periodicstats", "sampleset", &dmmap_sampleset);
	bbf_uci_set_value_by_section(dmmap_sampleset, "section_name", name);
	bbf_uci_set_value_by_section(dmmap_sampleset, "sampleset_instance", *instance);
	return 0;
}

static int delObjPeriodicStatisticsSampleSet(char *refparam, struct dmctx *ctx, void *data, char *instance, unsigned char del_action)
{
	struct uci_section *s = NULL, *stmp = NULL, *dmmap_section = NULL;

	switch (del_action) {
		case DEL_INST:
			// Loop over to delete all related sub-sections i.e., parameters
			bbf_uci_foreach_sections_safe("periodicstats", "parameter", stmp, s) {
				char *param_sec;

				bbf_find_dmmap_section("dmmap_periodicstats", "parameter", section_name(s), &dmmap_section);
				if (dmmap_section) {
					char *value;
					bbf_uci_get_value_by_section(dmmap_section, "parent_section", &value);
					if (!strcmp(value, section_name((struct uci_section *)data))) {
						bbf_uci_delete_section_by_section(dmmap_section, NULL, NULL);
					}
				}

				bbf_uci_get_value_by_section(s, "sample_set", &param_sec);
				if (!strcmp(param_sec, section_name((struct uci_section *)data)))
					bbf_uci_delete_section_by_section(s, NULL, NULL);
			}

			bbf_find_dmmap_section("dmmap_periodicstats", "sampleset", section_name((struct uci_section *)data), &dmmap_section);
			bbf_uci_delete_section_by_section(dmmap_section, NULL, NULL);

			bbf_uci_delete_section_by_section((struct uci_section *)data, NULL, NULL);
			break;
		case DEL_ALL:
			bbf_uci_foreach_sections_safe("periodicstats", "parameter", stmp, s) {
				bbf_find_dmmap_section("dmmap_periodicstats", "parameter", section_name(s), &dmmap_section);
				bbf_uci_delete_section_by_section(dmmap_section, NULL, NULL);

				bbf_uci_delete_section_by_section(s, NULL, NULL);
			}

			bbf_uci_foreach_sections_safe("periodicstats", "sampleset", stmp, s) {
				bbf_find_dmmap_section("dmmap_periodicstats", "sampleset", section_name(s), &dmmap_section);
				bbf_uci_delete_section_by_section(dmmap_section, NULL, NULL);

				bbf_uci_delete_section_by_section(s, NULL, NULL);
			}
			break;
	}
	return 0;
}

static int addObjPeriodicStatisticsSampleSetParameter(char *refparam, struct dmctx *ctx, void *data, char **instance)
{
	struct uci_section *s = NULL, *dmmap_parameter = NULL;
	char param_name[64] = {0};

	snprintf(param_name, sizeof(param_name), "param_%s_%s", *instance, section_name((struct uci_section *)data));

	bbf_uci_add_section("periodicstats", "parameter", &s);
	bbf_uci_rename_section(s, param_name);
	bbf_uci_set_value_by_section(s, "sample_set", section_name((struct uci_section *)data));
	bbf_uci_set_value_by_section(s, "enable", DEFAULT_ZERO);
	bbf_uci_set_value_by_section(s, "reference", NULL);

	bbf_uci_add_section_bbfdm("dmmap_periodicstats", "parameter", &dmmap_parameter);
	bbf_uci_set_value_by_section(dmmap_parameter, "parent_section", section_name((struct uci_section *)data));
	bbf_uci_set_value_by_section(dmmap_parameter, "section_name", param_name);
	bbf_uci_set_value_by_section(dmmap_parameter, "parameter_instance", *instance);
	return 0;
}

static int delObjPeriodicStatisticsSampleSetParameter(char *refparam, struct dmctx *ctx, void *data, char *instance, unsigned char del_action)
{
	struct uci_section *s = NULL, *stmp = NULL, *dmmap_section = NULL;

	switch (del_action) {
		case DEL_INST:
			bbf_find_dmmap_section("dmmap_periodicstats", "parameter", section_name((struct uci_section *)data), &dmmap_section);
			bbf_uci_delete_section_by_section(dmmap_section, NULL, NULL);
			bbf_uci_delete_section_by_section((struct uci_section *)data, NULL, NULL);
			break;
		case DEL_ALL:
			bbf_uci_foreach_sections_safe("periodicstats", "parameter", stmp, s) {
				bbf_find_dmmap_section("dmmap_periodicstats", "parameter", section_name(s), &dmmap_section);
				bbf_uci_delete_section_by_section(dmmap_section, NULL, NULL);

				bbf_uci_delete_section_by_section(s, NULL, NULL);
			}
			break;
	}
	return 0;
}

/*************************************************************
* GET & SET PARAM
**************************************************************/
static int get_PeriodicStatistics_MinSampleInterval(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	*value = "0";
	return 0;
}

static int get_PeriodicStatistics_MaxReportSamples(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	*value = "0";
	return 0;
}

static int get_PeriodicStatistics_SampleSetNumberOfEntries(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	char buf[16] = {0};

	int cnt = bbf_get_number_of_entries(ctx, data, instance, browsePeriodicStatisticsSampleSetInst);
	snprintf(buf, sizeof(buf), "%d", cnt);
	*value = bbf_strdup(buf);
	return 0;
}

static int get_PeriodicStatisticsSampleSet_Alias(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{

	bbf_uci_get_value_by_section((struct uci_section *)data, "alias", value);
	if ((*value)[0] == '\0') {
		char buf[16] = {0};

		snprintf(buf, sizeof(buf), "cpe-%s", instance);
		*value = bbf_strdup(buf);
	}

	return 0;
}

static int set_PeriodicStatisticsSampleSet_Alias(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	switch (action)	{
		case VALUECHECK:
			if (bbf_validate_string(value, -1, 64, NULL, NULL))
				return FAULT_9007;
			break;
		case VALUESET:
			bbf_uci_set_value_by_section((struct uci_section *)data, "alias", value);
			return 0;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSet_Enable(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	*value = bbf_uci_get_value_by_section_fallback_def((struct uci_section *)data, "enable", DEFAULT_ZERO);
	return 0;
}

static int set_PeriodicStatisticsSampleSet_Enable(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	bool b;
	switch (action) {
		case VALUECHECK:
			if (bbf_validate_boolean(value))
				return FAULT_9007;
			break;
		case VALUESET:
			bbf_convert_string_to_bool(value, &b);
			bbf_uci_set_value_by_section((struct uci_section *)data, "enable", b ? "1" : DEFAULT_ZERO);
			if (b)
				bbf_uci_set_value("periodicstats", "globals", "enable", "1");
			break;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSet_Status(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	bbf_uci_get_value_by_section((struct uci_section *)data, "enable", value);
	*value = (atoi(*value) == 1) ? "Enabled" : "Disabled";
	return 0;
}

static int get_PeriodicStatisticsSampleSet_Name(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	*value = bbf_strdup(section_name((struct uci_section *)data));
	return 0;
}

static int set_PeriodicStatisticsSampleSet_Name(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	struct uci_section *dmmap_section = NULL;

	switch (action) {
		case VALUECHECK:
			if (bbf_validate_string(value, -1, 128, NULL, NULL))
				return FAULT_9007;

			// Check if the value is empty
			if (*value == '\0')
				return FAULT_9007;
			break;
		case VALUESET:
			// Update dmmap_periodicstats file
			bbf_find_dmmap_section("dmmap_periodicstats", "sampleset", section_name((struct uci_section *)data), &dmmap_section);
			bbf_uci_set_value_by_section(dmmap_section, "section_name", value);

			// Update sampleset config
			bbf_uci_rename_section((struct uci_section *)data, value);
			break;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSet_SampleInterval(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	*value = bbf_uci_get_value_by_section_fallback_def((struct uci_section *)data, "sample_interval", DEFAULT_SAMPLE_INTERVAL);
	return 0;
}

static int set_PeriodicStatisticsSampleSet_SampleInterval(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	switch (action) {
		case VALUECHECK:
			if (bbf_validate_unsignedInt(value, RANGE_ARGS{{NULL,NULL}}, 1))
				return FAULT_9007;
			return 0;
		case VALUESET:
			bbf_uci_set_value_by_section((struct uci_section *)data, "sample_interval", value);
			return 0;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSet_ReportSamples(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	*value = bbf_uci_get_value_by_section_fallback_def((struct uci_section *)data, "report_sample", DEFAULT_REPORT_SAMPLE);
	return 0;
}

static int set_PeriodicStatisticsSampleSet_ReportSamples(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	switch (action) {
		case VALUECHECK:
			if (bbf_validate_unsignedInt(value, RANGE_ARGS{{NULL,NULL}}, 1))
				return FAULT_9007;
			return 0;
		case VALUESET:
			bbf_uci_set_value_by_section((struct uci_section *)data, "report_sample", value);
			return 0;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSet_TimeReference(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	*value = bbf_uci_get_value_by_section_fallback_def((struct uci_section *)data, "time_reference", DEFAULT_REF_TIME);
	return 0;
}

static int set_PeriodicStatisticsSampleSet_TimeReference(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
		switch (action)	{
		case VALUECHECK:
			if (bbf_validate_dateTime(value))
				return FAULT_9007;
			break;
		case VALUESET:
			bbf_uci_set_value_by_section((struct uci_section *)data, "time_reference", value);
			break;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSet_FetchSamples(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	*value = bbf_uci_get_value_by_section_fallback_def((struct uci_section *)data, "fetch_samples", DEFAULT_ZERO);
	return 0;
}

static int set_PeriodicStatisticsSampleSet_FetchSamples(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	switch (action) {
		case VALUECHECK:
			if (bbf_validate_unsignedInt(value, RANGE_ARGS{{NULL,NULL}}, 1))
				return FAULT_9007;
			return 0;
		case VALUESET:
			bbf_uci_set_value_by_section((struct uci_section *)data, "fetch_samples", value);
			return 0;
	}
	return 0;
}

/*static int get_PeriodicStatisticsSampleSet_ForceSample(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	//TODO
	return 0;
}

static int set_PeriodicStatisticsSampleSet_ForceSample(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	switch (action)	{
		case VALUECHECK:
			if (bbf_validate_boolean(value))
				return FAULT_9007;
			break;
		case VALUESET:
			//TODO
			break;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSet_ReportStartTime(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	//TODO
	return 0;
}

static int get_PeriodicStatisticsSampleSet_ReportEndTime(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	//TODO
	return 0;
}

static int get_PeriodicStatisticsSampleSet_SampleSeconds(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	//TODO
	return 0;
}*/

static int get_PeriodicStatisticsSampleSet_ParameterNumberOfEntries(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	char buf[16] = {0};

	int cnt = bbf_get_number_of_entries(ctx, data, instance, browsePeriodicStatisticsSampleSetParameterInst);
	snprintf(buf, sizeof(buf), "%d", cnt);
	*value = bbf_strdup(buf);
	return 0;
}

static int get_PeriodicStatisticsSampleSetParameter_Alias(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	bbf_uci_get_value_by_section((struct uci_section *)data, "alias", value);
	if ((*value)[0] == '\0') {
		char buf[16] = {0};

		snprintf(buf, sizeof(buf), "cpe-%s", instance);
		*value = bbf_strdup(buf);
	}

	return 0;
}

static int set_PeriodicStatisticsSampleSetParameter_Alias(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	switch (action)	{
		case VALUECHECK:
			if (bbf_validate_string(value, -1, 64, NULL, NULL))
				return FAULT_9007;
			break;
		case VALUESET:
			bbf_uci_set_value_by_section((struct uci_section *)data, "alias", value);
			return 0;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSetParameter_Enable(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	*value = bbf_uci_get_value_by_section_fallback_def((struct uci_section *)data, "enable", DEFAULT_ZERO);
	return 0;
}

static int set_PeriodicStatisticsSampleSetParameter_Enable(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	bool b;
	switch (action) {
		case VALUECHECK:
			if (bbf_validate_boolean(value))
				return FAULT_9007;
			break;
		case VALUESET:
			bbf_convert_string_to_bool(value, &b);
			bbf_uci_set_value_by_section((struct uci_section *)data, "enable", b ? "1" : DEFAULT_ZERO);
			break;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSetParameter_Reference(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	bbf_uci_get_value_by_section((struct uci_section *)data, "reference", value);
	return 0;
}

static int set_PeriodicStatisticsSampleSetParameter_Reference(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	switch (action) {
		case VALUECHECK:
			if (bbf_validate_string(value, -1, 256, NULL, NULL))
				return FAULT_9007;
			break;
		case VALUESET:
			bbf_uci_set_value_by_section((struct uci_section *)data, "reference", value);
			return 0;
	}
	return 0;
}

/*static int get_PeriodicStatisticsSampleSetParameter_SampleMode(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	//TODO
	return 0;
}

static int set_PeriodicStatisticsSampleSetParameter_SampleMode(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	switch (action)	{
		case VALUECHECK:
			if (bbf_validate_string(value, -1, -1, SampleMode, NULL))
				return FAULT_9007;
			break;
		case VALUESET:
			//TODO
			break;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSetParameter_CalculationMode(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	//TODO
	return 0;
}

static int set_PeriodicStatisticsSampleSetParameter_CalculationMode(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	switch (action)	{
		case VALUECHECK:
			if (bbf_validate_string(value, -1, -1, CalculationMode, NULL))
				return FAULT_9007;
			break;
		case VALUESET:
			//TODO
			break;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSetParameter_LowThreshold(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	//TODO
	return 0;
}

static int set_PeriodicStatisticsSampleSetParameter_LowThreshold(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	switch (action)	{
		case VALUECHECK:
			if (bbf_validate_int(value, RANGE_ARGS{{"-1",NULL}}, 1))
				return FAULT_9007;
			break;
		case VALUESET:
			//TODO
			break;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSetParameter_HighThreshold(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	//TODO
	return 0;
}

static int set_PeriodicStatisticsSampleSetParameter_HighThreshold(char *refparam, struct dmctx *ctx, void *data, char *instance, char *value, int action)
{
	switch (action)	{
		case VALUECHECK:
			if (bbf_validate_int(value, RANGE_ARGS{{NULL,NULL}}, 1))
				return FAULT_9007;
			break;
		case VALUESET:
			//TODO
			break;
	}
	return 0;
}

static int get_PeriodicStatisticsSampleSetParameter_SampleSeconds(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	//TODO
	return 0;
}

static int get_PeriodicStatisticsSampleSetParameter_SuspectData(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	//TODO
	return 0;
}*/

static int get_PeriodicStatisticsSampleSetParameter_Values(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	bbf_uci_get_value_by_section((struct uci_section *)data, "values", value);
	return 0;
}

/*static int get_PeriodicStatisticsSampleSetParameter_Failures(char *refparam, struct dmctx *ctx, void *data, char *instance, char **value)
{
	//TODO
	return 0;
}*/

/* *** Device. *** */
DMOBJ tDevicePeriodicStatisticsObj[] = {
/* OBJ, permission, addobj, delobj, checkdep, browseinstobj, nextdynamicobj, dynamicleaf, nextobj, leaf, linker, bbfdm_type, uniqueKeys*/
{"PeriodicStatistics", &DMREAD, NULL, NULL, NULL, NULL, NULL, NULL, tPeriodicStatisticsObj, tPeriodicStatisticsParams, NULL, BBFDM_BOTH},
{0}
};

/**********************************************************************************************************************************
*                                            OBJ & PARAM DEFINITION
***********************************************************************************************************************************/
/* *** Device.PeriodicStatistics. *** */
DMOBJ tPeriodicStatisticsObj[] = {
/* OBJ, permission, addobj, delobj, checkdep, browseinstobj, nextdynamicobj, dynamicleaf, nextobj, leaf, linker, bbfdm_type, uniqueKeys*/
{"SampleSet", &DMWRITE, addObjPeriodicStatisticsSampleSet, delObjPeriodicStatisticsSampleSet, NULL, browsePeriodicStatisticsSampleSetInst, NULL, NULL, tPeriodicStatisticsSampleSetObj, tPeriodicStatisticsSampleSetParams, NULL, BBFDM_BOTH, LIST_KEY{"Name", "Alias", NULL}},
{0}
};

DMLEAF tPeriodicStatisticsParams[] = {
/* PARAM, permission, type, getvalue, setvalue, bbfdm_type*/
{"MinSampleInterval", &DMREAD, DMT_UNINT, get_PeriodicStatistics_MinSampleInterval, NULL, BBFDM_BOTH},
{"MaxReportSamples", &DMREAD, DMT_UNINT, get_PeriodicStatistics_MaxReportSamples, NULL, BBFDM_BOTH},
{"SampleSetNumberOfEntries", &DMREAD, DMT_UNINT, get_PeriodicStatistics_SampleSetNumberOfEntries, NULL, BBFDM_BOTH},
{0}
};

/* *** Device.PeriodicStatistics.SampleSet.{i}. *** */
DMOBJ tPeriodicStatisticsSampleSetObj[] = {
/* OBJ, permission, addobj, delobj, checkdep, browseinstobj, nextdynamicobj, dynamicleaf, nextobj, leaf, linker, bbfdm_type, uniqueKeys*/
{"Parameter", &DMWRITE, addObjPeriodicStatisticsSampleSetParameter, delObjPeriodicStatisticsSampleSetParameter, NULL, browsePeriodicStatisticsSampleSetParameterInst, NULL, NULL, NULL, tPeriodicStatisticsSampleSetParameterParams, NULL, BBFDM_BOTH, LIST_KEY{"Reference", "Alias", NULL}},
{0}
};

DMLEAF tPeriodicStatisticsSampleSetParams[] = {
/* PARAM, permission, type, getvalue, setvalue, bbfdm_type*/
{"Alias", &DMWRITE, DMT_STRING, get_PeriodicStatisticsSampleSet_Alias, set_PeriodicStatisticsSampleSet_Alias, BBFDM_BOTH},
{"Enable", &DMWRITE, DMT_BOOL, get_PeriodicStatisticsSampleSet_Enable, set_PeriodicStatisticsSampleSet_Enable, BBFDM_BOTH},
{"Status", &DMREAD, DMT_STRING, get_PeriodicStatisticsSampleSet_Status, NULL, BBFDM_BOTH},
{"Name", &DMWRITE, DMT_STRING, get_PeriodicStatisticsSampleSet_Name, set_PeriodicStatisticsSampleSet_Name, BBFDM_BOTH},
{"SampleInterval", &DMWRITE, DMT_UNINT, get_PeriodicStatisticsSampleSet_SampleInterval, set_PeriodicStatisticsSampleSet_SampleInterval, BBFDM_BOTH},
{"ReportSamples", &DMWRITE, DMT_UNINT, get_PeriodicStatisticsSampleSet_ReportSamples, set_PeriodicStatisticsSampleSet_ReportSamples, BBFDM_BOTH},
{"TimeReference", &DMWRITE, DMT_TIME, get_PeriodicStatisticsSampleSet_TimeReference, set_PeriodicStatisticsSampleSet_TimeReference, BBFDM_BOTH},
{"FetchSamples", &DMWRITE, DMT_UNINT, get_PeriodicStatisticsSampleSet_FetchSamples, set_PeriodicStatisticsSampleSet_FetchSamples, BBFDM_BOTH},
//{"ForceSample", &DMWRITE, DMT_BOOL, get_PeriodicStatisticsSampleSet_ForceSample, set_PeriodicStatisticsSampleSet_ForceSample, BBFDM_CWMP},
//{"ReportStartTime", &DMREAD, DMT_TIME, get_PeriodicStatisticsSampleSet_ReportStartTime, NULL, BBFDM_BOTH},
//{"ReportEndTime", &DMREAD, DMT_TIME, get_PeriodicStatisticsSampleSet_ReportEndTime, NULL, BBFDM_BOTH},
//{"SampleSeconds", &DMREAD, DMT_STRING, get_PeriodicStatisticsSampleSet_SampleSeconds, NULL, BBFDM_BOTH},
{"ParameterNumberOfEntries", &DMREAD, DMT_UNINT, get_PeriodicStatisticsSampleSet_ParameterNumberOfEntries, NULL, BBFDM_BOTH},
{0}
};

/* *** Device.PeriodicStatistics.SampleSet.{i}.Parameter.{i}. *** */
DMLEAF tPeriodicStatisticsSampleSetParameterParams[] = {
/* PARAM, permission, type, getvalue, setvalue, bbfdm_type*/
{"Alias", &DMWRITE, DMT_STRING, get_PeriodicStatisticsSampleSetParameter_Alias, set_PeriodicStatisticsSampleSetParameter_Alias, BBFDM_BOTH},
{"Enable", &DMWRITE, DMT_BOOL, get_PeriodicStatisticsSampleSetParameter_Enable, set_PeriodicStatisticsSampleSetParameter_Enable, BBFDM_BOTH},
{"Reference", &DMWRITE, DMT_STRING, get_PeriodicStatisticsSampleSetParameter_Reference, set_PeriodicStatisticsSampleSetParameter_Reference, BBFDM_BOTH},
//{"SampleMode", &DMWRITE, DMT_STRING, get_PeriodicStatisticsSampleSetParameter_SampleMode, set_PeriodicStatisticsSampleSetParameter_SampleMode, BBFDM_BOTH},
//{"CalculationMode", &DMWRITE, DMT_STRING, get_PeriodicStatisticsSampleSetParameter_CalculationMode, set_PeriodicStatisticsSampleSetParameter_CalculationMode, BBFDM_BOTH},
//{"LowThreshold", &DMWRITE, DMT_INT, get_PeriodicStatisticsSampleSetParameter_LowThreshold, set_PeriodicStatisticsSampleSetParameter_LowThreshold, BBFDM_BOTH},
//{"HighThreshold", &DMWRITE, DMT_INT, get_PeriodicStatisticsSampleSetParameter_HighThreshold, set_PeriodicStatisticsSampleSetParameter_HighThreshold, BBFDM_BOTH},
//{"SampleSeconds", &DMREAD, DMT_STRING, get_PeriodicStatisticsSampleSetParameter_SampleSeconds, NULL, BBFDM_BOTH},
//{"SuspectData", &DMREAD, DMT_STRING, get_PeriodicStatisticsSampleSetParameter_SuspectData, NULL, BBFDM_BOTH},
{"Values", &DMREAD, DMT_STRING, get_PeriodicStatisticsSampleSetParameter_Values, NULL, BBFDM_BOTH},
//{"Failures", &DMREAD, DMT_UNINT, get_PeriodicStatisticsSampleSetParameter_Failures, NULL, BBFDM_BOTH},
{0}
};
